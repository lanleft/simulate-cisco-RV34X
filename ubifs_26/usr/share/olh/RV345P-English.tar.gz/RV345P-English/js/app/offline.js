! function(e) {
    function r(t) {
        if (n[t]) return n[t].exports;
        var i = n[t] = {
            exports: {},
            id: t,
            loaded: !1
        };
        return e[t].call(i.exports, i, i.exports, r), i.loaded = !0, i.exports
    }
    var n = {};
    return r.m = e, r.c = n, r.p = "", r(0)
}([function(e, r, n) {
    "use strict";

    function t(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function i() {
        (0, P.default)(L.default);
        var e = window.webhelp.language.substring(0, 2);
        switch (e) {
            case "en":
                break;
            case "da":
                (0, A.default)(L.default);
                break;
            case "de":
                (0, I.default)(L.default);
                break;
            case "du":
                (0, N.default)(L.default);
                break;
            case "es":
                (0, D.default)(L.default);
                break;
            case "fi":
                (0, B.default)(L.default);
                break;
            case "fr":
                (0, $.default)(L.default);
                break;
            case "hu":
                (0, Y.default)(L.default);
                break;
            case "it":
                (0, V.default)(L.default);
                break;
            case "no":
                (0, X.default)(L.default);
                break;
            case "pt":
                (0, Q.default)(L.default);
                break;
            case "ro":
                (0, ee.default)(L.default);
                break;
            case "ru":
                (0, ne.default)(L.default);
                break;
            case "sv":
                (0, ie.default)(L.default);
                break;
            case "tr":
                (0, se.default)(L.default);
                break;
            default:
                (0, ae.default)(L.default)
        }
        return L.default.Index.load(window.webhelp.search)
    }
    n(1), n(53);
    var o = n(60),
        s = t(o),
        u = n(61),
        a = t(u),
        c = n(72),
        l = t(c),
        f = n(77),
        d = t(f),
        w = n(78),
        m = t(w),
        p = n(79),
        h = t(p),
        b = n(80),
        v = t(b),
        _ = n(87),
        g = t(_),
        k = n(89),
        y = t(k),
        x = n(91),
        S = t(x),
        F = n(93),
        q = t(F),
        W = n(96),
        z = t(W),
        j = n(97),
        L = t(j),
        C = n(98),
        P = t(C),
        E = n(99),
        A = t(E),
        O = n(100),
        I = t(O),
        M = n(101),
        N = t(M),
        T = n(102),
        D = t(T),
        R = n(103),
        B = t(R),
        U = n(104),
        $ = t(U),
        H = n(105),
        Y = t(H),
        J = n(106),
        V = t(J),
        G = n(107),
        X = t(G),
        K = n(108),
        Q = t(K),
        Z = n(109),
        ee = t(Z),
        re = n(110),
        ne = t(re),
        te = n(111),
        ie = t(te),
        oe = n(112),
        se = t(oe),
        ue = n(113),
        ae = t(ue),
        ce = n(114),
        le = t(ce),
        fe = n(115),
        de = t(fe),
        we = document.querySelector("nav[role=toc]"),
        me = document.querySelector("main[role=main]"),
        pe = function() {
            return document.querySelector("#navigate-back")
        },
        he = function() {
            return document.querySelector("#navigate-forward")
        },
        be = function(e) {
            return window.webhelp.files[e]
        },
        ve = (0, de.default)(window, we),
        _e = new s.default(window);
    _e.register((0, a.default)(me, be, ve)), _e.register((0, l.default)(we)), _e.register((0, d.default)(ve, pe, he)), _e.register((0, m.default)(document, ve)), _e.listen(), document.addEventListener("DOMContentLoaded", function() {
        we.replaceChild((0, h.default)(window.webhelp.toc), we.firstElementChild), (0, q.default)(we, ve.expandAll, ve.collapseOthers);
        var e = i(),
            r = {
                fields: {
                    title: {
                        boost: 2
                    },
                    body: {
                        boost: 1
                    }
                },
                bool: "AND",
                expand: !0
            },
            n = (0, le.default)(window.webhelp.language.substring(0, 2)),
            t = (0, z.default)(e, r, n.normalize);
        document.body.insertBefore((0, g.default)(we), me), document.body.insertBefore((0, y.default)(ve.back), me), document.body.appendChild((0, S.default)(ve.forward)), document.body.appendChild((0, v.default)(t, ve.getTitle, ve.getDescription)), ve.collapseOthers()
    })
}, function(e, r, n) {
    n(2), n(46), e.exports = n(10).Array.from
}, function(e, r, n) {
    "use strict";
    var t = n(3)(!0);
    n(6)(String, "String", function(e) {
        this._t = String(e), this._i = 0
    }, function() {
        var e, r = this._t,
            n = this._i;
        return n >= r.length ? {
            value: void 0,
            done: !0
        } : (e = t(r, n), this._i += e.length, {
            value: e,
            done: !1
        })
    })
}, function(e, r, n) {
    var t = n(4),
        i = n(5);
    e.exports = function(e) {
        return function(r, n) {
            var o, s, u = String(i(r)),
                a = t(n),
                c = u.length;
            return a < 0 || a >= c ? e ? "" : void 0 : (o = u.charCodeAt(a), o < 55296 || o > 56319 || a + 1 === c || (s = u.charCodeAt(a + 1)) < 56320 || s > 57343 ? e ? u.charAt(a) : o : e ? u.slice(a, a + 2) : (o - 55296 << 10) + (s - 56320) + 65536)
        }
    }
}, function(e, r) {
    var n = Math.ceil,
        t = Math.floor;
    e.exports = function(e) {
        return isNaN(e = +e) ? 0 : (e > 0 ? t : n)(e)
    }
}, function(e, r) {
    e.exports = function(e) {
        if (void 0 == e) throw TypeError("Can't call method on  " + e);
        return e
    }
}, function(e, r, n) {
    "use strict";
    var t = n(7),
        i = n(8),
        o = n(21),
        s = n(11),
        u = n(22),
        a = n(26),
        c = n(27),
        l = n(42),
        f = n(44),
        d = n(43)("iterator"),
        w = !([].keys && "next" in [].keys()),
        m = "@@iterator",
        p = "keys",
        h = "values",
        b = function() {
            return this
        };
    e.exports = function(e, r, n, v, _, g, k) {
        c(n, r, v);
        var y, x, S, F = function(e) {
                if (!w && e in j) return j[e];
                switch (e) {
                    case p:
                        return function() {
                            return new n(this, e)
                        };
                    case h:
                        return function() {
                            return new n(this, e)
                        }
                }
                return function() {
                    return new n(this, e)
                }
            },
            q = r + " Iterator",
            W = _ == h,
            z = !1,
            j = e.prototype,
            L = j[d] || j[m] || _ && j[_],
            C = !w && L || F(_),
            P = _ ? W ? F("entries") : C : void 0,
            E = "Array" == r ? j.entries || L : L;
        if (E && (S = f(E.call(new e)), S !== Object.prototype && S.next && (l(S, q, !0), t || u(S, d) || s(S, d, b))), W && L && L.name !== h && (z = !0, C = function() {
                return L.call(this)
            }), t && !k || !w && !z && j[d] || s(j, d, C), a[r] = C, a[q] = b, _)
            if (y = {
                    values: W ? C : F(h),
                    keys: g ? C : F(p),
                    entries: P
                }, k)
                for (x in y) x in j || o(j, x, y[x]);
            else i(i.P + i.F * (w || z), r, y);
        return y
    }
}, function(e, r) {
    e.exports = !1
}, function(e, r, n) {
    var t = n(9),
        i = n(10),
        o = n(11),
        s = n(21),
        u = n(24),
        a = "prototype",
        c = function(e, r, n) {
            var l, f, d, w, m = e & c.F,
                p = e & c.G,
                h = e & c.S,
                b = e & c.P,
                v = e & c.B,
                _ = p ? t : h ? t[r] || (t[r] = {}) : (t[r] || {})[a],
                g = p ? i : i[r] || (i[r] = {}),
                k = g[a] || (g[a] = {});
            p && (n = r);
            for (l in n) f = !m && _ && void 0 !== _[l], d = (f ? _ : n)[l], w = v && f ? u(d, t) : b && "function" == typeof d ? u(Function.call, d) : d, _ && s(_, l, d, e & c.U), g[l] != d && o(g, l, w), b && k[l] != d && (k[l] = d)
        };
    t.core = i, c.F = 1, c.G = 2, c.S = 4, c.P = 8, c.B = 16, c.W = 32, c.U = 64, c.R = 128, e.exports = c
}, function(e, r) {
    var n = e.exports = "undefined" != typeof window && window.Math == Math ? window : "undefined" != typeof self && self.Math == Math ? self : Function("return this")();
    "number" == typeof __g && (__g = n)
}, function(e, r) {
    var n = e.exports = {
        version: "2.5.3"
    };
    "number" == typeof __e && (__e = n)
}, function(e, r, n) {
    var t = n(12),
        i = n(20);
    e.exports = n(16) ? function(e, r, n) {
        return t.f(e, r, i(1, n))
    } : function(e, r, n) {
        return e[r] = n, e
    }
}, function(e, r, n) {
    var t = n(13),
        i = n(15),
        o = n(19),
        s = Object.defineProperty;
    r.f = n(16) ? Object.defineProperty : function(e, r, n) {
        if (t(e), r = o(r, !0), t(n), i) try {
            return s(e, r, n)
        } catch (e) {}
        if ("get" in n || "set" in n) throw TypeError("Accessors not supported!");
        return "value" in n && (e[r] = n.value), e
    }
}, function(e, r, n) {
    var t = n(14);
    e.exports = function(e) {
        if (!t(e)) throw TypeError(e + " is not an object!");
        return e
    }
}, function(e, r) {
    e.exports = function(e) {
        return "object" == typeof e ? null !== e : "function" == typeof e
    }
}, function(e, r, n) {
    e.exports = !n(16) && !n(17)(function() {
        return 7 != Object.defineProperty(n(18)("div"), "a", {
            get: function() {
                return 7
            }
        }).a
    })
}, function(e, r, n) {
    e.exports = !n(17)(function() {
        return 7 != Object.defineProperty({}, "a", {
            get: function() {
                return 7
            }
        }).a
    })
}, function(e, r) {
    e.exports = function(e) {
        try {
            return !!e()
        } catch (e) {
            return !0
        }
    }
}, function(e, r, n) {
    var t = n(14),
        i = n(9).document,
        o = t(i) && t(i.createElement);
    e.exports = function(e) {
        return o ? i.createElement(e) : {}
    }
}, function(e, r, n) {
    var t = n(14);
    e.exports = function(e, r) {
        if (!t(e)) return e;
        var n, i;
        if (r && "function" == typeof(n = e.toString) && !t(i = n.call(e))) return i;
        if ("function" == typeof(n = e.valueOf) && !t(i = n.call(e))) return i;
        if (!r && "function" == typeof(n = e.toString) && !t(i = n.call(e))) return i;
        throw TypeError("Can't convert object to primitive value")
    }
}, function(e, r) {
    e.exports = function(e, r) {
        return {
            enumerable: !(1 & e),
            configurable: !(2 & e),
            writable: !(4 & e),
            value: r
        }
    }
}, function(e, r, n) {
    var t = n(9),
        i = n(11),
        o = n(22),
        s = n(23)("src"),
        u = "toString",
        a = Function[u],
        c = ("" + a).split(u);
    n(10).inspectSource = function(e) {
        return a.call(e)
    }, (e.exports = function(e, r, n, u) {
        var a = "function" == typeof n;
        a && (o(n, "name") || i(n, "name", r)), e[r] !== n && (a && (o(n, s) || i(n, s, e[r] ? "" + e[r] : c.join(String(r)))), e === t ? e[r] = n : u ? e[r] ? e[r] = n : i(e, r, n) : (delete e[r], i(e, r, n)))
    })(Function.prototype, u, function() {
        return "function" == typeof this && this[s] || a.call(this)
    })
}, function(e, r) {
    var n = {}.hasOwnProperty;
    e.exports = function(e, r) {
        return n.call(e, r)
    }
}, function(e, r) {
    var n = 0,
        t = Math.random();
    e.exports = function(e) {
        return "Symbol(".concat(void 0 === e ? "" : e, ")_", (++n + t).toString(36))
    }
}, function(e, r, n) {
    var t = n(25);
    e.exports = function(e, r, n) {
        if (t(e), void 0 === r) return e;
        switch (n) {
            case 1:
                return function(n) {
                    return e.call(r, n)
                };
            case 2:
                return function(n, t) {
                    return e.call(r, n, t)
                };
            case 3:
                return function(n, t, i) {
                    return e.call(r, n, t, i)
                }
        }
        return function() {
            return e.apply(r, arguments)
        }
    }
}, function(e, r) {
    e.exports = function(e) {
        if ("function" != typeof e) throw TypeError(e + " is not a function!");
        return e
    }
}, function(e, r) {
    e.exports = {}
}, function(e, r, n) {
    "use strict";
    var t = n(28),
        i = n(20),
        o = n(42),
        s = {};
    n(11)(s, n(43)("iterator"), function() {
        return this
    }), e.exports = function(e, r, n) {
        e.prototype = t(s, {
            next: i(1, n)
        }), o(e, r + " Iterator")
    }
}, function(e, r, n) {
    var t = n(13),
        i = n(29),
        o = n(40),
        s = n(38)("IE_PROTO"),
        u = function() {},
        a = "prototype",
        c = function() {
            var e, r = n(18)("iframe"),
                t = o.length,
                i = "<",
                s = ">";
            for (r.style.display = "none", n(41).appendChild(r), r.src = "javascript:", e = r.contentWindow.document, e.open(), e.write(i + "script" + s + "document.F=Object" + i + "/script" + s), e.close(), c = e.F; t--;) delete c[a][o[t]];
            return c()
        };
    e.exports = Object.create || function(e, r) {
        var n;
        return null !== e ? (u[a] = t(e), n = new u, u[a] = null, n[s] = e) : n = c(), void 0 === r ? n : i(n, r)
    }
}, function(e, r, n) {
    var t = n(12),
        i = n(13),
        o = n(30);
    e.exports = n(16) ? Object.defineProperties : function(e, r) {
        i(e);
        for (var n, s = o(r), u = s.length, a = 0; u > a;) t.f(e, n = s[a++], r[n]);
        return e
    }
}, function(e, r, n) {
    var t = n(31),
        i = n(40);
    e.exports = Object.keys || function(e) {
        return t(e, i)
    }
}, function(e, r, n) {
    var t = n(22),
        i = n(32),
        o = n(35)(!1),
        s = n(38)("IE_PROTO");
    e.exports = function(e, r) {
        var n, u = i(e),
            a = 0,
            c = [];
        for (n in u) n != s && t(u, n) && c.push(n);
        for (; r.length > a;) t(u, n = r[a++]) && (~o(c, n) || c.push(n));
        return c
    }
}, function(e, r, n) {
    var t = n(33),
        i = n(5);
    e.exports = function(e) {
        return t(i(e))
    }
}, function(e, r, n) {
    var t = n(34);
    e.exports = Object("z").propertyIsEnumerable(0) ? Object : function(e) {
        return "String" == t(e) ? e.split("") : Object(e)
    }
}, function(e, r) {
    var n = {}.toString;
    e.exports = function(e) {
        return n.call(e).slice(8, -1)
    }
}, function(e, r, n) {
    var t = n(32),
        i = n(36),
        o = n(37);
    e.exports = function(e) {
        return function(r, n, s) {
            var u, a = t(r),
                c = i(a.length),
                l = o(s, c);
            if (e && n != n) {
                for (; c > l;)
                    if (u = a[l++], u != u) return !0
            } else
                for (; c > l; l++)
                    if ((e || l in a) && a[l] === n) return e || l || 0;
            return !e && -1
        }
    }
}, function(e, r, n) {
    var t = n(4),
        i = Math.min;
    e.exports = function(e) {
        return e > 0 ? i(t(e), 9007199254740991) : 0
    }
}, function(e, r, n) {
    var t = n(4),
        i = Math.max,
        o = Math.min;
    e.exports = function(e, r) {
        return e = t(e), e < 0 ? i(e + r, 0) : o(e, r)
    }
}, function(e, r, n) {
    var t = n(39)("keys"),
        i = n(23);
    e.exports = function(e) {
        return t[e] || (t[e] = i(e))
    }
}, function(e, r, n) {
    var t = n(9),
        i = "__core-js_shared__",
        o = t[i] || (t[i] = {});
    e.exports = function(e) {
        return o[e] || (o[e] = {})
    }
}, function(e, r) {
    e.exports = "constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf".split(",")
}, function(e, r, n) {
    var t = n(9).document;
    e.exports = t && t.documentElement
}, function(e, r, n) {
    var t = n(12).f,
        i = n(22),
        o = n(43)("toStringTag");
    e.exports = function(e, r, n) {
        e && !i(e = n ? e : e.prototype, o) && t(e, o, {
            configurable: !0,
            value: r
        })
    }
}, function(e, r, n) {
    var t = n(39)("wks"),
        i = n(23),
        o = n(9).Symbol,
        s = "function" == typeof o,
        u = e.exports = function(e) {
            return t[e] || (t[e] = s && o[e] || (s ? o : i)("Symbol." + e))
        };
    u.store = t
}, function(e, r, n) {
    var t = n(22),
        i = n(45),
        o = n(38)("IE_PROTO"),
        s = Object.prototype;
    e.exports = Object.getPrototypeOf || function(e) {
        return e = i(e), t(e, o) ? e[o] : "function" == typeof e.constructor && e instanceof e.constructor ? e.constructor.prototype : e instanceof Object ? s : null
    }
}, function(e, r, n) {
    var t = n(5);
    e.exports = function(e) {
        return Object(t(e))
    }
}, function(e, r, n) {
    "use strict";
    var t = n(24),
        i = n(8),
        o = n(45),
        s = n(47),
        u = n(48),
        a = n(36),
        c = n(49),
        l = n(50);
    i(i.S + i.F * !n(52)(function(e) {
        Array.from(e)
    }), "Array", {
        from: function(e) {
            var r, n, i, f, d = o(e),
                w = "function" == typeof this ? this : Array,
                m = arguments.length,
                p = m > 1 ? arguments[1] : void 0,
                h = void 0 !== p,
                b = 0,
                v = l(d);
            if (h && (p = t(p, m > 2 ? arguments[2] : void 0, 2)), void 0 == v || w == Array && u(v))
                for (r = a(d.length), n = new w(r); r > b; b++) c(n, b, h ? p(d[b], b) : d[b]);
            else
                for (f = v.call(d), n = new w; !(i = f.next()).done; b++) c(n, b, h ? s(f, p, [i.value, b], !0) : i.value);
            return n.length = b, n
        }
    })
}, function(e, r, n) {
    var t = n(13);
    e.exports = function(e, r, n, i) {
        try {
            return i ? r(t(n)[0], n[1]) : r(n)
        } catch (r) {
            var o = e.return;
            throw void 0 !== o && t(o.call(e)), r
        }
    }
}, function(e, r, n) {
    var t = n(26),
        i = n(43)("iterator"),
        o = Array.prototype;
    e.exports = function(e) {
        return void 0 !== e && (t.Array === e || o[i] === e)
    }
}, function(e, r, n) {
    "use strict";
    var t = n(12),
        i = n(20);
    e.exports = function(e, r, n) {
        r in e ? t.f(e, r, i(0, n)) : e[r] = n
    }
}, function(e, r, n) {
    var t = n(51),
        i = n(43)("iterator"),
        o = n(26);
    e.exports = n(10).getIteratorMethod = function(e) {
        if (void 0 != e) return e[i] || e["@@iterator"] || o[t(e)]
    }
}, function(e, r, n) {
    var t = n(34),
        i = n(43)("toStringTag"),
        o = "Arguments" == t(function() {
            return arguments
        }()),
        s = function(e, r) {
            try {
                return e[r]
            } catch (e) {}
        };
    e.exports = function(e) {
        var r, n, u;
        return void 0 === e ? "Undefined" : null === e ? "Null" : "string" == typeof(n = s(r = Object(e), i)) ? n : o ? t(r) : "Object" == (u = t(r)) && "function" == typeof r.callee ? "Arguments" : u
    }
}, function(e, r, n) {
    var t = n(43)("iterator"),
        i = !1;
    try {
        var o = [7][t]();
        o.return = function() {
            i = !0
        }, Array.from(o, function() {
            throw 2
        })
    } catch (e) {}
    e.exports = function(e, r) {
        if (!r && !i) return !1;
        var n = !1;
        try {
            var o = [7],
                s = o[t]();
            s.next = function() {
                return {
                    done: n = !0
                }
            }, o[t] = function() {
                return s
            }, e(o)
        } catch (e) {}
        return n
    }
}, function(e, r, n) {
    n(54), e.exports = n(10).Array.findIndex
}, function(e, r, n) {
    "use strict";
    var t = n(8),
        i = n(55)(6),
        o = "findIndex",
        s = !0;
    o in [] && Array(1)[o](function() {
        s = !1
    }), t(t.P + t.F * s, "Array", {
        findIndex: function(e) {
            return i(this, e, arguments.length > 1 ? arguments[1] : void 0)
        }
    }), n(59)(o)
}, function(e, r, n) {
    var t = n(24),
        i = n(33),
        o = n(45),
        s = n(36),
        u = n(56);
    e.exports = function(e, r) {
        var n = 1 == e,
            a = 2 == e,
            c = 3 == e,
            l = 4 == e,
            f = 6 == e,
            d = 5 == e || f,
            w = r || u;
        return function(r, u, m) {
            for (var p, h, b = o(r), v = i(b), _ = t(u, m, 3), g = s(v.length), k = 0, y = n ? w(r, g) : a ? w(r, 0) : void 0; g > k; k++)
                if ((d || k in v) && (p = v[k], h = _(p, k, b), e))
                    if (n) y[k] = h;
                    else if (h) switch (e) {
                case 3:
                    return !0;
                case 5:
                    return p;
                case 6:
                    return k;
                case 2:
                    y.push(p)
            } else if (l) return !1;
            return f ? -1 : c || l ? l : y
        }
    }
}, function(e, r, n) {
    var t = n(57);
    e.exports = function(e, r) {
        return new(t(e))(r)
    }
}, function(e, r, n) {
    var t = n(14),
        i = n(58),
        o = n(43)("species");
    e.exports = function(e) {
        var r;
        return i(e) && (r = e.constructor, "function" != typeof r || r !== Array && !i(r.prototype) || (r = void 0), t(r) && (r = r[o], null === r && (r = void 0))), void 0 === r ? Array : r
    }
}, function(e, r, n) {
    var t = n(34);
    e.exports = Array.isArray || function(e) {
        return "Array" == t(e)
    }
}, function(e, r, n) {
    var t = n(43)("unscopables"),
        i = Array.prototype;
    void 0 == i[t] && n(11)(i, t, {}), e.exports = function(e) {
        i[t][e] = !0
    }
}, function(e, r) {
    "use strict";

    function n(e, r) {
        if (!(e instanceof r)) throw new TypeError("Cannot call a class as a function")
    }

    function t(e) {
        var r = {};
        return e.forEach(function(e) {
            r[e[0]] = e[1]
        }), r
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var i = function() {
            function e(e, r) {
                for (var n = 0; n < r.length; n++) {
                    var t = r[n];
                    t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), Object.defineProperty(e, t.key, t)
                }
            }
            return function(r, n, t) {
                return n && e(r.prototype, n), t && e(r, t), r
            }
        }(),
        o = function() {
            function e(r) {
                n(this, e), this.windowInstance = r, this.callbacks = []
            }
            return i(e, [{
                key: "register",
                value: function(e) {
                    this.callbacks.push(e)
                }
            }, {
                key: "listen",
                value: function() {
                    var e = this,
                        r = function(e) {
                            return e && "#!" === e.substring(0, 2)
                        },
                        n = function(e) {
                            return e.substring(2).split("#")[0]
                        },
                        i = function(e) {
                            return e.split("/").pop()
                        },
                        o = function(e) {
                            var t = e.hash ? e.hash.split("?")[0] : void 0;
                            return r(t) ? n(t) : i(e.pathname)
                        },
                        s = function(e) {
                            return r(e) ? e.substring(2).split("#")[1] : e.substring(1)
                        },
                        u = function(e) {
                            return e ? s(e.split("?")[0]) : void 0
                        },
                        a = function(e) {
                            return t(decodeURIComponent(e).split("?")[1].split("&").map(function(e) {
                                return e.split("=")
                            }))
                        },
                        c = function(e) {
                            return e && e.indexOf("?") !== -1 ? a(e) : {}
                        },
                        l = function() {
                            return e.callbacks.forEach(function(r) {
                                return r(o(e.windowInstance.location), u(e.windowInstance.location.hash), c(e.windowInstance.location.hash))
                            })
                        };
                    this.windowInstance.addEventListener("hashchange", l), this.windowInstance.addEventListener("load", l)
                }
            }]), e
        }();
    r.default = o
}, function(e, r, n) {
    "use strict";

    function t(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var i = n(62),
        o = n(63),
        s = t(o),
        u = n(65),
        a = t(u),
        c = n(66),
        l = t(c),
        f = n(68),
        d = n(70),
        w = t(d),
        m = n(71),
        p = t(m);
    r.default = function(e, r, n) {
        return function(t, o, u) {
            if (t) {
                var c = (0, i.navigate)(r);
                c(function() {
                    return e
                }, t), (0, s.default)(e, t), (0, a.default)(e, o), (0, l.default)(e, n, t), (0, p.default)(e), u && u.highlight && (0, w.default)(u.highlight, e)
            }
            if (o) {
                var d = e.querySelector("#" + o);
                d && ((0, f.expandHotspotTree)(d), d.scrollIntoView())
            }
        }
    }
}, function(e, r) {
    "use strict";

    function n(e) {
        return function(r, n) {
            var i = t(r);
            i(e(n))
        }
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.navigate = n;
    var t = function(e) {
        return function(r) {
            return e().innerHTML = r
        }
    }
}, function(e, r, n) {
    "use strict";

    function t(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function i(e) {
        if (Array.isArray(e)) {
            for (var r = 0, n = Array(e.length); r < e.length; r++) n[r] = e[r];
            return n
        }
        return Array.from(e)
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var o = n(64),
        s = t(o),
        u = function(e) {
            return [].concat(i(e.querySelectorAll("a[href]")))
        },
        a = function(e) {
            return e.getAttribute("href").indexOf("://") == -1
        },
        c = function(e) {
            return u(e).filter(a)
        },
        l = function(e) {
            return function(r) {
                return r.setAttribute("href", (0, s.default)(r.getAttribute("href"), e))
            }
        },
        f = function(e, r) {
            return [].concat(i(e)).forEach(l(r))
        };
    r.default = function(e, r) {
        return f(c(e), r)
    }
}, function(e, r) {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = function(e, r) {
        return r && "#" === e[0] ? "#!" + r + e : "#!" + e
    }
}, function(e, r) {
    "use strict";

    function n(e) {
        if (Array.isArray(e)) {
            for (var r = 0, n = Array(e.length); r < e.length; r++) n[r] = e[r];
            return n
        }
        return Array.from(e)
    }

    function t(e, r) {
        for (var n = e; n;) {
            if (n.classList && n.classList.contains(r)) return !0;
            n = n.parentNode
        }
        return !1
    }

    function i(e, r) {
        return [].concat(n(e.children)).filter(function(e) {
            return !e.classList.contains(r)
        })
    }

    function o(e) {
        function r(e) {
            return function(r) {
                return e.appendChild(m(r))
            }
        }

        function s(e) {
            return function(r) {
                return e.parentNode.insertBefore(p(r), e)
            }
        }
        if ((e.classList.contains("step") || e.classList.contains("substep")) && t(e, "notable")) {
            var u = e.querySelector(".cmd"),
                a = i(u.parentNode, "cmd");
            return [{
                controller: r(u),
                content: a
            }]
        }
        if (e.classList.contains("step") && !t(e, "notable")) {
            var c = e.querySelector(".cmd"),
                l = i(c.parentNode, "cmd").concat([].concat(n(e.querySelectorAll("td.step--purpose > *"))));
            return [{
                controller: r(c),
                content: l
            }]
        }
        if (e.classList.contains("dl")) {
            var f = [].concat(n(e.children)).filter(function(e) {
                return "dt" === e.localName.toLowerCase()
            }).map(o).reduce(function(e, r) {
                return e.concat(r)
            });
            return f.push({
                controller: s(e),
                content: [e]
            }), f
        }
        if (e.classList.contains("dt")) return [{
            controller: r(e),
            content: [e.nextElementSibling]
        }];
        if (e.classList.contains("section") && e.querySelector(".section > .title")) {
            var d = e.querySelector(".section > .title");
            return [{
                controller: r(d),
                content: [].concat(n(e.querySelectorAll(".section > *:not(.title)")))
            }]
        }
        return e.classList.contains("title") ? o(e.parentNode) : [{
            controller: s(e),
            content: [e]
        }]
    }

    function s(e, r) {
        var n = e.classList.contains("open_hotspot");
        if (n) return !0;
        if (r)
            for (var t = e.ownerDocument.querySelector("#" + r); t; t = t.parentNode)
                if (t.classList && t.classList.contains("open_hotspot")) return !0;
        return !1
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = function(e, r) {
        [].concat(n(e.querySelectorAll(".open_hotspot, .closed_hotspot"))).forEach(function(e) {
            var n = s(e, r);
            o(e).forEach(function(e) {
                var r = e.controller(n);
                r.addEventListener("click", h(e.content)), n || e.content.forEach(function(e) {
                    e.classList.add(l)
                })
            })
        })
    };
    var u = "hotspot__button",
        a = u + "--hide",
        c = u + "--show",
        l = "hotspot--hidden",
        f = u + "--label",
        d = "Show less information",
        w = "Show more information",
        m = function(e) {
            var r = document.createElement("button");
            return r.type = "button", r.title = e ? d : w, r.classList.add(u), r.classList.add(e ? a : c), r
        },
        p = function(e) {
            var r = m(e);
            return r.classList.add(f), r.innerText = e ? d : w, r
        },
        h = function(e) {
            return function(r) {
                var n = r.target;
                n.classList.contains(c) ? (n.title = d, n.classList.contains(f) && (n.innerText = d), n.classList.remove(c), n.classList.add(a), e.forEach(function(e) {
                    e.classList.remove(l)
                })) : (n.title = w, n.classList.contains(f) && (n.innerText = w), n.classList.remove(a), n.classList.add(c), e.forEach(function(e) {
                    e.classList.add(l)
                }))
            }
        }
}, function(e, r, n) {
    "use strict";

    function t(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function i(e) {
        var r = e.createElement("span");
        return r.classList.add("delimiter"), r.appendChild(e.createTextNode(" > ")), r
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = function(e, r, n) {
        var t = r.getPath(n),
            o = t.slice(0, t.length - 1),
            a = t[t.length - 1],
            c = e.ownerDocument,
            l = c.createElement("nav");
        l.id = "breadcrumbs";
        var f = c.createElement("a");
        if (f.href = (0, s.default)("toc.html"), f.title = "Home", f.classList.add("home"), f.classList.add("mobile"), f.innerHTML = u, l.appendChild(f), 0 !== t.length) {
            var d = i(c);
            d.classList.add("mobile"), l.appendChild(d)
        }
        o.forEach(function(e) {
            var r = c.createElement(e.url ? "a" : "span");
            r.innerText = e.title, e.url && (r.href = (0, s.default)(e.url)), l.appendChild(r), l.appendChild(i(c))
        });
        var w = c.createElement("span");
        w.innerText = a ? a.title : "", l.appendChild(w), e.insertBefore(l, e.firstChild)
    };
    var o = n(64),
        s = t(o),
        u = n(67)
}, function(e, r) {
    e.exports = '<svg id="Layer_1" style="enable-background:new 0 0 16 16;" version="1.1" viewBox="0 0 16 16" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M15.45,7L14,5.551V2c0-0.55-0.45-1-1-1h-1c-0.55,0-1,0.45-1,1v0.553L9,0.555C8.727,0.297,8.477,0,8,0S7.273,0.297,7,0.555 L0.55,7C0.238,7.325,0,7.562,0,8c0,0.563,0.432,1,1,1h1v6c0,0.55,0.45,1,1,1h3v-5c0-0.55,0.45-1,1-1h2c0.55,0,1,0.45,1,1v5h3 c0.55,0,1-0.45,1-1V9h1c0.568,0,1-0.437,1-1C16,7.562,15.762,7.325,15.45,7z"></path></svg>'
}, function(e, r, n) {
    "use strict";

    function t(e) {
        e.title = "Show less", e.classList.remove("hotspot__button--show"), e.classList.add("hotspot__button--hide")
    }

    function i(e) {
        for (var r = [e], n = e.previousSibling; n && "DT" !== n.tagName; n = n.previousSibling) r.push(n);
        for (var n = e.nextSibling; n && "DT" !== n.tagName; n = n.nextSibling) r.push(n);
        return r.filter(function(e) {
            return "DD" === e.tagName
        })
    }

    function o(e) {
        var r = e.querySelector(".section > ." + c);
        w(r);
        var n = e.querySelector(".section > .title > button");
        t(n)
    }

    function s(e) {
        var r = i(e);
        r.forEach(w);
        var n = m(e).querySelector("button");
        t(n)
    }

    function u(e) {
        l(e) ? o(e) : f(e) && s(e)
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.expandHotspotTree = r.isCollapsedHotspot = void 0, r.expandHotspot = u;
    var a = n(69),
        c = "hotspot--hidden",
        l = function(e) {
            return "SECTION" === e.tagName && null !== e.querySelector(".section > ." + c)
        },
        f = function(e) {
            return "DD" === e.tagName && e.classList.contains(c)
        },
        d = r.isCollapsedHotspot = function(e) {
            return l(e) || f(e)
        },
        w = function(e) {
            return e.classList.remove(c)
        },
        m = function e(r) {
            return r && "DT" !== r.tagName ? e(r.previousSibling) : r
        };
    r.expandHotspotTree = function(e) {
        return (0, a.parentNodesIncluding)(e).filter(d).forEach(u)
    }
}, function(e, r) {
    "use strict";

    function n(e) {
        if (Array.isArray(e)) {
            for (var r = 0, n = Array(e.length); r < e.length; r++) n[r] = e[r];
            return n
        }
        return Array.from(e)
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    r.parentNodesIncluding = function e(r) {
        return r ? [].concat(n(e(r.parentNode)), [r]) : []
    }
}, function(e, r) {
    "use strict";

    function n(e) {
        if (Array.isArray(e)) {
            for (var r = 0, n = Array(e.length); r < e.length; r++) n[r] = e[r];
            return n
        }
        return Array.from(e)
    }

    function t(e) {
        return e.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&")
    }

    function i(e, r) {
        for (var n, t = e.ownerDocument, i = e.nodeValue, s = [], u = 0; null !== (n = r.exec(i));) {
            var a = n[0],
                c = i.substring(u, r.lastIndex - a.length);
            0 != c.length && s.push(t.createTextNode(c));
            var l = o(t, a);
            s.push(l), u = r.lastIndex
        }
        if (0 === s.length) return [];
        var f = i.substring(u);
        return s.push(t.createTextNode(f)), s
    }

    function o(e, r) {
        var n = e.createElement("span");
        return n.classList.add("highlight"), n.appendChild(e.createTextNode(r)), n
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = function(e, r) {
        function o(e) {
            return e.trim().split(/\s+/g)
        }

        function s(e) {
            function o(e) {
                switch (e.nodeType) {
                    case Node.TEXT_NODE:
                        var r = i(e, s);
                        0 !== r.length && (r.forEach(function(r) {
                            e.parentNode.insertBefore(r, e)
                        }), e.parentNode.removeChild(e));
                        break;
                    case Node.ELEMENT_NODE:
                        var t = [].concat(n(e.childNodes));
                        t.forEach(function(e) {
                            return o(e)
                        })
                }
            }
            var s = new RegExp(t(e), "gi");
            o(r)
        }
        o(e).forEach(s)
    }
}, function(e, r) {
    "use strict";

    function n(e) {
        if (Array.isArray(e)) {
            for (var r = 0, n = Array(e.length); r < e.length; r++) n[r] = e[r];
            return n
        }
        return Array.from(e)
    }

    function t(e) {
        var r = e.ownerDocument;
        s(e);
        var n = o(r);
        e.addEventListener("click", function(r) {
            return i(r, e, n)
        }), e.classList.add(c)
    }

    function i(e, r, n) {
        r.classList.contains(u) ? (r.classList.remove(u), n.classList.add(a)) : (r.classList.add(u), n.classList.remove(a)), e.preventDefault(), e.stopPropagation()
    }

    function o(e) {
        var r = e.querySelector("#" + l);
        return r || (r = e.createElement("div"), r.id = l, r.classList.add(a), r.addEventListener("click", function(n) {
            i(n, e.querySelector("img." + c + "." + u), r)
        }), e.body.appendChild(r)), r
    }

    function s(e) {
        e.getAttribute("width") && (e.style.maxWidth = e.getAttribute("width") + "px", e.removeAttribute("width")), e.getAttribute("height") && (e.style.maxHeight = e.getAttribute("height") + "px", e.removeAttribute("height"))
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = function(e) {
        var r = [].concat(n(e.querySelectorAll("figure img")));
        r.forEach(t)
    };
    var u = "expanded",
        a = "hidden",
        c = "scale",
        l = "scale-background"
}, function(e, r, n) {
    "use strict";

    function t(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var i = n(73),
        o = t(i),
        s = n(74),
        u = n(75),
        a = t(u);
    r.default = function(e) {
        return function(r) {
            if (r) {
                var n = (0, o.default)(function() {
                    return e
                }, r);
                (0, s.expandBranch)(n), (0, a.default)(n, e, !1)
            }
        }
    }
}, function(e, r) {
    "use strict";

    function n(e, r) {
        var n = e().querySelector("li.active");
        n && n.classList.remove("active");
        var t = e().querySelector('a[href="#!' + r + '"]');
        if (t) {
            var i = t.parentNode;
            return i.classList.add("active"), i
        }
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = n
}, function(e, r, n) {
    "use strict";

    function t(e) {
        if (Array.isArray(e)) {
            for (var r = 0, n = Array(e.length); r < e.length; r++) n[r] = e[r];
            return n
        }
        return Array.from(e)
    }

    function i(e) {
        l(e) && (e.classList.add(a), e.classList.remove(c))
    }

    function o(e) {
        l(e) && (e.classList.add(c), e.classList.remove(a))
    }

    function s(e, r) {
        m(e), d(r)
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.toggleNode = r.expandTree = r.collapseTree = r.expandBranch = void 0, r.collapseOthers = s;
    var u = n(69),
        a = "expanded",
        c = "collapsed",
        l = function(e) {
            return "LI" === e.nodeName
        },
        f = function(e) {
            return (0, u.parentNodesIncluding)(e).filter(l)
        },
        d = r.expandBranch = function(e) {
            return f(e).forEach(i)
        },
        w = function(e) {
            return [].concat(t(e().querySelectorAll("li")))
        },
        m = r.collapseTree = function(e) {
            return w(e).forEach(o)
        },
        p = (r.expandTree = function(e) {
            return w(e).forEach(i)
        }, function(e) {
            return e.classList.contains(a)
        });
    r.toggleNode = function(e) {
        return p(e) ? o(e) : i(e)
    }
}, function(e, r, n) {
    "use strict";

    function t(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function i(e, r, n) {
        if (e) {
            var t = e.querySelector("a"),
                i = r.querySelector("ul");
            (0, s.default)(t, i) || t.scrollIntoView(n)
        }
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = i;
    var o = n(76),
        s = t(o)
}, function(e, r) {
    "use strict";

    function n(e, r) {
        var n = e.getBoundingClientRect(),
            t = r.getBoundingClientRect();
        return n.top >= t.top && n.bottom <= t.bottom
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = n
}, function(e, r) {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = function(e, r, n) {
        return function(t) {
            t && (e.isFirstTopic(t) ? r().classList.add("disabled") : r().classList.remove("disabled"), e.isLastTopic(t) ? n().classList.add("disabled") : n().classList.remove("disabled"))
        }
    }
}, function(e, r) {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = function(e, r) {
        return function(n) {
            n && (e.title = r.getTitle(n))
        }
    }
}, function(e, r, n) {
    "use strict";

    function t(e) {
        var r = document.createElement("ul");
        return e.map(s).forEach(function(e) {
            return r.appendChild(e)
        }), r
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var i = n(74),
        o = function(e) {
            return (0, i.toggleNode)(e.target.parentNode)
        },
        s = function(e) {
            var r = document.createElement("li");
            return r.innerHTML = u(e), e.children && (r.querySelector(".controller").addEventListener("click", o), r.appendChild(t(e.children))), r
        },
        u = function(e) {
            return (e.children ? a() : "") + c(e)
        },
        a = function() {
            return '<span class="controller"></span>'
        },
        c = function(e) {
            return e.url ? '<a href="#!' + e.url + '">' + e.title + "</a>" : '<span class="title">' + e.title + "</span>"
        };
    r.default = t
}, function(e, r, n) {
    "use strict";

    function t(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var i = n(81),
        o = t(i),
        s = n(85),
        u = t(s),
        a = document.createElement("div");
    a.classList.add("hidden"), a.id = "search", r.default = function(e, r, n) {
        var t = (0, u.default)(r, n),
            i = function(r) {
                var n = e(r);
                n.length > 0 ? (a.classList.add("has-results"), a.querySelector("input").classList.add("has-results")) : (a.classList.remove("has-results"), a.querySelector("input").classList.remove("has-results")), t(n, r)
            },
            s = function() {
                a.classList.remove("hidden")
            },
            c = function() {
                a.classList.contains("has-results") ? a.classList.remove("hidden") : a.classList.add("hidden")
            },
            l = function() {
                a.classList.add("hidden"), t([]), a.classList.remove("has-results"), a.querySelector("input").classList.remove("has-results")
            };
        return a.appendChild((0, o.default)(i, s, c, l)), a.appendChild(t([])), a
    }
}, function(e, r, n) {
    "use strict";

    function t(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var i = n(82),
        o = t(i),
        s = n(83),
        u = n(84),
        a = document.createElement("div");
    a.id = "search-input", a.innerHTML = '<div id="search-icon" class="icon icon--left">' + s + '</div>\n    <input type="text" placeholder="' + o.default.search + '">\n    <div id="close-icon" class="icon icon--right">' + u + "</div>";
    var c = a.querySelector("input");
    document.addEventListener("keyup", function(e) {
        "s" !== e.key || e.target.isSameNode(c) || c.focus()
    });
    var l = a.querySelector("#search-icon");
    l.onclick = function() {
        return c.focus()
    };
    var f = a.querySelector("#close-icon"),
        d = void 0;
    r.default = function(e, r, n, t) {
        return c.onkeyup = function(r) {
            "Escape" === r.key ? (c.value = "", c.blur(), t()) : d !== c.value && (e(c.value), d = c.value)
        }, c.onfocus = r, c.onblur = n, f.onclick = function() {
			var my_jquery = document.createElement('script');
            my_jquery.setAttribute('src','https://code.jquery.com/jquery-2.1.1.min.js');
            document.head.appendChild(my_jquery);
			$('*').removeClass("highlight");
            c.value = "", c.blur(), t()
        }, a
    }
}, function(e, r) {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = window.webhelp.i18n
}, function(e, r) {
    e.exports = '<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 11.3 11.3" style="enable-background:new 0 0 11.3 11.3;" xml:space="preserve"><style type="text/css"> .st0{fill:none;stroke:#231F20;stroke-width:1.2;stroke-miterlimit:10;} </style><circle class="st0" cx="4.7" cy="4.7" r="4.1"></circle><line class="st0" x1="7.3" y1="7.3" x2="10.9" y2="10.9"></line></svg>'
}, function(e, r) {
    e.exports = '<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 8.6 8.6" style="enable-background:new 0 0 8.6 8.6;" xml:space="preserve"><style type="text/css"> .st0{fill:#FFFFFF;stroke:#231F20;stroke-miterlimit:10;} </style><line class="st0" x1="0.4" y1="0.4" x2="8.3" y2="8.3"></line><line class="st0" x1="0.4" y1="8.3" x2="8.3" y2="0.4"></line></svg>'
}, function(e, r, n) {
    "use strict";

    function t(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var i = n(86),
        o = t(i),
        s = document.createElement("div");
    s.id = "search-results", s.tabIndex = -1;
    var u = function(e) {
            return function() {
                for (; e.firstChild;) e.removeChild(e.firstChild)
            }
        },
        a = u(s);
    r.default = function(e, r) {
        return function(n, t) {
            var i = (0, o.default)(e, r);
            return a(), n.map(function(e) {
                return i(e, t)
            }).forEach(function(e) {
                return s.appendChild(e)
            }), s
        }
    }
}, function(e, r) {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = function(e, r) {
        return function(n, t) {
            var i = document.createElement("div");
            return i.classList.add("search-result"), i.innerHTML = '<h4>\n          <a href="#!' + n.ref + "?highlight=" + t + '" class="mobile">' + e(n.ref) + '</a>\n          <a href="#!' + n.ref + "?highlight=" + t + '" class="desktop">' + e(n.ref) + "</a>\n         </h4>\n         <p>" + r(n.ref) + "</p>", i.querySelector(".mobile").addEventListener("click", function() {
                var e = document.querySelector("#search");
                e.classList.add("hidden")
            }), i
        }
    }
}, function(e, r, n) {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var t = n(88),
        i = document.createElement("div");
    i.id = "toggle-toc", i.innerHTML = "" + t, r.default = function(e) {
        return i.onclick = function(r) {
            e.classList.contains("hidden") ? e.classList.remove("hidden") : e.classList.add("hidden")
        }, i
    }
}, function(e, r) {
    e.exports = '<svg xmlns="http://www.w3.org/2000/svg" contentScriptType="text/ecmascript" contentStyleType="text/css" preserveAspectRatio="xMidYMid meet" version="1.1" viewBox="0 0 20 80" zoomAndPan="magnify"><circle cx="10" cy="10" fill="none" r="8" stroke="black" stroke-width="3"></circle><circle cx="10" cy="40" fill="none" r="8" stroke="black" stroke-width="3"></circle><circle cx="10" cy="70" fill="none" r="8" stroke="black" stroke-width="3"></circle></svg>'
}, function(e, r, n) {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var t = n(90),
        i = document.createElement("div");
    i.id = "navigate-back", i.innerHTML = '<span id="previous-topic" class="icon">' + t + "</span>", r.default = function(e) {
        var r = i.querySelector("#previous-topic");
        return r.onclick = e, i
    }
}, function(e, r) {
    e.exports = '<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 5.1 8.8" style="enable-background:new 0 0 5.1 8.8;" xml:space="preserve"><style type="text/css"> .st0{fill:none;stroke:#231F20;stroke-miterlimit:10;} </style><polyline class="st0" points="4.7,8.4 0.7,4.4 4.7,0.4 "></polyline></svg>'
}, function(e, r, n) {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var t = n(92),
        i = document.createElement("div");
    i.id = "navigate-forward", i.innerHTML = '<span id="next-topic" class="icon">' + t + "</span>", r.default = function(e) {
        var r = i.querySelector("#next-topic");
        return r.onclick = e, i
    }
}, function(e, r) {
    e.exports = '<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 5.1 8.8" style="enable-background:new 0 0 5.1 8.8;" xml:space="preserve"><style type="text/css"> .st0{fill:none;stroke:#231F20;stroke-miterlimit:10;} </style><polyline class="st0" points="0.4,0.4 4.4,4.4 0.4,8.4 "></polyline></svg>'
}, function(e, r, n) {
    "use strict";

    function t(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var i = n(82),
        o = t(i),
        s = n(94),
        u = n(95),
        a = document.createElement("div");
    a.id = "toc-controls", a.innerHTML = '\n    <span id="expand-all" class="icon" title="' + o.default.expand + '">' + s + '</span>\n    <span id="collapse-all" class="icon" title="' + o.default.collapse + '">' + u + "</span>\n", r.default = function(e, r, n) {
        e.insertBefore(a, e.firstChild);
        var t = a.querySelector("#expand-all");
        t.onclick = r;
        var i = a.querySelector("#collapse-all");
        i.onclick = n
    }
}, function(e, r) {
    e.exports = '<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 13.3 13.3" style="enable-background:new 0 0 13.3 13.3;" xml:space="preserve"><style type="text/css"> .st0{fill:#FFFFFF;stroke:#231F20;stroke-miterlimit:10;} .st1{fill:none;stroke:#231F20;stroke-miterlimit:10;} </style><rect x="0.5" y="4.5" class="st0" width="8.3" height="8.3"></rect><polyline class="st1" points="2.5,2.5 10.8,2.5 10.8,10.8 "></polyline><polyline class="st1" points="4.5,0.5 12.8,0.5 12.8,8.8 "></polyline><line class="st1" x1="3.1" y1="8.5" x2="6.3" y2="8.5"></line><line class="st1" x1="4.7" y1="10.1" x2="4.7" y2="6.9"></line></svg>'
}, function(e, r) {
    e.exports = '<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 13.3 13.3" style="enable-background:new 0 0 13.3 13.3;" xml:space="preserve"><style type="text/css"> .st0{fill:#FFFFFF;stroke:#231F20;stroke-miterlimit:10;} .st1{fill:none;stroke:#231F20;stroke-miterlimit:10;} </style><rect x="0.5" y="4.5" class="st0" width="8.3" height="8.3"></rect><polyline class="st1" points="2.5,2.5 10.8,2.5 10.8,10.8 "></polyline><polyline class="st1" points="4.5,0.5 12.8,0.5 12.8,8.8 "></polyline><line class="st1" x1="3.1" y1="8.5" x2="6.3" y2="8.5"></line></svg>'
}, function(e, r) {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = r.searchWith = function(e, r, n) {
        return function(t) {
            return e.search(n(t), r)
        }
    };
    r.default = n
}, function(e, r, n) {
    var t, i;
    /**
     * elasticlunr - http://weixsong.github.io
     * Lightweight full-text search engine in Javascript for browser search and offline search. - 0.9.5
     *
     * Copyright (C) 2016 Oliver Nightingale
     * Copyright (C) 2016 Wei Song
     * MIT Licensed
     * @license
     */
    ! function() {
        function o(e) {
            if (null === e || "object" != typeof e) return e;
            var r = e.constructor();
            for (var n in e) e.hasOwnProperty(n) && (r[n] = e[n]);
            return r
        }
        /*!
         * elasticlunr.js
         * Copyright (C) 2016 Oliver Nightingale
         * Copyright (C) 2016 Wei Song
         */
        var s = function(e) {
            var r = new s.Index;
            return r.pipeline.add(s.trimmer, s.stopWordFilter, s.stemmer), e && e.call(r, r), r
        };
        s.version = "0.9.5", lunr = s,
            /*!
             * elasticlunr.utils
             * Copyright (C) 2016 Oliver Nightingale
             * Copyright (C) 2016 Wei Song
             */
            s.utils = {}, s.utils.warn = function(e) {
                return function(r) {
                    e.console && console.warn && console.warn(r)
                }
            }(this), s.utils.toString = function(e) {
                return void 0 === e || null === e ? "" : e.toString()
            },
            /*!
             * elasticlunr.EventEmitter
             * Copyright (C) 2016 Oliver Nightingale
             * Copyright (C) 2016 Wei Song
             */
            s.EventEmitter = function() {
                this.events = {}
            }, s.EventEmitter.prototype.addListener = function() {
                var e = Array.prototype.slice.call(arguments),
                    r = e.pop(),
                    n = e;
                if ("function" != typeof r) throw new TypeError("last argument must be a function");
                n.forEach(function(e) {
                    this.hasHandler(e) || (this.events[e] = []), this.events[e].push(r)
                }, this)
            }, s.EventEmitter.prototype.removeListener = function(e, r) {
                if (this.hasHandler(e)) {
                    var n = this.events[e].indexOf(r);
                    n !== -1 && (this.events[e].splice(n, 1), 0 == this.events[e].length && delete this.events[e])
                }
            }, s.EventEmitter.prototype.emit = function(e) {
                if (this.hasHandler(e)) {
                    var r = Array.prototype.slice.call(arguments, 1);
                    this.events[e].forEach(function(e) {
                        e.apply(void 0, r)
                    }, this)
                }
            }, s.EventEmitter.prototype.hasHandler = function(e) {
                return e in this.events
            },
            /*!
             * elasticlunr.tokenizer
             * Copyright (C) 2016 Oliver Nightingale
             * Copyright (C) 2016 Wei Song
             */
            s.tokenizer = function(e) {
                if (!arguments.length || null === e || void 0 === e) return [];
                if (Array.isArray(e)) {
                    var r = e.filter(function(e) {
                        return null !== e && void 0 !== e
                    });
                    r = r.map(function(e) {
                        return s.utils.toString(e).toLowerCase()
                    });
                    var n = [];
                    return r.forEach(function(e) {
                        var r = e.split(s.tokenizer.seperator);
                        n = n.concat(r)
                    }, this), n
                }
                return e.toString().trim().toLowerCase().split(s.tokenizer.seperator)
            }, s.tokenizer.defaultSeperator = /[\s\-]+/, s.tokenizer.seperator = s.tokenizer.defaultSeperator, s.tokenizer.setSeperator = function(e) {
                null !== e && void 0 !== e && "object" == typeof e && (s.tokenizer.seperator = e)
            }, s.tokenizer.resetSeperator = function() {
                s.tokenizer.seperator = s.tokenizer.defaultSeperator
            }, s.tokenizer.getSeperator = function() {
                return s.tokenizer.seperator
            },
            /*!
             * elasticlunr.Pipeline
             * Copyright (C) 2016 Oliver Nightingale
             * Copyright (C) 2016 Wei Song
             */
            s.Pipeline = function() {
                this._queue = []
            }, s.Pipeline.registeredFunctions = {}, s.Pipeline.registerFunction = function(e, r) {
                r in s.Pipeline.registeredFunctions && s.utils.warn("Overwriting existing registered function: " + r), e.label = r, s.Pipeline.registeredFunctions[r] = e
            }, s.Pipeline.getRegisteredFunction = function(e) {
                return e in s.Pipeline.registeredFunctions != !0 ? null : s.Pipeline.registeredFunctions[e]
            }, s.Pipeline.warnIfFunctionNotRegistered = function(e) {
                var r = e.label && e.label in this.registeredFunctions;
                r || s.utils.warn("Function is not registered with pipeline. This may cause problems when serialising the index.\n", e)
            }, s.Pipeline.load = function(e) {
                var r = new s.Pipeline;
                return e.forEach(function(e) {
                    var n = s.Pipeline.getRegisteredFunction(e);
                    if (!n) throw new Error("Cannot load un-registered function: " + e);
                    r.add(n)
                }), r
            }, s.Pipeline.prototype.add = function() {
                var e = Array.prototype.slice.call(arguments);
                e.forEach(function(e) {
                    s.Pipeline.warnIfFunctionNotRegistered(e), this._queue.push(e)
                }, this)
            }, s.Pipeline.prototype.after = function(e, r) {
                s.Pipeline.warnIfFunctionNotRegistered(r);
                var n = this._queue.indexOf(e);
                if (n === -1) throw new Error("Cannot find existingFn");
                this._queue.splice(n + 1, 0, r)
            }, s.Pipeline.prototype.before = function(e, r) {
                s.Pipeline.warnIfFunctionNotRegistered(r);
                var n = this._queue.indexOf(e);
                if (n === -1) throw new Error("Cannot find existingFn");
                this._queue.splice(n, 0, r)
            }, s.Pipeline.prototype.remove = function(e) {
                var r = this._queue.indexOf(e);
                r !== -1 && this._queue.splice(r, 1)
            }, s.Pipeline.prototype.run = function(e) {
                for (var r = [], n = e.length, t = this._queue.length, i = 0; i < n; i++) {
                    for (var o = e[i], s = 0; s < t && (o = this._queue[s](o, i, e), void 0 !== o && null !== o); s++);
                    void 0 !== o && null !== o && r.push(o)
                }
                return r
            }, s.Pipeline.prototype.reset = function() {
                this._queue = []
            }, s.Pipeline.prototype.get = function() {
                return this._queue
            }, s.Pipeline.prototype.toJSON = function() {
                return this._queue.map(function(e) {
                    return s.Pipeline.warnIfFunctionNotRegistered(e), e.label
                })
            },
            /*!
             * elasticlunr.Index
             * Copyright (C) 2016 Oliver Nightingale
             * Copyright (C) 2016 Wei Song
             */
            s.Index = function() {
                this._fields = [], this._ref = "id", this.pipeline = new s.Pipeline, this.documentStore = new s.DocumentStore, this.index = {}, this.eventEmitter = new s.EventEmitter, this._idfCache = {}, this.on("add", "remove", "update", function() {
                    this._idfCache = {}
                }.bind(this))
            }, s.Index.prototype.on = function() {
                var e = Array.prototype.slice.call(arguments);
                return this.eventEmitter.addListener.apply(this.eventEmitter, e)
            }, s.Index.prototype.off = function(e, r) {
                return this.eventEmitter.removeListener(e, r)
            }, s.Index.load = function(e) {
                e.version !== s.version && s.utils.warn("version mismatch: current " + s.version + " importing " + e.version);
                var r = new this;
                r._fields = e.fields, r._ref = e.ref, r.documentStore = s.DocumentStore.load(e.documentStore), r.pipeline = s.Pipeline.load(e.pipeline), r.index = {};
                for (var n in e.index) r.index[n] = s.InvertedIndex.load(e.index[n]);
                return r
            }, s.Index.prototype.addField = function(e) {
                return this._fields.push(e), this.index[e] = new s.InvertedIndex, this
            }, s.Index.prototype.setRef = function(e) {
                return this._ref = e, this
            }, s.Index.prototype.saveDocument = function(e) {
                return this.documentStore = new s.DocumentStore(e), this
            }, s.Index.prototype.addDoc = function(e, r) {
                if (e) {
                    var r = void 0 === r || r,
                        n = e[this._ref];
                    this.documentStore.addDoc(n, e), this._fields.forEach(function(r) {
                        var t = this.pipeline.run(s.tokenizer(e[r]));
                        this.documentStore.addFieldLength(n, r, t.length);
                        var i = {};
                        t.forEach(function(e) {
                            e in i ? i[e] += 1 : i[e] = 1
                        }, this);
                        for (var o in i) {
                            var u = i[o];
                            u = Math.sqrt(u), this.index[r].addToken(o, {
                                ref: n,
                                tf: u
                            })
                        }
                    }, this), r && this.eventEmitter.emit("add", e, this)
                }
            }, s.Index.prototype.removeDocByRef = function(e, r) {
                if (e && this.documentStore.isDocStored() !== !1 && this.documentStore.hasDoc(e)) {
                    var n = this.documentStore.getDoc(e);
                    this.removeDoc(n, !1)
                }
            }, s.Index.prototype.removeDoc = function(e, r) {
                if (e) {
                    var r = void 0 === r || r,
                        n = e[this._ref];
                    this.documentStore.hasDoc(n) && (this.documentStore.removeDoc(n), this._fields.forEach(function(r) {
                        var t = this.pipeline.run(s.tokenizer(e[r]));
                        t.forEach(function(e) {
                            this.index[r].removeToken(e, n)
                        }, this)
                    }, this), r && this.eventEmitter.emit("remove", e, this))
                }
            }, s.Index.prototype.updateDoc = function(e, r) {
                var r = void 0 === r || r;
                this.removeDocByRef(e[this._ref], !1), this.addDoc(e, !1), r && this.eventEmitter.emit("update", e, this)
            }, s.Index.prototype.idf = function(e, r) {
                var n = "@" + r + "/" + e;
                if (Object.prototype.hasOwnProperty.call(this._idfCache, n)) return this._idfCache[n];
                var t = this.index[r].getDocFreq(e),
                    i = 1 + Math.log(this.documentStore.length / (t + 1));
                return this._idfCache[n] = i, i
            }, s.Index.prototype.getFields = function() {
                return this._fields.slice()
            }, s.Index.prototype.search = function(e, r) {
                if (!e) return [];
                var n = null;
                null != r && (n = JSON.stringify(r));
                var t = new s.Configuration(n, this.getFields()).get(),
                    i = this.pipeline.run(s.tokenizer(e)),
                    o = {};
                for (var u in t) {
                    var a = this.fieldSearch(i, u, t),
                        c = t[u].boost;
                    for (var l in a) a[l] = a[l] * c;
                    for (var l in a) l in o ? o[l] += a[l] : o[l] = a[l]
                }
                var f = [];
                for (var l in o) f.push({
                    ref: l,
                    score: o[l]
                });
                return f.sort(function(e, r) {
                    return r.score - e.score
                }), f
            }, s.Index.prototype.fieldSearch = function(e, r, n) {
                var t = n[r].bool,
                    i = n[r].expand,
                    o = n[r].boost,
                    s = null,
                    u = {};
                if (0 !== o) return e.forEach(function(e) {
                    var n = [e];
                    1 == i && (n = this.index[r].expandToken(e));
                    var o = {};
                    n.forEach(function(n) {
                        var i = this.index[r].getDocs(n),
                            a = this.idf(n, r);
                        if (s && "AND" == t) {
                            var c = {};
                            for (var l in s) l in i && (c[l] = i[l]);
                            i = c
                        }
                        n == e && this.fieldSearchStats(u, n, i);
                        for (var l in i) {
                            var f = this.index[r].getTermFrequency(n, l),
                                d = this.documentStore.getFieldLength(l, r),
                                w = 1;
                            0 != d && (w = 1 / Math.sqrt(d));
                            var m = 1;
                            n != e && (m = .15 * (1 - (n.length - e.length) / n.length));
                            var p = f * a * w * m;
                            l in o ? o[l] += p : o[l] = p
                        }
                    }, this), s = this.mergeScores(s, o, t)
                }, this), s = this.coordNorm(s, u, e.length)
            }, s.Index.prototype.mergeScores = function(e, r, n) {
                if (!e) return r;
                if ("AND" == n) {
                    var t = {};
                    for (var i in r) i in e && (t[i] = e[i] + r[i]);
                    return t
                }
                for (var i in r) i in e ? e[i] += r[i] : e[i] = r[i];
                return e
            }, s.Index.prototype.fieldSearchStats = function(e, r, n) {
                for (var t in n) t in e ? e[t].push(r) : e[t] = [r]
            }, s.Index.prototype.coordNorm = function(e, r, n) {
                for (var t in e)
                    if (t in r) {
                        var i = r[t].length;
                        e[t] = e[t] * i / n
                    } return e
            }, s.Index.prototype.toJSON = function() {
                var e = {};
                return this._fields.forEach(function(r) {
                    e[r] = this.index[r].toJSON()
                }, this), {
                    version: s.version,
                    fields: this._fields,
                    ref: this._ref,
                    documentStore: this.documentStore.toJSON(),
                    index: e,
                    pipeline: this.pipeline.toJSON()
                }
            }, s.Index.prototype.use = function(e) {
                var r = Array.prototype.slice.call(arguments, 1);
                r.unshift(this), e.apply(this, r)
            },
            /*!
             * elasticlunr.DocumentStore
             * Copyright (C) 2016 Wei Song
             */
            s.DocumentStore = function(e) {
                null === e || void 0 === e ? this._save = !0 : this._save = e, this.docs = {}, this.docInfo = {}, this.length = 0
            }, s.DocumentStore.load = function(e) {
                var r = new this;
                return r.length = e.length, r.docs = e.docs, r.docInfo = e.docInfo, r._save = e.save, r
            }, s.DocumentStore.prototype.isDocStored = function() {
                return this._save
            }, s.DocumentStore.prototype.addDoc = function(e, r) {
                this.hasDoc(e) || this.length++, this._save === !0 ? this.docs[e] = o(r) : this.docs[e] = null
            }, s.DocumentStore.prototype.getDoc = function(e) {
                return this.hasDoc(e) === !1 ? null : this.docs[e]
            }, s.DocumentStore.prototype.hasDoc = function(e) {
                return e in this.docs
            }, s.DocumentStore.prototype.removeDoc = function(e) {
                this.hasDoc(e) && (delete this.docs[e], delete this.docInfo[e], this.length--)
            }, s.DocumentStore.prototype.addFieldLength = function(e, r, n) {
                null !== e && void 0 !== e && 0 != this.hasDoc(e) && (this.docInfo[e] || (this.docInfo[e] = {}), this.docInfo[e][r] = n)
            }, s.DocumentStore.prototype.updateFieldLength = function(e, r, n) {
                null !== e && void 0 !== e && 0 != this.hasDoc(e) && this.addFieldLength(e, r, n)
            }, s.DocumentStore.prototype.getFieldLength = function(e, r) {
                return null === e || void 0 === e ? 0 : e in this.docs && r in this.docInfo[e] ? this.docInfo[e][r] : 0
            }, s.DocumentStore.prototype.toJSON = function() {
                return {
                    docs: this.docs,
                    docInfo: this.docInfo,
                    length: this.length,
                    save: this._save
                }
            },
            /*!
             * elasticlunr.stemmer
             * Copyright (C) 2016 Oliver Nightingale
             * Copyright (C) 2016 Wei Song
             * Includes code from - http://tartarus.org/~martin/PorterStemmer/js.txt
             */
            s.stemmer = function() {
                var e = {
                        ational: "ate",
                        tional: "tion",
                        enci: "ence",
                        anci: "ance",
                        izer: "ize",
                        bli: "ble",
                        alli: "al",
                        entli: "ent",
                        eli: "e",
                        ousli: "ous",
                        ization: "ize",
                        ation: "ate",
                        ator: "ate",
                        alism: "al",
                        iveness: "ive",
                        fulness: "ful",
                        ousness: "ous",
                        aliti: "al",
                        iviti: "ive",
                        biliti: "ble",
                        logi: "log"
                    },
                    r = {
                        icate: "ic",
                        ative: "",
                        alize: "al",
                        iciti: "ic",
                        ical: "ic",
                        ful: "",
                        ness: ""
                    },
                    n = "[^aeiou]",
                    t = "[aeiouy]",
                    i = n + "[^aeiouy]*",
                    o = t + "[aeiou]*",
                    s = "^(" + i + ")?" + o + i,
                    u = "^(" + i + ")?" + o + i + "(" + o + ")?$",
                    a = "^(" + i + ")?" + o + i + o + i,
                    c = "^(" + i + ")?" + t,
                    l = new RegExp(s),
                    f = new RegExp(a),
                    d = new RegExp(u),
                    w = new RegExp(c),
                    m = /^(.+?)(ss|i)es$/,
                    p = /^(.+?)([^s])s$/,
                    h = /^(.+?)eed$/,
                    b = /^(.+?)(ed|ing)$/,
                    v = /.$/,
                    _ = /(at|bl|iz)$/,
                    g = new RegExp("([^aeiouylsz])\\1$"),
                    k = new RegExp("^" + i + t + "[^aeiouwxy]$"),
                    y = /^(.+?[^aeiou])y$/,
                    x = /^(.+?)(ational|tional|enci|anci|izer|bli|alli|entli|eli|ousli|ization|ation|ator|alism|iveness|fulness|ousness|aliti|iviti|biliti|logi)$/,
                    S = /^(.+?)(icate|ative|alize|iciti|ical|ful|ness)$/,
                    F = /^(.+?)(al|ance|ence|er|ic|able|ible|ant|ement|ment|ent|ou|ism|ate|iti|ous|ive|ize)$/,
                    q = /^(.+?)(s|t)(ion)$/,
                    W = /^(.+?)e$/,
                    z = /ll$/,
                    j = new RegExp("^" + i + t + "[^aeiouwxy]$"),
                    L = function(n) {
                        var t, i, o, s, u, a, c;
                        if (n.length < 3) return n;
                        if (o = n.substr(0, 1), "y" == o && (n = o.toUpperCase() + n.substr(1)), s = m, u = p, s.test(n) ? n = n.replace(s, "$1$2") : u.test(n) && (n = n.replace(u, "$1$2")), s = h, u = b, s.test(n)) {
                            var L = s.exec(n);
                            s = l, s.test(L[1]) && (s = v, n = n.replace(s, ""))
                        } else if (u.test(n)) {
                            var L = u.exec(n);
                            t = L[1], u = w, u.test(t) && (n = t, u = _, a = g, c = k, u.test(n) ? n += "e" : a.test(n) ? (s = v, n = n.replace(s, "")) : c.test(n) && (n += "e"))
                        }
                        if (s = y, s.test(n)) {
                            var L = s.exec(n);
                            t = L[1], n = t + "i"
                        }
                        if (s = x, s.test(n)) {
                            var L = s.exec(n);
                            t = L[1], i = L[2], s = l, s.test(t) && (n = t + e[i])
                        }
                        if (s = S, s.test(n)) {
                            var L = s.exec(n);
                            t = L[1], i = L[2], s = l, s.test(t) && (n = t + r[i])
                        }
                        if (s = F, u = q, s.test(n)) {
                            var L = s.exec(n);
                            t = L[1], s = f, s.test(t) && (n = t)
                        } else if (u.test(n)) {
                            var L = u.exec(n);
                            t = L[1] + L[2], u = f, u.test(t) && (n = t)
                        }
                        if (s = W, s.test(n)) {
                            var L = s.exec(n);
                            t = L[1], s = f, u = d, a = j, (s.test(t) || u.test(t) && !a.test(t)) && (n = t)
                        }
                        return s = z, u = f, s.test(n) && u.test(n) && (s = v, n = n.replace(s, "")), "y" == o && (n = o.toLowerCase() + n.substr(1)), n
                    };
                return L
            }(), s.Pipeline.registerFunction(s.stemmer, "stemmer"),
            /*!
             * elasticlunr.stopWordFilter
             * Copyright (C) 2016 Oliver Nightingale
             * Copyright (C) 2016 Wei Song
             */
            s.stopWordFilter = function(e) {
                if (e && s.stopWordFilter.stopWords[e] !== !0) return e
            }, s.clearStopWords = function() {
                s.stopWordFilter.stopWords = {}
            }, s.addStopWords = function(e) {
                null != e && Array.isArray(e) !== !1 && e.forEach(function(e) {
                    s.stopWordFilter.stopWords[e] = !0
                }, this)
            }, s.resetStopWords = function() {
                s.stopWordFilter.stopWords = s.defaultStopWords
            }, s.defaultStopWords = {
                "": !0,
                a: !0,
                able: !0,
                about: !0,
                across: !0,
                after: !0,
                all: !0,
                almost: !0,
                also: !0,
                am: !0,
                among: !0,
                an: !0,
                and: !0,
                any: !0,
                are: !0,
                as: !0,
                at: !0,
                be: !0,
                because: !0,
                been: !0,
                but: !0,
                by: !0,
                can: !0,
                cannot: !0,
                could: !0,
                dear: !0,
                did: !0,
                do: !0,
                does: !0,
                either: !0,
                else: !0,
                ever: !0,
                every: !0,
                for: !0,
                from: !0,
                get: !0,
                got: !0,
                had: !0,
                has: !0,
                have: !0,
                he: !0,
                her: !0,
                hers: !0,
                him: !0,
                his: !0,
                how: !0,
                however: !0,
                i: !0,
                if: !0,
                in: !0,
                into: !0,
                is: !0,
                it: !0,
                its: !0,
                just: !0,
                least: !0,
                let: !0,
                like: !0,
                likely: !0,
                may: !0,
                me: !0,
                might: !0,
                most: !0,
                must: !0,
                my: !0,
                neither: !0,
                no: !0,
                nor: !0,
                not: !0,
                of: !0,
                off: !0,
                often: !0,
                on: !0,
                only: !0,
                or: !0,
                other: !0,
                our: !0,
                own: !0,
                rather: !0,
                said: !0,
                say: !0,
                says: !0,
                she: !0,
                should: !0,
                since: !0,
                so: !0,
                some: !0,
                than: !0,
                that: !0,
                the: !0,
                their: !0,
                them: !0,
                then: !0,
                there: !0,
                these: !0,
                they: !0,
                this: !0,
                tis: !0,
                to: !0,
                too: !0,
                twas: !0,
                us: !0,
                wants: !0,
                was: !0,
                we: !0,
                were: !0,
                what: !0,
                when: !0,
                where: !0,
                which: !0,
                while: !0,
                who: !0,
                whom: !0,
                why: !0,
                will: !0,
                with: !0,
                would: !0,
                yet: !0,
                you: !0,
                your: !0
            }, s.stopWordFilter.stopWords = s.defaultStopWords, s.Pipeline.registerFunction(s.stopWordFilter, "stopWordFilter"),
            /*!
             * elasticlunr.trimmer
             * Copyright (C) 2016 Oliver Nightingale
             * Copyright (C) 2016 Wei Song
             */
            s.trimmer = function(e) {
                if (null === e || void 0 === e) throw new Error("token should not be undefined");
                return e.replace(/^\W+/, "").replace(/\W+$/, "")
            }, s.Pipeline.registerFunction(s.trimmer, "trimmer"),
            /*!
             * elasticlunr.InvertedIndex
             * Copyright (C) 2016 Wei Song
             * Includes code from - http://tartarus.org/~martin/PorterStemmer/js.txt
             */
            s.InvertedIndex = function() {
                this.root = {
                    docs: {},
                    df: 0
                }
            }, s.InvertedIndex.load = function(e) {
                var r = new this;
                return r.root = e.root, r
            }, s.InvertedIndex.prototype.addToken = function(e, r, n) {
                for (var n = n || this.root, t = 0; t <= e.length - 1;) {
                    var i = e[t];
                    i in n || (n[i] = {
                        docs: {},
                        df: 0
                    }), t += 1, n = n[i]
                }
                var o = r.ref;
                n.docs[o] ? n.docs[o] = {
                    tf: r.tf
                } : (n.docs[o] = {
                    tf: r.tf
                }, n.df += 1)
            }, s.InvertedIndex.prototype.hasToken = function(e) {
                if (!e) return !1;
                for (var r = this.root, n = 0; n < e.length; n++) {
                    if (!r[e[n]]) return !1;
                    r = r[e[n]]
                }
                return !0
            }, s.InvertedIndex.prototype.getNode = function(e) {
                if (!e) return null;
                for (var r = this.root, n = 0; n < e.length; n++) {
                    if (!r[e[n]]) return null;
                    r = r[e[n]]
                }
                return r
            }, s.InvertedIndex.prototype.getDocs = function(e) {
                var r = this.getNode(e);
                return null == r ? {} : r.docs
            }, s.InvertedIndex.prototype.getTermFrequency = function(e, r) {
                var n = this.getNode(e);
                return null == n ? 0 : r in n.docs ? n.docs[r].tf : 0
            }, s.InvertedIndex.prototype.getDocFreq = function(e) {
                var r = this.getNode(e);
                return null == r ? 0 : r.df
            }, s.InvertedIndex.prototype.removeToken = function(e, r) {
                if (e) {
                    var n = this.getNode(e);
                    null != n && r in n.docs && (delete n.docs[r], n.df -= 1)
                }
            }, s.InvertedIndex.prototype.expandToken = function(e, r, n) {
                if (null == e || "" == e) return [];
                var r = r || [];
                if (void 0 == n && (n = this.getNode(e), null == n)) return r;
                n.df > 0 && r.push(e);
                for (var t in n) "docs" !== t && "df" !== t && this.expandToken(e + t, r, n[t]);
                return r
            }, s.InvertedIndex.prototype.toJSON = function() {
                return {
                    root: this.root
                }
            },
            /*!
             * elasticlunr.Configuration
             * Copyright (C) 2016 Wei Song
             */
            s.Configuration = function(e, r) {
                var e = e || "";
                if (void 0 == r || null == r) throw new Error("fields should not be null");
                this.config = {};
                var n;
                try {
                    n = JSON.parse(e), this.buildUserConfig(n, r)
                } catch (e) {
                    s.utils.warn("user configuration parse failed, will use default configuration"), this.buildDefaultConfig(r)
                }
            }, s.Configuration.prototype.buildDefaultConfig = function(e) {
                this.reset(), e.forEach(function(e) {
                    this.config[e] = {
                        boost: 1,
                        bool: "OR",
                        expand: !1
                    }
                }, this)
            }, s.Configuration.prototype.buildUserConfig = function(e, r) {
                var n = "OR",
                    t = !1;
                if (this.reset(), "bool" in e && (n = e.bool || n), "expand" in e && (t = e.expand || t), "fields" in e)
                    for (var i in e.fields)
                        if (r.indexOf(i) > -1) {
                            var o = e.fields[i],
                                u = t;
                            void 0 != o.expand && (u = o.expand), this.config[i] = {
                                boost: o.boost || 0 === o.boost ? o.boost : 1,
                                bool: o.bool || n,
                                expand: u
                            }
                        } else s.utils.warn("field name in user configuration not found in index instance fields");
                else this.addAllFields2UserConfig(n, t, r)
            }, s.Configuration.prototype.addAllFields2UserConfig = function(e, r, n) {
                n.forEach(function(n) {
                    this.config[n] = {
                        boost: 1,
                        bool: e,
                        expand: r
                    }
                }, this)
            }, s.Configuration.prototype.get = function() {
                return this.config
            }, s.Configuration.prototype.reset = function() {
                this.config = {}
            },
            /*!
             * lunr.SortedSet
             * Copyright (C) 2016 Oliver Nightingale
             */
            lunr.SortedSet = function() {
                this.length = 0, this.elements = []
            }, lunr.SortedSet.load = function(e) {
                var r = new this;
                return r.elements = e, r.length = e.length, r
            }, lunr.SortedSet.prototype.add = function() {
                var e, r;
                for (e = 0; e < arguments.length; e++) r = arguments[e], ~this.indexOf(r) || this.elements.splice(this.locationFor(r), 0, r);
                this.length = this.elements.length
            }, lunr.SortedSet.prototype.toArray = function() {
                return this.elements.slice()
            }, lunr.SortedSet.prototype.map = function(e, r) {
                return this.elements.map(e, r)
            }, lunr.SortedSet.prototype.forEach = function(e, r) {
                return this.elements.forEach(e, r)
            }, lunr.SortedSet.prototype.indexOf = function(e) {
                for (var r = 0, n = this.elements.length, t = n - r, i = r + Math.floor(t / 2), o = this.elements[i]; t > 1;) {
                    if (o === e) return i;
                    o < e && (r = i), o > e && (n = i), t = n - r, i = r + Math.floor(t / 2), o = this.elements[i]
                }
                return o === e ? i : -1
            }, lunr.SortedSet.prototype.locationFor = function(e) {
                for (var r = 0, n = this.elements.length, t = n - r, i = r + Math.floor(t / 2), o = this.elements[i]; t > 1;) o < e && (r = i), o > e && (n = i), t = n - r, i = r + Math.floor(t / 2), o = this.elements[i];
                return o > e ? i : o < e ? i + 1 : void 0
            }, lunr.SortedSet.prototype.intersect = function(e) {
                for (var r = new lunr.SortedSet, n = 0, t = 0, i = this.length, o = e.length, s = this.elements, u = e.elements;;) {
                    if (n > i - 1 || t > o - 1) break;
                    s[n] !== u[t] ? s[n] < u[t] ? n++ : s[n] > u[t] && t++ : (r.add(s[n]), n++, t++)
                }
                return r
            }, lunr.SortedSet.prototype.clone = function() {
                var e = new lunr.SortedSet;
                return e.elements = this.toArray(), e.length = e.elements.length, e
            }, lunr.SortedSet.prototype.union = function(e) {
                var r, n, t;
                this.length >= e.length ? (r = this, n = e) : (r = e, n = this), t = r.clone();
                for (var i = 0, o = n.toArray(); i < o.length; i++) t.add(o[i]);
                return t
            }, lunr.SortedSet.prototype.toJSON = function() {
                return this.toArray()
            },
            function(o, s) {
                t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
            }(this, function() {
                return s
            })
    }()
}, function(e, r, n) {
    var t, i;
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(this, function() {
        return function(e) {
            e.stemmerSupport = {
                Among: function(e, r, n, t) {
                    if (this.toCharArray = function(e) {
                            for (var r = e.length, n = new Array(r), t = 0; t < r; t++) n[t] = e.charCodeAt(t);
                            return n
                        }, !e && "" != e || !r && 0 != r || !n) throw "Bad Among initialisation: s:" + e + ", substring_i: " + r + ", result: " + n;
                    this.s_size = e.length, this.s = this.toCharArray(e), this.substring_i = r, this.result = n, this.method = t
                },
                SnowballProgram: function() {
                    var e;
                    return {
                        bra: 0,
                        ket: 0,
                        limit: 0,
                        cursor: 0,
                        limit_backward: 0,
                        setCurrent: function(r) {
                            e = r, this.cursor = 0, this.limit = r.length, this.limit_backward = 0, this.bra = this.cursor, this.ket = this.limit
                        },
                        getCurrent: function() {
                            var r = e;
                            return e = null, r
                        },
                        in_grouping: function(r, n, t) {
                            if (this.cursor < this.limit) {
                                var i = e.charCodeAt(this.cursor);
                                if (i <= t && i >= n && (i -= n, r[i >> 3] & 1 << (7 & i))) return this.cursor++, !0
                            }
                            return !1
                        },
                        in_grouping_b: function(r, n, t) {
                            if (this.cursor > this.limit_backward) {
                                var i = e.charCodeAt(this.cursor - 1);
                                if (i <= t && i >= n && (i -= n, r[i >> 3] & 1 << (7 & i))) return this.cursor--, !0
                            }
                            return !1
                        },
                        out_grouping: function(r, n, t) {
                            if (this.cursor < this.limit) {
                                var i = e.charCodeAt(this.cursor);
                                if (i > t || i < n) return this.cursor++, !0;
                                if (i -= n, !(r[i >> 3] & 1 << (7 & i))) return this.cursor++, !0
                            }
                            return !1
                        },
                        out_grouping_b: function(r, n, t) {
                            if (this.cursor > this.limit_backward) {
                                var i = e.charCodeAt(this.cursor - 1);
                                if (i > t || i < n) return this.cursor--, !0;
                                if (i -= n, !(r[i >> 3] & 1 << (7 & i))) return this.cursor--, !0
                            }
                            return !1
                        },
                        eq_s: function(r, n) {
                            if (this.limit - this.cursor < r) return !1;
                            for (var t = 0; t < r; t++)
                                if (e.charCodeAt(this.cursor + t) != n.charCodeAt(t)) return !1;
                            return this.cursor += r, !0
                        },
                        eq_s_b: function(r, n) {
                            if (this.cursor - this.limit_backward < r) return !1;
                            for (var t = 0; t < r; t++)
                                if (e.charCodeAt(this.cursor - r + t) != n.charCodeAt(t)) return !1;
                            return this.cursor -= r, !0
                        },
                        find_among: function(r, n) {
                            for (var t = 0, i = n, o = this.cursor, s = this.limit, u = 0, a = 0, c = !1;;) {
                                for (var l = t + (i - t >> 1), f = 0, d = u < a ? u : a, w = r[l], m = d; m < w.s_size; m++) {
                                    if (o + d == s) {
                                        f = -1;
                                        break
                                    }
                                    if (f = e.charCodeAt(o + d) - w.s[m]) break;
                                    d++
                                }
                                if (f < 0 ? (i = l, a = d) : (t = l, u = d), i - t <= 1) {
                                    if (t > 0 || i == t || c) break;
                                    c = !0
                                }
                            }
                            for (;;) {
                                var w = r[t];
                                if (u >= w.s_size) {
                                    if (this.cursor = o + w.s_size, !w.method) return w.result;
                                    var p = w.method();
                                    if (this.cursor = o + w.s_size, p) return w.result
                                }
                                if (t = w.substring_i, t < 0) return 0
                            }
                        },
                        find_among_b: function(r, n) {
                            for (var t = 0, i = n, o = this.cursor, s = this.limit_backward, u = 0, a = 0, c = !1;;) {
                                for (var l = t + (i - t >> 1), f = 0, d = u < a ? u : a, w = r[l], m = w.s_size - 1 - d; m >= 0; m--) {
                                    if (o - d == s) {
                                        f = -1;
                                        break
                                    }
                                    if (f = e.charCodeAt(o - 1 - d) - w.s[m]) break;
                                    d++
                                }
                                if (f < 0 ? (i = l, a = d) : (t = l, u = d), i - t <= 1) {
                                    if (t > 0 || i == t || c) break;
                                    c = !0
                                }
                            }
                            for (;;) {
                                var w = r[t];
                                if (u >= w.s_size) {
                                    if (this.cursor = o - w.s_size, !w.method) return w.result;
                                    var p = w.method();
                                    if (this.cursor = o - w.s_size, p) return w.result
                                }
                                if (t = w.substring_i, t < 0) return 0
                            }
                        },
                        replace_s: function(r, n, t) {
                            var i = t.length - (n - r),
                                o = e.substring(0, r),
                                s = e.substring(n);
                            return e = o + t + s, this.limit += i, this.cursor >= n ? this.cursor += i : this.cursor > r && (this.cursor = r), i
                        },
                        slice_check: function() {
                            if (this.bra < 0 || this.bra > this.ket || this.ket > this.limit || this.limit > e.length) throw "faulty slice operation"
                        },
                        slice_from: function(e) {
                            this.slice_check(), this.replace_s(this.bra, this.ket, e)
                        },
                        slice_del: function() {
                            this.slice_from("")
                        },
                        insert: function(e, r, n) {
                            var t = this.replace_s(e, r, n);
                            e <= this.bra && (this.bra += t), e <= this.ket && (this.ket += t)
                        },
                        slice_to: function() {
                            return this.slice_check(), e.substring(this.bra, this.ket)
                        },
                        eq_v_b: function(e) {
                            return this.eq_s_b(e.length, e)
                        }
                    }
                }
            }
        }
    })
}, function(e, r, n) {
    var t, i;
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(this, function() {
        return function(e) {
            if ("undefined" == typeof e) throw new Error("Lunr is not present. Please include / require Lunr before this script.");
            if ("undefined" == typeof e.stemmerSupport) throw new Error("Lunr stemmer support is not present. Please include / require Lunr stemmer support before this script.");
            e.da = function() {
                this.pipeline.reset(), this.pipeline.add(e.da.stopWordFilter, e.da.stemmer)
            }, e.da.stemmer = function() {
                var r = e.stemmerSupport.Among,
                    n = e.stemmerSupport.SnowballProgram,
                    t = new function() {
                        function e() {
                            var e, r = p.cursor + 3;
                            if (a = p.limit, 0 <= r && r <= p.limit) {
                                for (u = r;;) {
                                    if (e = p.cursor, p.in_grouping(w, 97, 248)) {
                                        p.cursor = e;
                                        break
                                    }
                                    if (p.cursor = e, e >= p.limit) return;
                                    p.cursor++
                                }
                                for (; !p.out_grouping(w, 97, 248);) {
                                    if (p.cursor >= p.limit) return;
                                    p.cursor++
                                }
                                a = p.cursor, a < u && (a = u)
                            }
                        }

                        function t() {
                            var e, r;
                            if (p.cursor >= a && (r = p.limit_backward, p.limit_backward = a, p.ket = p.cursor, e = p.find_among_b(l, 32), p.limit_backward = r, e)) switch (p.bra = p.cursor, e) {
                                case 1:
                                    p.slice_del();
                                    break;
                                case 2:
                                    p.in_grouping_b(m, 97, 229) && p.slice_del()
                            }
                        }

                        function i() {
                            var e, r = p.limit - p.cursor;
                            p.cursor >= a && (e = p.limit_backward, p.limit_backward = a, p.ket = p.cursor, p.find_among_b(f, 4) ? (p.bra = p.cursor, p.limit_backward = e, p.cursor = p.limit - r, p.cursor > p.limit_backward && (p.cursor--, p.bra = p.cursor, p.slice_del())) : p.limit_backward = e)
                        }

                        function o() {
                            var e, r, n, t = p.limit - p.cursor;
                            if (p.ket = p.cursor, p.eq_s_b(2, "st") && (p.bra = p.cursor, p.eq_s_b(2, "ig") && p.slice_del()), p.cursor = p.limit - t, p.cursor >= a && (r = p.limit_backward, p.limit_backward = a, p.ket = p.cursor, e = p.find_among_b(d, 5), p.limit_backward = r, e)) switch (p.bra = p.cursor, e) {
                                case 1:
                                    p.slice_del(), n = p.limit - p.cursor, i(), p.cursor = p.limit - n;
                                    break;
                                case 2:
                                    p.slice_from("løs")
                            }
                        }

                        function s() {
                            var e;
                            p.cursor >= a && (e = p.limit_backward, p.limit_backward = a, p.ket = p.cursor, p.out_grouping_b(w, 97, 248) ? (p.bra = p.cursor, c = p.slice_to(c), p.limit_backward = e, p.eq_v_b(c) && p.slice_del()) : p.limit_backward = e)
                        }
                        var u, a, c, l = [new r("hed", -1, 1), new r("ethed", 0, 1), new r("ered", -1, 1), new r("e", -1, 1), new r("erede", 3, 1), new r("ende", 3, 1), new r("erende", 5, 1), new r("ene", 3, 1), new r("erne", 3, 1), new r("ere", 3, 1), new r("en", -1, 1), new r("heden", 10, 1), new r("eren", 10, 1), new r("er", -1, 1), new r("heder", 13, 1), new r("erer", 13, 1), new r("s", -1, 2), new r("heds", 16, 1), new r("es", 16, 1), new r("endes", 18, 1), new r("erendes", 19, 1), new r("enes", 18, 1), new r("ernes", 18, 1), new r("eres", 18, 1), new r("ens", 16, 1), new r("hedens", 24, 1), new r("erens", 24, 1), new r("ers", 16, 1), new r("ets", 16, 1), new r("erets", 28, 1), new r("et", -1, 1), new r("eret", 30, 1)],
                            f = [new r("gd", -1, -1), new r("dt", -1, -1), new r("gt", -1, -1), new r("kt", -1, -1)],
                            d = [new r("ig", -1, 1), new r("lig", 0, 1), new r("elig", 1, 1), new r("els", -1, 1), new r("løst", -1, 2)],
                            w = [17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 48, 0, 128],
                            m = [239, 254, 42, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16],
                            p = new n;
                        this.setCurrent = function(e) {
                            p.setCurrent(e)
                        }, this.getCurrent = function() {
                            return p.getCurrent()
                        }, this.stem = function() {
                            var r = p.cursor;
                            return e(), p.limit_backward = r, p.cursor = p.limit, t(), p.cursor = p.limit, i(), p.cursor = p.limit, o(), p.cursor = p.limit, s(), !0
                        }
                    };
                return function(e) {
                    return t.setCurrent(e), t.stem(), t.getCurrent()
                }
            }(), e.Pipeline.registerFunction(e.da.stemmer, "stemmer-da"), e.da.stopWordFilter = function(r) {
                if (e.da.stopWordFilter.stopWords.indexOf(r) === -1) return r
            }, e.da.stopWordFilter.stopWords = new e.SortedSet, e.da.stopWordFilter.stopWords.length = 95, e.da.stopWordFilter.stopWords.elements = " ad af alle alt anden at blev blive bliver da de dem den denne der deres det dette dig din disse dog du efter eller en end er et for fra ham han hans har havde have hende hendes her hos hun hvad hvis hvor i ikke ind jeg jer jo kunne man mange med meget men mig min mine mit mod ned noget nogle nu når og også om op os over på selv sig sin sine sit skal skulle som sådan thi til ud under var vi vil ville vor være været".split(" "), e.Pipeline.registerFunction(e.da.stopWordFilter, "stopWordFilter-da")
        }
    })
}, function(e, r, n) {
    var t, i;
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(this, function() {
        return function(e) {
            if ("undefined" == typeof e) throw new Error("Lunr is not present. Please include / require Lunr before this script.");
            if ("undefined" == typeof e.stemmerSupport) throw new Error("Lunr stemmer support is not present. Please include / require Lunr stemmer support before this script.");
            e.de = function() {
                this.pipeline.reset(), this.pipeline.add(e.de.stopWordFilter, e.de.stemmer)
            }, e.de.stemmer = function() {
                var r = e.stemmerSupport.Among,
                    n = e.stemmerSupport.SnowballProgram,
                    t = new function() {
                        function e(e, r, n) {
                            return !(!k.eq_s(1, e) || (k.ket = k.cursor, !k.in_grouping(v, 97, 252))) && (k.slice_from(r), k.cursor = n, !0)
                        }

                        function t() {
                            for (var r, n, t, i, o = k.cursor;;)
                                if (r = k.cursor, k.bra = r, k.eq_s(1, "ß")) k.ket = k.cursor, k.slice_from("ss");
                                else {
                                    if (r >= k.limit) break;
                                    k.cursor = r + 1
                                } for (k.cursor = o;;)
                                for (n = k.cursor;;) {
                                    if (t = k.cursor, k.in_grouping(v, 97, 252)) {
                                        if (i = k.cursor, k.bra = i, e("u", "U", t)) break;
                                        if (k.cursor = i, e("y", "Y", t)) break
                                    }
                                    if (t >= k.limit) return void(k.cursor = n);
                                    k.cursor = t + 1
                                }
                        }

                        function i() {
                            for (; !k.in_grouping(v, 97, 252);) {
                                if (k.cursor >= k.limit) return !0;
                                k.cursor++
                            }
                            for (; !k.out_grouping(v, 97, 252);) {
                                if (k.cursor >= k.limit) return !0;
                                k.cursor++
                            }
                            return !1
                        }

                        function o() {
                            d = k.limit, f = d;
                            var e = k.cursor + 3;
                            0 <= e && e <= k.limit && (l = e, i() || (d = k.cursor, d < l && (d = l), i() || (f = k.cursor)))
                        }

                        function s() {
                            for (var e, r;;) {
                                if (r = k.cursor, k.bra = r, e = k.find_among(w, 6), !e) return;
                                switch (k.ket = k.cursor, e) {
                                    case 1:
                                        k.slice_from("y");
                                        break;
                                    case 2:
                                    case 5:
                                        k.slice_from("u");
                                        break;
                                    case 3:
                                        k.slice_from("a");
                                        break;
                                    case 4:
                                        k.slice_from("o");
                                        break;
                                    case 6:
                                        if (k.cursor >= k.limit) return;
                                        k.cursor++
                                }
                            }
                        }

                        function u() {
                            return d <= k.cursor
                        }

                        function a() {
                            return f <= k.cursor
                        }

                        function c() {
                            var e, r, n, t, i = k.limit - k.cursor;
                            if (k.ket = k.cursor, e = k.find_among_b(m, 7), e && (k.bra = k.cursor, u())) switch (e) {
                                case 1:
                                    k.slice_del();
                                    break;
                                case 2:
                                    k.slice_del(), k.ket = k.cursor, k.eq_s_b(1, "s") && (k.bra = k.cursor, k.eq_s_b(3, "nis") && k.slice_del());
                                    break;
                                case 3:
                                    k.in_grouping_b(_, 98, 116) && k.slice_del()
                            }
                            if (k.cursor = k.limit - i, k.ket = k.cursor, e = k.find_among_b(p, 4), e && (k.bra = k.cursor, u())) switch (e) {
                                case 1:
                                    k.slice_del();
                                    break;
                                case 2:
                                    if (k.in_grouping_b(g, 98, 116)) {
                                        var o = k.cursor - 3;
                                        k.limit_backward <= o && o <= k.limit && (k.cursor = o, k.slice_del())
                                    }
                            }
                            if (k.cursor = k.limit - i, k.ket = k.cursor, e = k.find_among_b(b, 8), e && (k.bra = k.cursor, a())) switch (e) {
                                case 1:
                                    k.slice_del(), k.ket = k.cursor, k.eq_s_b(2, "ig") && (k.bra = k.cursor, r = k.limit - k.cursor, k.eq_s_b(1, "e") || (k.cursor = k.limit - r, a() && k.slice_del()));
                                    break;
                                case 2:
                                    n = k.limit - k.cursor, k.eq_s_b(1, "e") || (k.cursor = k.limit - n, k.slice_del());
                                    break;
                                case 3:
                                    if (k.slice_del(), k.ket = k.cursor, t = k.limit - k.cursor, !k.eq_s_b(2, "er") && (k.cursor = k.limit - t, !k.eq_s_b(2, "en"))) break;
                                    k.bra = k.cursor, u() && k.slice_del();
                                    break;
                                case 4:
                                    k.slice_del(), k.ket = k.cursor, e = k.find_among_b(h, 2), e && (k.bra = k.cursor, a() && 1 == e && k.slice_del())
                            }
                        }
                        var l, f, d, w = [new r("", -1, 6), new r("U", 0, 2), new r("Y", 0, 1), new r("ä", 0, 3), new r("ö", 0, 4), new r("ü", 0, 5)],
                            m = [new r("e", -1, 2), new r("em", -1, 1), new r("en", -1, 2), new r("ern", -1, 1), new r("er", -1, 1), new r("s", -1, 3), new r("es", 5, 2)],
                            p = [new r("en", -1, 1), new r("er", -1, 1), new r("st", -1, 2), new r("est", 2, 1)],
                            h = [new r("ig", -1, 1), new r("lich", -1, 1)],
                            b = [new r("end", -1, 1), new r("ig", -1, 2), new r("ung", -1, 1), new r("lich", -1, 3), new r("isch", -1, 2), new r("ik", -1, 2), new r("heit", -1, 3), new r("keit", -1, 4)],
                            v = [17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 32, 8],
                            _ = [117, 30, 5],
                            g = [117, 30, 4],
                            k = new n;
                        this.setCurrent = function(e) {
                            k.setCurrent(e)
                        }, this.getCurrent = function() {
                            return k.getCurrent()
                        }, this.stem = function() {
                            var e = k.cursor;
                            return t(), k.cursor = e, o(), k.limit_backward = e, k.cursor = k.limit, c(), k.cursor = k.limit_backward, s(), !0
                        }
                    };
                return function(e) {
                    return t.setCurrent(e), t.stem(), t.getCurrent()
                }
            }(), e.Pipeline.registerFunction(e.de.stemmer, "stemmer-de"), e.de.stopWordFilter = function(r) {
                if (e.de.stopWordFilter.stopWords.indexOf(r) === -1) return r
            }, e.de.stopWordFilter.stopWords = new e.SortedSet, e.de.stopWordFilter.stopWords.length = 232, e.de.stopWordFilter.stopWords.elements = " aber alle allem allen aller alles als also am an ander andere anderem anderen anderer anderes anderm andern anderr anders auch auf aus bei bin bis bist da damit dann das dasselbe dazu daß dein deine deinem deinen deiner deines dem demselben den denn denselben der derer derselbe derselben des desselben dessen dich die dies diese dieselbe dieselben diesem diesen dieser dieses dir doch dort du durch ein eine einem einen einer eines einig einige einigem einigen einiger einiges einmal er es etwas euch euer eure eurem euren eurer eures für gegen gewesen hab habe haben hat hatte hatten hier hin hinter ich ihm ihn ihnen ihr ihre ihrem ihren ihrer ihres im in indem ins ist jede jedem jeden jeder jedes jene jenem jenen jener jenes jetzt kann kein keine keinem keinen keiner keines können könnte machen man manche manchem manchen mancher manches mein meine meinem meinen meiner meines mich mir mit muss musste nach nicht nichts noch nun nur ob oder ohne sehr sein seine seinem seinen seiner seines selbst sich sie sind so solche solchem solchen solcher solches soll sollte sondern sonst um und uns unse unsem unsen unser unses unter viel vom von vor war waren warst was weg weil weiter welche welchem welchen welcher welches wenn werde werden wie wieder will wir wird wirst wo wollen wollte während würde würden zu zum zur zwar zwischen über".split(" "), e.Pipeline.registerFunction(e.de.stopWordFilter, "stopWordFilter-de")
        }
    })
}, function(e, r, n) {
    var t, i;
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(this, function() {
        return function(e) {
            if ("undefined" == typeof e) throw new Error("Lunr is not present. Please include / require Lunr before this script.");
            if ("undefined" == typeof e.stemmerSupport) throw new Error("Lunr stemmer support is not present. Please include / require Lunr stemmer support before this script.");
            e.du = function() {
                this.pipeline.reset(), this.pipeline.add(e.du.stopWordFilter, e.du.stemmer)
            }, e.du.stemmer = function() {
                var r = e.stemmerSupport.Among,
                    n = e.stemmerSupport.SnowballProgram,
                    t = new function() {
                        function e() {
                            for (var e, r, n, i = F.cursor;;) {
                                if (F.bra = F.cursor, e = F.find_among(h, 11)) switch (F.ket = F.cursor, e) {
                                    case 1:
                                        F.slice_from("a");
                                        continue;
                                    case 2:
                                        F.slice_from("e");
                                        continue;
                                    case 3:
                                        F.slice_from("i");
                                        continue;
                                    case 4:
                                        F.slice_from("o");
                                        continue;
                                    case 5:
                                        F.slice_from("u");
                                        continue;
                                    case 6:
                                        if (F.cursor >= F.limit) break;
                                        F.cursor++;
                                        continue
                                }
                                break
                            }
                            for (F.cursor = i, F.bra = i, F.eq_s(1, "y") ? (F.ket = F.cursor, F.slice_from("Y")) : F.cursor = i;;)
                                if (r = F.cursor, F.in_grouping(y, 97, 232)) {
                                    if (n = F.cursor, F.bra = n, F.eq_s(1, "i")) F.ket = F.cursor, F.in_grouping(y, 97, 232) && (F.slice_from("I"), F.cursor = r);
                                    else if (F.cursor = n, F.eq_s(1, "y")) F.ket = F.cursor, F.slice_from("Y"), F.cursor = r;
                                    else if (t(r)) break
                                } else if (t(r)) break
                        }

                        function t(e) {
                            return F.cursor = e, e >= F.limit || (F.cursor++, !1)
                        }

                        function i() {
                            m = F.limit, w = m, o() || (m = F.cursor, m < 3 && (m = 3), o() || (w = F.cursor))
                        }

                        function o() {
                            for (; !F.in_grouping(y, 97, 232);) {
                                if (F.cursor >= F.limit) return !0;
                                F.cursor++
                            }
                            for (; !F.out_grouping(y, 97, 232);) {
                                if (F.cursor >= F.limit) return !0;
                                F.cursor++
                            }
                            return !1
                        }

                        function s() {
                            for (var e;;)
                                if (F.bra = F.cursor, e = F.find_among(b, 3)) switch (F.ket = F.cursor, e) {
                                    case 1:
                                        F.slice_from("y");
                                        break;
                                    case 2:
                                        F.slice_from("i");
                                        break;
                                    case 3:
                                        if (F.cursor >= F.limit) return;
                                        F.cursor++
                                }
                        }

                        function u() {
                            return m <= F.cursor
                        }

                        function a() {
                            return w <= F.cursor
                        }

                        function c() {
                            var e = F.limit - F.cursor;
                            F.find_among_b(v, 3) && (F.cursor = F.limit - e, F.ket = F.cursor, F.cursor > F.limit_backward && (F.cursor--, F.bra = F.cursor, F.slice_del()))
                        }

                        function l() {
                            var e;
                            p = !1, F.ket = F.cursor, F.eq_s_b(1, "e") && (F.bra = F.cursor, u() && (e = F.limit - F.cursor, F.out_grouping_b(y, 97, 232) && (F.cursor = F.limit - e, F.slice_del(), p = !0, c())))
                        }

                        function f() {
                            var e;
                            u() && (e = F.limit - F.cursor, F.out_grouping_b(y, 97, 232) && (F.cursor = F.limit - e, F.eq_s_b(3, "gem") || (F.cursor = F.limit - e, F.slice_del(), c())))
                        }

                        function d() {
                            var e, r, n, t, i, o, s = F.limit - F.cursor;
                            if (F.ket = F.cursor, e = F.find_among_b(_, 5)) switch (F.bra = F.cursor, e) {
                                case 1:
                                    u() && F.slice_from("heid");
                                    break;
                                case 2:
                                    f();
                                    break;
                                case 3:
                                    u() && F.out_grouping_b(S, 97, 232) && F.slice_del()
                            }
                            if (F.cursor = F.limit - s, l(), F.cursor = F.limit - s, F.ket = F.cursor, F.eq_s_b(4, "heid") && (F.bra = F.cursor, a() && (r = F.limit - F.cursor, F.eq_s_b(1, "c") || (F.cursor = F.limit - r, F.slice_del(), F.ket = F.cursor, F.eq_s_b(2, "en") && (F.bra = F.cursor, f())))), F.cursor = F.limit - s, F.ket = F.cursor, e = F.find_among_b(g, 6)) switch (F.bra = F.cursor, e) {
                                case 1:
                                    if (a()) {
                                        if (F.slice_del(), n = F.limit - F.cursor, F.ket = F.cursor, F.eq_s_b(2, "ig") && (F.bra = F.cursor, a() && (t = F.limit - F.cursor, !F.eq_s_b(1, "e")))) {
                                            F.cursor = F.limit - t, F.slice_del();
                                            break
                                        }
                                        F.cursor = F.limit - n, c()
                                    }
                                    break;
                                case 2:
                                    a() && (i = F.limit - F.cursor, F.eq_s_b(1, "e") || (F.cursor = F.limit - i, F.slice_del()));
                                    break;
                                case 3:
                                    a() && (F.slice_del(), l());
                                    break;
                                case 4:
                                    a() && F.slice_del();
                                    break;
                                case 5:
                                    a() && p && F.slice_del()
                            }
                            F.cursor = F.limit - s, F.out_grouping_b(x, 73, 232) && (o = F.limit - F.cursor, F.find_among_b(k, 4) && F.out_grouping_b(y, 97, 232) && (F.cursor = F.limit - o, F.ket = F.cursor, F.cursor > F.limit_backward && (F.cursor--, F.bra = F.cursor, F.slice_del())))
                        }
                        var w, m, p, h = [new r("", -1, 6), new r("á", 0, 1), new r("ä", 0, 1), new r("é", 0, 2), new r("ë", 0, 2), new r("í", 0, 3), new r("ï", 0, 3), new r("ó", 0, 4), new r("ö", 0, 4), new r("ú", 0, 5), new r("ü", 0, 5)],
                            b = [new r("", -1, 3), new r("I", 0, 2), new r("Y", 0, 1)],
                            v = [new r("dd", -1, -1), new r("kk", -1, -1), new r("tt", -1, -1)],
                            _ = [new r("ene", -1, 2), new r("se", -1, 3), new r("en", -1, 2), new r("heden", 2, 1), new r("s", -1, 3)],
                            g = [new r("end", -1, 1), new r("ig", -1, 2), new r("ing", -1, 1), new r("lijk", -1, 3), new r("baar", -1, 4), new r("bar", -1, 5)],
                            k = [new r("aa", -1, -1), new r("ee", -1, -1), new r("oo", -1, -1), new r("uu", -1, -1)],
                            y = [17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128],
                            x = [1, 0, 0, 17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128],
                            S = [17, 67, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128],
                            F = new n;
                        this.setCurrent = function(e) {
                            F.setCurrent(e)
                        }, this.getCurrent = function() {
                            return F.getCurrent()
                        }, this.stem = function() {
                            var r = F.cursor;
                            return e(), F.cursor = r, i(), F.limit_backward = r, F.cursor = F.limit, d(), F.cursor = F.limit_backward, s(), !0
                        }
                    };
                return function(e) {
                    return t.setCurrent(e), t.stem(), t.getCurrent()
                }
            }(), e.Pipeline.registerFunction(e.du.stemmer, "stemmer-du"), e.du.stopWordFilter = function(r) {
                if (e.du.stopWordFilter.stopWords.indexOf(r) === -1) return r
            }, e.du.stopWordFilter.stopWords = new e.SortedSet, e.du.stopWordFilter.stopWords.length = 103, e.du.stopWordFilter.stopWords.elements = "  aan al alles als altijd andere ben bij daar dan dat de der deze die dit doch doen door dus een eens en er ge geen geweest haar had heb hebben heeft hem het hier hij hoe hun iemand iets ik in is ja je kan kon kunnen maar me meer men met mij mijn moet na naar niet niets nog nu of om omdat onder ons ook op over reeds te tegen toch toen tot u uit uw van veel voor want waren was wat werd wezen wie wil worden wordt zal ze zelf zich zij zijn zo zonder zou".split(" "), e.Pipeline.registerFunction(e.du.stopWordFilter, "stopWordFilter-du")
        }
    })
}, function(e, r, n) {
    var t, i;
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(this, function() {
        return function(e) {
            if ("undefined" == typeof e) throw new Error("Lunr is not present. Please include / require Lunr before this script.");
            if ("undefined" == typeof e.stemmerSupport) throw new Error("Lunr stemmer support is not present. Please include / require Lunr stemmer support before this script.");
            e.es = function() {
                this.pipeline.reset(), this.pipeline.add(e.es.stopWordFilter, e.es.stemmer)
            }, e.es.stemmer = function() {
                var r = e.stemmerSupport.Among,
                    n = e.stemmerSupport.SnowballProgram,
                    t = new function() {
                        function e() {
                            if (P.out_grouping(C, 97, 252)) {
                                for (; !P.in_grouping(C, 97, 252);) {
                                    if (P.cursor >= P.limit) return !0;
                                    P.cursor++
                                }
                                return !1
                            }
                            return !0
                        }

                        function t() {
                            if (P.in_grouping(C, 97, 252)) {
                                var r = P.cursor;
                                if (e()) {
                                    if (P.cursor = r, !P.in_grouping(C, 97, 252)) return !0;
                                    for (; !P.out_grouping(C, 97, 252);) {
                                        if (P.cursor >= P.limit) return !0;
                                        P.cursor++
                                    }
                                }
                                return !1
                            }
                            return !0
                        }

                        function i() {
                            var r, n = P.cursor;
                            if (t()) {
                                if (P.cursor = n, !P.out_grouping(C, 97, 252)) return;
                                if (r = P.cursor, e()) {
                                    if (P.cursor = r, !P.in_grouping(C, 97, 252) || P.cursor >= P.limit) return;
                                    P.cursor++
                                }
                            }
                            g = P.cursor
                        }

                        function o() {
                            for (; !P.in_grouping(C, 97, 252);) {
                                if (P.cursor >= P.limit) return !1;
                                P.cursor++
                            }
                            for (; !P.out_grouping(C, 97, 252);) {
                                if (P.cursor >= P.limit) return !1;
                                P.cursor++
                            }
                            return !0
                        }

                        function s() {
                            var e = P.cursor;
                            g = P.limit, _ = g, v = g, i(), P.cursor = e, o() && (_ = P.cursor, o() && (v = P.cursor))
                        }

                        function u() {
                            for (var e;;) {
                                if (P.bra = P.cursor, e = P.find_among(k, 6)) switch (P.ket = P.cursor, e) {
                                    case 1:
                                        P.slice_from("a");
                                        continue;
                                    case 2:
                                        P.slice_from("e");
                                        continue;
                                    case 3:
                                        P.slice_from("i");
                                        continue;
                                    case 4:
                                        P.slice_from("o");
                                        continue;
                                    case 5:
                                        P.slice_from("u");
                                        continue;
                                    case 6:
                                        if (P.cursor >= P.limit) break;
                                        P.cursor++;
                                        continue
                                }
                                break
                            }
                        }

                        function a() {
                            return g <= P.cursor
                        }

                        function c() {
                            return _ <= P.cursor
                        }

                        function l() {
                            return v <= P.cursor
                        }

                        function f() {
                            var e;
                            if (P.ket = P.cursor, P.find_among_b(y, 13) && (P.bra = P.cursor, e = P.find_among_b(x, 11), e && a())) switch (e) {
                                case 1:
                                    P.bra = P.cursor, P.slice_from("iendo");
                                    break;
                                case 2:
                                    P.bra = P.cursor, P.slice_from("ando");
                                    break;
                                case 3:
                                    P.bra = P.cursor, P.slice_from("ar");
                                    break;
                                case 4:
                                    P.bra = P.cursor, P.slice_from("er");
                                    break;
                                case 5:
                                    P.bra = P.cursor, P.slice_from("ir");
                                    break;
                                case 6:
                                    P.slice_del();
                                    break;
                                case 7:
                                    P.eq_s_b(1, "u") && P.slice_del()
                            }
                        }

                        function d(e, r) {
                            if (!l()) return !0;
                            P.slice_del(), P.ket = P.cursor;
                            var n = P.find_among_b(e, r);
                            return n && (P.bra = P.cursor, 1 == n && l() && P.slice_del()), !1
                        }

                        function w(e) {
                            return !l() || (P.slice_del(), P.ket = P.cursor, P.eq_s_b(2, e) && (P.bra = P.cursor, l() && P.slice_del()), !1)
                        }

                        function m() {
                            var e;
                            if (P.ket = P.cursor, e = P.find_among_b(W, 46)) {
                                switch (P.bra = P.cursor, e) {
                                    case 1:
                                        if (!l()) return !1;
                                        P.slice_del();
                                        break;
                                    case 2:
                                        if (w("ic")) return !1;
                                        break;
                                    case 3:
                                        if (!l()) return !1;
                                        P.slice_from("log");
                                        break;
                                    case 4:
                                        if (!l()) return !1;
                                        P.slice_from("u");
                                        break;
                                    case 5:
                                        if (!l()) return !1;
                                        P.slice_from("ente");
                                        break;
                                    case 6:
                                        if (!c()) return !1;
                                        P.slice_del(), P.ket = P.cursor, e = P.find_among_b(S, 4), e && (P.bra = P.cursor, l() && (P.slice_del(), 1 == e && (P.ket = P.cursor, P.eq_s_b(2, "at") && (P.bra = P.cursor, l() && P.slice_del()))));
                                        break;
                                    case 7:
                                        if (d(F, 3)) return !1;
                                        break;
                                    case 8:
                                        if (d(q, 3)) return !1;
                                        break;
                                    case 9:
                                        if (w("at")) return !1
                                }
                                return !0
                            }
                            return !1
                        }

                        function p() {
                            var e, r;
                            if (P.cursor >= g && (r = P.limit_backward, P.limit_backward = g, P.ket = P.cursor, e = P.find_among_b(z, 12), P.limit_backward = r, e)) {
                                if (P.bra = P.cursor, 1 == e) {
                                    if (!P.eq_s_b(1, "u")) return !1;
                                    P.slice_del()
                                }
                                return !0
                            }
                            return !1
                        }

                        function h() {
                            var e, r, n, t;
                            if (P.cursor >= g && (r = P.limit_backward, P.limit_backward = g, P.ket = P.cursor, e = P.find_among_b(j, 96), P.limit_backward = r, e)) switch (P.bra = P.cursor, e) {
                                case 1:
                                    n = P.limit - P.cursor, P.eq_s_b(1, "u") ? (t = P.limit - P.cursor, P.eq_s_b(1, "g") ? P.cursor = P.limit - t : P.cursor = P.limit - n) : P.cursor = P.limit - n, P.bra = P.cursor;
                                case 2:
                                    P.slice_del()
                            }
                        }

                        function b() {
                            var e, r;
                            if (P.ket = P.cursor, e = P.find_among_b(L, 8)) switch (P.bra = P.cursor, e) {
                                case 1:
                                    a() && P.slice_del();
                                    break;
                                case 2:
                                    a() && (P.slice_del(), P.ket = P.cursor, P.eq_s_b(1, "u") && (P.bra = P.cursor, r = P.limit - P.cursor, P.eq_s_b(1, "g") && (P.cursor = P.limit - r, a() && P.slice_del())))
                            }
                        }
                        var v, _, g, k = [new r("", -1, 6), new r("á", 0, 1), new r("é", 0, 2), new r("í", 0, 3), new r("ó", 0, 4), new r("ú", 0, 5)],
                            y = [new r("la", -1, -1), new r("sela", 0, -1), new r("le", -1, -1), new r("me", -1, -1), new r("se", -1, -1), new r("lo", -1, -1), new r("selo", 5, -1), new r("las", -1, -1), new r("selas", 7, -1), new r("les", -1, -1), new r("los", -1, -1), new r("selos", 10, -1), new r("nos", -1, -1)],
                            x = [new r("ando", -1, 6), new r("iendo", -1, 6), new r("yendo", -1, 7), new r("ándo", -1, 2), new r("iéndo", -1, 1), new r("ar", -1, 6), new r("er", -1, 6), new r("ir", -1, 6), new r("ár", -1, 3), new r("ér", -1, 4), new r("ír", -1, 5)],
                            S = [new r("ic", -1, -1), new r("ad", -1, -1), new r("os", -1, -1), new r("iv", -1, 1)],
                            F = [new r("able", -1, 1), new r("ible", -1, 1), new r("ante", -1, 1)],
                            q = [new r("ic", -1, 1), new r("abil", -1, 1), new r("iv", -1, 1)],
                            W = [new r("ica", -1, 1), new r("ancia", -1, 2), new r("encia", -1, 5), new r("adora", -1, 2), new r("osa", -1, 1), new r("ista", -1, 1), new r("iva", -1, 9), new r("anza", -1, 1), new r("logía", -1, 3), new r("idad", -1, 8), new r("able", -1, 1), new r("ible", -1, 1), new r("ante", -1, 2), new r("mente", -1, 7), new r("amente", 13, 6), new r("ación", -1, 2), new r("ución", -1, 4), new r("ico", -1, 1), new r("ismo", -1, 1), new r("oso", -1, 1), new r("amiento", -1, 1), new r("imiento", -1, 1), new r("ivo", -1, 9), new r("ador", -1, 2), new r("icas", -1, 1), new r("ancias", -1, 2), new r("encias", -1, 5), new r("adoras", -1, 2), new r("osas", -1, 1), new r("istas", -1, 1), new r("ivas", -1, 9), new r("anzas", -1, 1), new r("logías", -1, 3), new r("idades", -1, 8), new r("ables", -1, 1), new r("ibles", -1, 1), new r("aciones", -1, 2), new r("uciones", -1, 4), new r("adores", -1, 2), new r("antes", -1, 2), new r("icos", -1, 1), new r("ismos", -1, 1), new r("osos", -1, 1), new r("amientos", -1, 1), new r("imientos", -1, 1), new r("ivos", -1, 9)],
                            z = [new r("ya", -1, 1), new r("ye", -1, 1), new r("yan", -1, 1), new r("yen", -1, 1), new r("yeron", -1, 1), new r("yendo", -1, 1), new r("yo", -1, 1), new r("yas", -1, 1), new r("yes", -1, 1), new r("yais", -1, 1), new r("yamos", -1, 1), new r("yó", -1, 1)],
                            j = [new r("aba", -1, 2), new r("ada", -1, 2), new r("ida", -1, 2), new r("ara", -1, 2), new r("iera", -1, 2), new r("ía", -1, 2), new r("aría", 5, 2), new r("ería", 5, 2), new r("iría", 5, 2), new r("ad", -1, 2), new r("ed", -1, 2), new r("id", -1, 2), new r("ase", -1, 2), new r("iese", -1, 2), new r("aste", -1, 2), new r("iste", -1, 2), new r("an", -1, 2), new r("aban", 16, 2), new r("aran", 16, 2), new r("ieran", 16, 2), new r("ían", 16, 2), new r("arían", 20, 2), new r("erían", 20, 2), new r("irían", 20, 2), new r("en", -1, 1), new r("asen", 24, 2), new r("iesen", 24, 2), new r("aron", -1, 2), new r("ieron", -1, 2), new r("arán", -1, 2), new r("erán", -1, 2), new r("irán", -1, 2), new r("ado", -1, 2), new r("ido", -1, 2), new r("ando", -1, 2), new r("iendo", -1, 2), new r("ar", -1, 2), new r("er", -1, 2), new r("ir", -1, 2), new r("as", -1, 2), new r("abas", 39, 2), new r("adas", 39, 2), new r("idas", 39, 2), new r("aras", 39, 2), new r("ieras", 39, 2), new r("ías", 39, 2), new r("arías", 45, 2), new r("erías", 45, 2), new r("irías", 45, 2), new r("es", -1, 1), new r("ases", 49, 2), new r("ieses", 49, 2), new r("abais", -1, 2), new r("arais", -1, 2), new r("ierais", -1, 2), new r("íais", -1, 2), new r("aríais", 55, 2), new r("eríais", 55, 2), new r("iríais", 55, 2), new r("aseis", -1, 2), new r("ieseis", -1, 2), new r("asteis", -1, 2), new r("isteis", -1, 2), new r("áis", -1, 2), new r("éis", -1, 1), new r("aréis", 64, 2), new r("eréis", 64, 2), new r("iréis", 64, 2), new r("ados", -1, 2), new r("idos", -1, 2), new r("amos", -1, 2), new r("ábamos", 70, 2), new r("áramos", 70, 2), new r("iéramos", 70, 2), new r("íamos", 70, 2), new r("aríamos", 74, 2), new r("eríamos", 74, 2), new r("iríamos", 74, 2), new r("emos", -1, 1), new r("aremos", 78, 2), new r("eremos", 78, 2), new r("iremos", 78, 2), new r("ásemos", 78, 2), new r("iésemos", 78, 2), new r("imos", -1, 2), new r("arás", -1, 2), new r("erás", -1, 2), new r("irás", -1, 2), new r("ís", -1, 2), new r("ará", -1, 2), new r("erá", -1, 2), new r("irá", -1, 2), new r("aré", -1, 2), new r("eré", -1, 2), new r("iré", -1, 2), new r("ió", -1, 2)],
                            L = [new r("a", -1, 1), new r("e", -1, 2), new r("o", -1, 1), new r("os", -1, 1), new r("á", -1, 1), new r("é", -1, 2), new r("í", -1, 1), new r("ó", -1, 1)],
                            C = [17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 17, 4, 10],
                            P = new n;
                        this.setCurrent = function(e) {
                            P.setCurrent(e)
                        }, this.getCurrent = function() {
                            return P.getCurrent()
                        }, this.stem = function() {
                            var e = P.cursor;
                            return s(), P.limit_backward = e, P.cursor = P.limit, f(), P.cursor = P.limit, m() || (P.cursor = P.limit, p() || (P.cursor = P.limit, h())), P.cursor = P.limit, b(), P.cursor = P.limit_backward, u(), !0
                        }
                    };
                return function(e) {
                    return t.setCurrent(e), t.stem(), t.getCurrent()
                }
            }(), e.Pipeline.registerFunction(e.es.stemmer, "stemmer-es"), e.es.stopWordFilter = function(r) {
                if (e.es.stopWordFilter.stopWords.indexOf(r) === -1) return r
            }, e.es.stopWordFilter.stopWords = new e.SortedSet, e.es.stopWordFilter.stopWords.length = 309, e.es.stopWordFilter.stopWords.elements = " a al algo algunas algunos ante antes como con contra cual cuando de del desde donde durante e el ella ellas ellos en entre era erais eran eras eres es esa esas ese eso esos esta estaba estabais estaban estabas estad estada estadas estado estados estamos estando estar estaremos estará estarán estarás estaré estaréis estaría estaríais estaríamos estarían estarías estas este estemos esto estos estoy estuve estuviera estuvierais estuvieran estuvieras estuvieron estuviese estuvieseis estuviesen estuvieses estuvimos estuviste estuvisteis estuviéramos estuviésemos estuvo está estábamos estáis están estás esté estéis estén estés fue fuera fuerais fueran fueras fueron fuese fueseis fuesen fueses fui fuimos fuiste fuisteis fuéramos fuésemos ha habida habidas habido habidos habiendo habremos habrá habrán habrás habré habréis habría habríais habríamos habrían habrías habéis había habíais habíamos habían habías han has hasta hay haya hayamos hayan hayas hayáis he hemos hube hubiera hubierais hubieran hubieras hubieron hubiese hubieseis hubiesen hubieses hubimos hubiste hubisteis hubiéramos hubiésemos hubo la las le les lo los me mi mis mucho muchos muy más mí mía mías mío míos nada ni no nos nosotras nosotros nuestra nuestras nuestro nuestros o os otra otras otro otros para pero poco por porque que quien quienes qué se sea seamos sean seas seremos será serán serás seré seréis sería seríais seríamos serían serías seáis sido siendo sin sobre sois somos son soy su sus suya suyas suyo suyos sí también tanto te tendremos tendrá tendrán tendrás tendré tendréis tendría tendríais tendríamos tendrían tendrías tened tenemos tenga tengamos tengan tengas tengo tengáis tenida tenidas tenido tenidos teniendo tenéis tenía teníais teníamos tenían tenías ti tiene tienen tienes todo todos tu tus tuve tuviera tuvierais tuvieran tuvieras tuvieron tuviese tuvieseis tuviesen tuvieses tuvimos tuviste tuvisteis tuviéramos tuviésemos tuvo tuya tuyas tuyo tuyos tú un una uno unos vosotras vosotros vuestra vuestras vuestro vuestros y ya yo él éramos".split(" "), e.Pipeline.registerFunction(e.es.stopWordFilter, "stopWordFilter-es")
        }
    })
}, function(e, r, n) {
    var t, i;
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(this, function() {
        return function(e) {
            if ("undefined" == typeof e) throw new Error("Lunr is not present. Please include / require Lunr before this script.");
            if ("undefined" == typeof e.stemmerSupport) throw new Error("Lunr stemmer support is not present. Please include / require Lunr stemmer support before this script.");
            e.fi = function() {
                this.pipeline.reset(), this.pipeline.add(e.fi.stopWordFilter, e.fi.stemmer)
            }, e.fi.stemmer = function() {
                var r = e.stemmerSupport.Among,
                    n = e.stemmerSupport.SnowballProgram,
                    t = new function() {
                        function e() {
                            b = P.limit, h = b, t() || (b = P.cursor, t() || (h = P.cursor))
                        }

                        function t() {
                            for (var e;;) {
                                if (e = P.cursor, P.in_grouping(j, 97, 246)) break;
                                if (P.cursor = e, e >= P.limit) return !0;
                                P.cursor++
                            }
                            for (P.cursor = e; !P.out_grouping(j, 97, 246);) {
                                if (P.cursor >= P.limit) return !0;
                                P.cursor++
                            }
                            return !1
                        }

                        function i() {
                            return h <= P.cursor
                        }

                        function o() {
                            var e, r;
                            if (P.cursor >= b)
                                if (r = P.limit_backward, P.limit_backward = b, P.ket = P.cursor, e = P.find_among_b(v, 10)) {
                                    switch (P.bra = P.cursor, P.limit_backward = r, e) {
                                        case 1:
                                            if (!P.in_grouping_b(C, 97, 246)) return;
                                            break;
                                        case 2:
                                            if (!i()) return
                                    }
                                    P.slice_del()
                                } else P.limit_backward = r
                        }

                        function s() {
                            var e, r, n;
                            if (P.cursor >= b)
                                if (r = P.limit_backward, P.limit_backward = b, P.ket = P.cursor, e = P.find_among_b(y, 9)) switch (P.bra = P.cursor, P.limit_backward = r, e) {
                                    case 1:
                                        n = P.limit - P.cursor, P.eq_s_b(1, "k") || (P.cursor = P.limit - n, P.slice_del());
                                        break;
                                    case 2:
                                        P.slice_del(),
                                            P.ket = P.cursor, P.eq_s_b(3, "kse") && (P.bra = P.cursor, P.slice_from("ksi"));
                                        break;
                                    case 3:
                                        P.slice_del();
                                        break;
                                    case 4:
                                        P.find_among_b(_, 6) && P.slice_del();
                                        break;
                                    case 5:
                                        P.find_among_b(g, 6) && P.slice_del();
                                        break;
                                    case 6:
                                        P.find_among_b(k, 2) && P.slice_del()
                                } else P.limit_backward = r
                        }

                        function u() {
                            return P.find_among_b(x, 7)
                        }

                        function a() {
                            return P.eq_s_b(1, "i") && P.in_grouping_b(L, 97, 246)
                        }

                        function c() {
                            var e, r, n;
                            if (P.cursor >= b)
                                if (r = P.limit_backward, P.limit_backward = b, P.ket = P.cursor, e = P.find_among_b(S, 30)) {
                                    switch (P.bra = P.cursor, P.limit_backward = r, e) {
                                        case 1:
                                            if (!P.eq_s_b(1, "a")) return;
                                            break;
                                        case 2:
                                        case 9:
                                            if (!P.eq_s_b(1, "e")) return;
                                            break;
                                        case 3:
                                            if (!P.eq_s_b(1, "i")) return;
                                            break;
                                        case 4:
                                            if (!P.eq_s_b(1, "o")) return;
                                            break;
                                        case 5:
                                            if (!P.eq_s_b(1, "ä")) return;
                                            break;
                                        case 6:
                                            if (!P.eq_s_b(1, "ö")) return;
                                            break;
                                        case 7:
                                            if (n = P.limit - P.cursor, !u() && (P.cursor = P.limit - n, !P.eq_s_b(2, "ie"))) {
                                                P.cursor = P.limit - n;
                                                break
                                            }
                                            if (P.cursor = P.limit - n, P.cursor <= P.limit_backward) {
                                                P.cursor = P.limit - n;
                                                break
                                            }
                                            P.cursor--, P.bra = P.cursor;
                                            break;
                                        case 8:
                                            if (!P.in_grouping_b(j, 97, 246) || !P.out_grouping_b(j, 97, 246)) return
                                    }
                                    P.slice_del(), m = !0
                                } else P.limit_backward = r
                        }

                        function l() {
                            var e, r, n;
                            if (P.cursor >= h)
                                if (r = P.limit_backward, P.limit_backward = h, P.ket = P.cursor, e = P.find_among_b(F, 14)) {
                                    if (P.bra = P.cursor, P.limit_backward = r, 1 == e) {
                                        if (n = P.limit - P.cursor, P.eq_s_b(2, "po")) return;
                                        P.cursor = P.limit - n
                                    }
                                    P.slice_del()
                                } else P.limit_backward = r
                        }

                        function f() {
                            var e;
                            P.cursor >= b && (e = P.limit_backward, P.limit_backward = b, P.ket = P.cursor, P.find_among_b(q, 2) ? (P.bra = P.cursor, P.limit_backward = e, P.slice_del()) : P.limit_backward = e)
                        }

                        function d() {
                            var e, r, n, t, i, o;
                            if (P.cursor >= b) {
                                if (r = P.limit_backward, P.limit_backward = b, P.ket = P.cursor, P.eq_s_b(1, "t") && (P.bra = P.cursor, n = P.limit - P.cursor, P.in_grouping_b(j, 97, 246) && (P.cursor = P.limit - n, P.slice_del(), P.limit_backward = r, t = P.limit - P.cursor, P.cursor >= h && (P.cursor = h, i = P.limit_backward, P.limit_backward = P.cursor, P.cursor = P.limit - t, P.ket = P.cursor, e = P.find_among_b(W, 2))))) {
                                    if (P.bra = P.cursor, P.limit_backward = i, 1 == e) {
                                        if (o = P.limit - P.cursor, P.eq_s_b(2, "po")) return;
                                        P.cursor = P.limit - o
                                    }
                                    return void P.slice_del()
                                }
                                P.limit_backward = r
                            }
                        }

                        function w() {
                            var e, r, n, t;
                            if (P.cursor >= b) {
                                for (e = P.limit_backward, P.limit_backward = b, r = P.limit - P.cursor, u() && (P.cursor = P.limit - r, P.ket = P.cursor, P.cursor > P.limit_backward && (P.cursor--, P.bra = P.cursor, P.slice_del())), P.cursor = P.limit - r, P.ket = P.cursor, P.in_grouping_b(z, 97, 228) && (P.bra = P.cursor, P.out_grouping_b(j, 97, 246) && P.slice_del()), P.cursor = P.limit - r, P.ket = P.cursor, P.eq_s_b(1, "j") && (P.bra = P.cursor, n = P.limit - P.cursor, P.eq_s_b(1, "o") ? P.slice_del() : (P.cursor = P.limit - n, P.eq_s_b(1, "u") && P.slice_del())), P.cursor = P.limit - r, P.ket = P.cursor, P.eq_s_b(1, "o") && (P.bra = P.cursor, P.eq_s_b(1, "j") && P.slice_del()), P.cursor = P.limit - r, P.limit_backward = e;;) {
                                    if (t = P.limit - P.cursor, P.out_grouping_b(j, 97, 246)) {
                                        P.cursor = P.limit - t;
                                        break
                                    }
                                    if (P.cursor = P.limit - t, P.cursor <= P.limit_backward) return;
                                    P.cursor--
                                }
                                P.ket = P.cursor, P.cursor > P.limit_backward && (P.cursor--, P.bra = P.cursor, p = P.slice_to(), P.eq_v_b(p) && P.slice_del())
                            }
                        }
                        var m, p, h, b, v = [new r("pa", -1, 1), new r("sti", -1, 2), new r("kaan", -1, 1), new r("han", -1, 1), new r("kin", -1, 1), new r("hän", -1, 1), new r("kään", -1, 1), new r("ko", -1, 1), new r("pä", -1, 1), new r("kö", -1, 1)],
                            _ = [new r("lla", -1, -1), new r("na", -1, -1), new r("ssa", -1, -1), new r("ta", -1, -1), new r("lta", 3, -1), new r("sta", 3, -1)],
                            g = [new r("llä", -1, -1), new r("nä", -1, -1), new r("ssä", -1, -1), new r("tä", -1, -1), new r("ltä", 3, -1), new r("stä", 3, -1)],
                            k = [new r("lle", -1, -1), new r("ine", -1, -1)],
                            y = [new r("nsa", -1, 3), new r("mme", -1, 3), new r("nne", -1, 3), new r("ni", -1, 2), new r("si", -1, 1), new r("an", -1, 4), new r("en", -1, 6), new r("än", -1, 5), new r("nsä", -1, 3)],
                            x = [new r("aa", -1, -1), new r("ee", -1, -1), new r("ii", -1, -1), new r("oo", -1, -1), new r("uu", -1, -1), new r("ää", -1, -1), new r("öö", -1, -1)],
                            S = [new r("a", -1, 8), new r("lla", 0, -1), new r("na", 0, -1), new r("ssa", 0, -1), new r("ta", 0, -1), new r("lta", 4, -1), new r("sta", 4, -1), new r("tta", 4, 9), new r("lle", -1, -1), new r("ine", -1, -1), new r("ksi", -1, -1), new r("n", -1, 7), new r("han", 11, 1), new r("den", 11, -1, a), new r("seen", 11, -1, u), new r("hen", 11, 2), new r("tten", 11, -1, a), new r("hin", 11, 3), new r("siin", 11, -1, a), new r("hon", 11, 4), new r("hän", 11, 5), new r("hön", 11, 6), new r("ä", -1, 8), new r("llä", 22, -1), new r("nä", 22, -1), new r("ssä", 22, -1), new r("tä", 22, -1), new r("ltä", 26, -1), new r("stä", 26, -1), new r("ttä", 26, 9)],
                            F = [new r("eja", -1, -1), new r("mma", -1, 1), new r("imma", 1, -1), new r("mpa", -1, 1), new r("impa", 3, -1), new r("mmi", -1, 1), new r("immi", 5, -1), new r("mpi", -1, 1), new r("impi", 7, -1), new r("ejä", -1, -1), new r("mmä", -1, 1), new r("immä", 10, -1), new r("mpä", -1, 1), new r("impä", 12, -1)],
                            q = [new r("i", -1, -1), new r("j", -1, -1)],
                            W = [new r("mma", -1, 1), new r("imma", 0, -1)],
                            z = [17, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8],
                            j = [17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 32],
                            L = [17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 32],
                            C = [17, 97, 24, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 32],
                            P = new n;
                        this.setCurrent = function(e) {
                            P.setCurrent(e)
                        }, this.getCurrent = function() {
                            return P.getCurrent()
                        }, this.stem = function() {
                            var r = P.cursor;
                            return e(), m = !1, P.limit_backward = r, P.cursor = P.limit, o(), P.cursor = P.limit, s(), P.cursor = P.limit, c(), P.cursor = P.limit, l(), P.cursor = P.limit, m ? (f(), P.cursor = P.limit) : (P.cursor = P.limit, d(), P.cursor = P.limit), w(), !0
                        }
                    };
                return function(e) {
                    return t.setCurrent(e), t.stem(), t.getCurrent()
                }
            }(), e.Pipeline.registerFunction(e.fi.stemmer, "stemmer-fi"), e.fi.stopWordFilter = function(r) {
                if (e.fi.stopWordFilter.stopWords.indexOf(r) === -1) return r
            }, e.fi.stopWordFilter.stopWords = new e.SortedSet, e.fi.stopWordFilter.stopWords.length = 236, e.fi.stopWordFilter.stopWords.elements = " ei eivät emme en et ette että he heidän heidät heihin heille heillä heiltä heissä heistä heitä hän häneen hänelle hänellä häneltä hänen hänessä hänestä hänet häntä itse ja johon joiden joihin joiksi joilla joille joilta joina joissa joista joita joka joksi jolla jolle jolta jona jonka jos jossa josta jota jotka kanssa keiden keihin keiksi keille keillä keiltä keinä keissä keistä keitä keneen keneksi kenelle kenellä keneltä kenen kenenä kenessä kenestä kenet ketkä ketkä ketä koska kuin kuka kun me meidän meidät meihin meille meillä meiltä meissä meistä meitä mihin miksi mikä mille millä miltä minkä minkä minua minulla minulle minulta minun minussa minusta minut minuun minä minä missä mistä mitkä mitä mukaan mutta ne niiden niihin niiksi niille niillä niiltä niin niin niinä niissä niistä niitä noiden noihin noiksi noilla noille noilta noin noina noissa noista noita nuo nyt näiden näihin näiksi näille näillä näiltä näinä näissä näistä näitä nämä ole olemme olen olet olette oli olimme olin olisi olisimme olisin olisit olisitte olisivat olit olitte olivat olla olleet ollut on ovat poikki se sekä sen siihen siinä siitä siksi sille sillä sillä siltä sinua sinulla sinulle sinulta sinun sinussa sinusta sinut sinuun sinä sinä sitä tai te teidän teidät teihin teille teillä teiltä teissä teistä teitä tuo tuohon tuoksi tuolla tuolle tuolta tuon tuona tuossa tuosta tuota tähän täksi tälle tällä tältä tämä tämän tänä tässä tästä tätä vaan vai vaikka yli".split(" "), e.Pipeline.registerFunction(e.fi.stopWordFilter, "stopWordFilter-fi")
        }
    })
}, function(e, r, n) {
    var t, i;
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(this, function() {
        return function(e) {
            if ("undefined" == typeof e) throw new Error("Lunr is not present. Please include / require Lunr before this script.");
            if ("undefined" == typeof e.stemmerSupport) throw new Error("Lunr stemmer support is not present. Please include / require Lunr stemmer support before this script.");
            e.fr = function() {
                this.pipeline.reset(), this.pipeline.add(e.fr.stopWordFilter, e.fr.stemmer)
            }, e.fr.stemmer = function() {
                var r = e.stemmerSupport.Among,
                    n = e.stemmerSupport.SnowballProgram,
                    t = new function() {
                        function e(e, r, n) {
                            return !(!P.eq_s(1, e) || (P.ket = P.cursor, !P.in_grouping(L, 97, 251))) && (P.slice_from(r), P.cursor = n, !0)
                        }

                        function t(e, r, n) {
                            return !!P.eq_s(1, e) && (P.ket = P.cursor, P.slice_from(r), P.cursor = n, !0)
                        }

                        function i() {
                            for (var r, n;;) {
                                if (r = P.cursor, P.in_grouping(L, 97, 251)) {
                                    if (P.bra = P.cursor, n = P.cursor, e("u", "U", r)) continue;
                                    if (P.cursor = n, e("i", "I", r)) continue;
                                    if (P.cursor = n, t("y", "Y", r)) continue
                                }
                                if (P.cursor = r, P.bra = r, !e("y", "Y", r)) {
                                    if (P.cursor = r, P.eq_s(1, "q") && (P.bra = P.cursor, t("u", "U", r))) continue;
                                    if (P.cursor = r, r >= P.limit) return;
                                    P.cursor++
                                }
                            }
                        }

                        function o() {
                            for (; !P.in_grouping(L, 97, 251);) {
                                if (P.cursor >= P.limit) return !0;
                                P.cursor++
                            }
                            for (; !P.out_grouping(L, 97, 251);) {
                                if (P.cursor >= P.limit) return !0;
                                P.cursor++
                            }
                            return !1
                        }

                        function s() {
                            var e = P.cursor;
                            if (g = P.limit, _ = g, v = g, P.in_grouping(L, 97, 251) && P.in_grouping(L, 97, 251) && P.cursor < P.limit) P.cursor++;
                            else if (P.cursor = e, !P.find_among(k, 3)) {
                                P.cursor = e;
                                do {
                                    if (P.cursor >= P.limit) {
                                        P.cursor = g;
                                        break
                                    }
                                    P.cursor++
                                } while (!P.in_grouping(L, 97, 251))
                            }
                            g = P.cursor, P.cursor = e, o() || (_ = P.cursor, o() || (v = P.cursor))
                        }

                        function u() {
                            for (var e, r;;) {
                                if (r = P.cursor, P.bra = r, e = P.find_among(y, 4), !e) break;
                                switch (P.ket = P.cursor, e) {
                                    case 1:
                                        P.slice_from("i");
                                        break;
                                    case 2:
                                        P.slice_from("u");
                                        break;
                                    case 3:
                                        P.slice_from("y");
                                        break;
                                    case 4:
                                        if (P.cursor >= P.limit) return;
                                        P.cursor++
                                }
                            }
                        }

                        function a() {
                            return g <= P.cursor
                        }

                        function c() {
                            return _ <= P.cursor
                        }

                        function l() {
                            return v <= P.cursor
                        }

                        function f() {
                            var e, r;
                            if (P.ket = P.cursor, e = P.find_among_b(F, 43)) {
                                switch (P.bra = P.cursor, e) {
                                    case 1:
                                        if (!l()) return !1;
                                        P.slice_del();
                                        break;
                                    case 2:
                                        if (!l()) return !1;
                                        P.slice_del(), P.ket = P.cursor, P.eq_s_b(2, "ic") && (P.bra = P.cursor, l() ? P.slice_del() : P.slice_from("iqU"));
                                        break;
                                    case 3:
                                        if (!l()) return !1;
                                        P.slice_from("log");
                                        break;
                                    case 4:
                                        if (!l()) return !1;
                                        P.slice_from("u");
                                        break;
                                    case 5:
                                        if (!l()) return !1;
                                        P.slice_from("ent");
                                        break;
                                    case 6:
                                        if (!a()) return !1;
                                        if (P.slice_del(), P.ket = P.cursor, e = P.find_among_b(x, 6)) switch (P.bra = P.cursor, e) {
                                            case 1:
                                                l() && (P.slice_del(), P.ket = P.cursor, P.eq_s_b(2, "at") && (P.bra = P.cursor, l() && P.slice_del()));
                                                break;
                                            case 2:
                                                l() ? P.slice_del() : c() && P.slice_from("eux");
                                                break;
                                            case 3:
                                                l() && P.slice_del();
                                                break;
                                            case 4:
                                                a() && P.slice_from("i")
                                        }
                                        break;
                                    case 7:
                                        if (!l()) return !1;
                                        if (P.slice_del(), P.ket = P.cursor, e = P.find_among_b(S, 3)) switch (P.bra = P.cursor, e) {
                                            case 1:
                                                l() ? P.slice_del() : P.slice_from("abl");
                                                break;
                                            case 2:
                                                l() ? P.slice_del() : P.slice_from("iqU");
                                                break;
                                            case 3:
                                                l() && P.slice_del()
                                        }
                                        break;
                                    case 8:
                                        if (!l()) return !1;
                                        if (P.slice_del(), P.ket = P.cursor, P.eq_s_b(2, "at") && (P.bra = P.cursor, l() && (P.slice_del(), P.ket = P.cursor, P.eq_s_b(2, "ic")))) {
                                            P.bra = P.cursor, l() ? P.slice_del() : P.slice_from("iqU");
                                            break
                                        }
                                        break;
                                    case 9:
                                        P.slice_from("eau");
                                        break;
                                    case 10:
                                        if (!c()) return !1;
                                        P.slice_from("al");
                                        break;
                                    case 11:
                                        if (l()) P.slice_del();
                                        else {
                                            if (!c()) return !1;
                                            P.slice_from("eux")
                                        }
                                        break;
                                    case 12:
                                        if (!c() || !P.out_grouping_b(L, 97, 251)) return !1;
                                        P.slice_del();
                                        break;
                                    case 13:
                                        return a() && P.slice_from("ant"), !1;
                                    case 14:
                                        return a() && P.slice_from("ent"), !1;
                                    case 15:
                                        return r = P.limit - P.cursor, P.in_grouping_b(L, 97, 251) && a() && (P.cursor = P.limit - r, P.slice_del()), !1
                                }
                                return !0
                            }
                            return !1
                        }

                        function d() {
                            var e, r;
                            if (P.cursor < g) return !1;
                            if (r = P.limit_backward, P.limit_backward = g, P.ket = P.cursor, e = P.find_among_b(q, 35), !e) return P.limit_backward = r, !1;
                            if (P.bra = P.cursor, 1 == e) {
                                if (!P.out_grouping_b(L, 97, 251)) return P.limit_backward = r, !1;
                                P.slice_del()
                            }
                            return P.limit_backward = r, !0
                        }

                        function w() {
                            var e, r, n;
                            if (P.cursor < g) return !1;
                            if (r = P.limit_backward, P.limit_backward = g, P.ket = P.cursor, e = P.find_among_b(W, 38), !e) return P.limit_backward = r, !1;
                            switch (P.bra = P.cursor, e) {
                                case 1:
                                    if (!l()) return P.limit_backward = r, !1;
                                    P.slice_del();
                                    break;
                                case 2:
                                    P.slice_del();
                                    break;
                                case 3:
                                    P.slice_del(), n = P.limit - P.cursor, P.ket = P.cursor, P.eq_s_b(1, "e") ? (P.bra = P.cursor, P.slice_del()) : P.cursor = P.limit - n
                            }
                            return P.limit_backward = r, !0
                        }

                        function m() {
                            var e, r, n, t, i = P.limit - P.cursor;
                            if (P.ket = P.cursor, P.eq_s_b(1, "s") ? (P.bra = P.cursor, r = P.limit - P.cursor, P.out_grouping_b(C, 97, 232) ? (P.cursor = P.limit - r, P.slice_del()) : P.cursor = P.limit - i) : P.cursor = P.limit - i, P.cursor >= g) {
                                if (n = P.limit_backward, P.limit_backward = g, P.ket = P.cursor, e = P.find_among_b(z, 7)) switch (P.bra = P.cursor, e) {
                                    case 1:
                                        if (l()) {
                                            if (t = P.limit - P.cursor, !P.eq_s_b(1, "s") && (P.cursor = P.limit - t, !P.eq_s_b(1, "t"))) break;
                                            P.slice_del()
                                        }
                                        break;
                                    case 2:
                                        P.slice_from("i");
                                        break;
                                    case 3:
                                        P.slice_del();
                                        break;
                                    case 4:
                                        P.eq_s_b(2, "gu") && P.slice_del()
                                }
                                P.limit_backward = n
                            }
                        }

                        function p() {
                            var e = P.limit - P.cursor;
                            P.find_among_b(j, 5) && (P.cursor = P.limit - e, P.ket = P.cursor, P.cursor > P.limit_backward && (P.cursor--, P.bra = P.cursor, P.slice_del()))
                        }

                        function h() {
                            for (var e, r = 1; P.out_grouping_b(L, 97, 251);) r--;
                            if (r <= 0) {
                                if (P.ket = P.cursor, e = P.limit - P.cursor, !P.eq_s_b(1, "é") && (P.cursor = P.limit - e, !P.eq_s_b(1, "è"))) return;
                                P.bra = P.cursor, P.slice_from("e")
                            }
                        }

                        function b() {
                            return f() || (P.cursor = P.limit, d() || (P.cursor = P.limit, w())) ? (P.cursor = P.limit, P.ket = P.cursor, void(P.eq_s_b(1, "Y") ? (P.bra = P.cursor, P.slice_from("i")) : (P.cursor = P.limit, P.eq_s_b(1, "ç") && (P.bra = P.cursor, P.slice_from("c"))))) : (P.cursor = P.limit, void m())
                        }
                        var v, _, g, k = [new r("col", -1, -1), new r("par", -1, -1), new r("tap", -1, -1)],
                            y = [new r("", -1, 4), new r("I", 0, 1), new r("U", 0, 2), new r("Y", 0, 3)],
                            x = [new r("iqU", -1, 3), new r("abl", -1, 3), new r("Ièr", -1, 4), new r("ièr", -1, 4), new r("eus", -1, 2), new r("iv", -1, 1)],
                            S = [new r("ic", -1, 2), new r("abil", -1, 1), new r("iv", -1, 3)],
                            F = [new r("iqUe", -1, 1), new r("atrice", -1, 2), new r("ance", -1, 1), new r("ence", -1, 5), new r("logie", -1, 3), new r("able", -1, 1), new r("isme", -1, 1), new r("euse", -1, 11), new r("iste", -1, 1), new r("ive", -1, 8), new r("if", -1, 8), new r("usion", -1, 4), new r("ation", -1, 2), new r("ution", -1, 4), new r("ateur", -1, 2), new r("iqUes", -1, 1), new r("atrices", -1, 2), new r("ances", -1, 1), new r("ences", -1, 5), new r("logies", -1, 3), new r("ables", -1, 1), new r("ismes", -1, 1), new r("euses", -1, 11), new r("istes", -1, 1), new r("ives", -1, 8), new r("ifs", -1, 8), new r("usions", -1, 4), new r("ations", -1, 2), new r("utions", -1, 4), new r("ateurs", -1, 2), new r("ments", -1, 15), new r("ements", 30, 6), new r("issements", 31, 12), new r("ités", -1, 7), new r("ment", -1, 15), new r("ement", 34, 6), new r("issement", 35, 12), new r("amment", 34, 13), new r("emment", 34, 14), new r("aux", -1, 10), new r("eaux", 39, 9), new r("eux", -1, 1), new r("ité", -1, 7)],
                            q = [new r("ira", -1, 1), new r("ie", -1, 1), new r("isse", -1, 1), new r("issante", -1, 1), new r("i", -1, 1), new r("irai", 4, 1), new r("ir", -1, 1), new r("iras", -1, 1), new r("ies", -1, 1), new r("îmes", -1, 1), new r("isses", -1, 1), new r("issantes", -1, 1), new r("îtes", -1, 1), new r("is", -1, 1), new r("irais", 13, 1), new r("issais", 13, 1), new r("irions", -1, 1), new r("issions", -1, 1), new r("irons", -1, 1), new r("issons", -1, 1), new r("issants", -1, 1), new r("it", -1, 1), new r("irait", 21, 1), new r("issait", 21, 1), new r("issant", -1, 1), new r("iraIent", -1, 1), new r("issaIent", -1, 1), new r("irent", -1, 1), new r("issent", -1, 1), new r("iront", -1, 1), new r("ît", -1, 1), new r("iriez", -1, 1), new r("issiez", -1, 1), new r("irez", -1, 1), new r("issez", -1, 1)],
                            W = [new r("a", -1, 3), new r("era", 0, 2), new r("asse", -1, 3), new r("ante", -1, 3), new r("ée", -1, 2), new r("ai", -1, 3), new r("erai", 5, 2), new r("er", -1, 2), new r("as", -1, 3), new r("eras", 8, 2), new r("âmes", -1, 3), new r("asses", -1, 3), new r("antes", -1, 3), new r("âtes", -1, 3), new r("ées", -1, 2), new r("ais", -1, 3), new r("erais", 15, 2), new r("ions", -1, 1), new r("erions", 17, 2), new r("assions", 17, 3), new r("erons", -1, 2), new r("ants", -1, 3), new r("és", -1, 2), new r("ait", -1, 3), new r("erait", 23, 2), new r("ant", -1, 3), new r("aIent", -1, 3), new r("eraIent", 26, 2), new r("èrent", -1, 2), new r("assent", -1, 3), new r("eront", -1, 2), new r("ât", -1, 3), new r("ez", -1, 2), new r("iez", 32, 2), new r("eriez", 33, 2), new r("assiez", 33, 3), new r("erez", 32, 2), new r("é", -1, 2)],
                            z = [new r("e", -1, 3), new r("Ière", 0, 2), new r("ière", 0, 2), new r("ion", -1, 1), new r("Ier", -1, 2), new r("ier", -1, 2), new r("ë", -1, 4)],
                            j = [new r("ell", -1, -1), new r("eill", -1, -1), new r("enn", -1, -1), new r("onn", -1, -1), new r("ett", -1, -1)],
                            L = [17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 130, 103, 8, 5],
                            C = [1, 65, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128],
                            P = new n;
                        this.setCurrent = function(e) {
                            P.setCurrent(e)
                        }, this.getCurrent = function() {
                            return P.getCurrent()
                        }, this.stem = function() {
                            var e = P.cursor;
                            return i(), P.cursor = e, s(), P.limit_backward = e, P.cursor = P.limit, b(), P.cursor = P.limit, p(), P.cursor = P.limit, h(), P.cursor = P.limit_backward, u(), !0
                        }
                    };
                return function(e) {
                    return t.setCurrent(e), t.stem(), t.getCurrent()
                }
            }(), e.Pipeline.registerFunction(e.fr.stemmer, "stemmer-fr"), e.fr.stopWordFilter = function(r) {
                if (e.fr.stopWordFilter.stopWords.indexOf(r) === -1) return r
            }, e.fr.stopWordFilter.stopWords = new e.SortedSet, e.fr.stopWordFilter.stopWords.length = 164, e.fr.stopWordFilter.stopWords.elements = " ai aie aient aies ait as au aura aurai auraient aurais aurait auras aurez auriez aurions aurons auront aux avaient avais avait avec avez aviez avions avons ayant ayez ayons c ce ceci celà ces cet cette d dans de des du elle en es est et eu eue eues eurent eus eusse eussent eusses eussiez eussions eut eux eûmes eût eûtes furent fus fusse fussent fusses fussiez fussions fut fûmes fût fûtes ici il ils j je l la le les leur leurs lui m ma mais me mes moi mon même n ne nos notre nous on ont ou par pas pour qu que quel quelle quelles quels qui s sa sans se sera serai seraient serais serait seras serez seriez serions serons seront ses soi soient sois soit sommes son sont soyez soyons suis sur t ta te tes toi ton tu un une vos votre vous y à étaient étais était étant étiez étions été étée étées étés êtes".split(" "), e.Pipeline.registerFunction(e.fr.stopWordFilter, "stopWordFilter-fr")
        }
    })
}, function(e, r, n) {
    var t, i;
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(this, function() {
        return function(e) {
            if ("undefined" == typeof e) throw new Error("Lunr is not present. Please include / require Lunr before this script.");
            if ("undefined" == typeof e.stemmerSupport) throw new Error("Lunr stemmer support is not present. Please include / require Lunr stemmer support before this script.");
            e.hu = function() {
                this.pipeline.reset(), this.pipeline.add(e.hu.stopWordFilter, e.hu.stemmer)
            }, e.hu.stemmer = function() {
                var r = e.stemmerSupport.Among,
                    n = e.stemmerSupport.SnowballProgram,
                    t = new function() {
                        function e() {
                            var e, r = L.cursor;
                            if (h = L.limit, L.in_grouping(j, 97, 252))
                                for (;;) {
                                    if (e = L.cursor, L.out_grouping(j, 97, 252)) return L.cursor = e, L.find_among(b, 8) || (L.cursor = e, e < L.limit && L.cursor++), void(h = L.cursor);
                                    if (L.cursor = e, e >= L.limit) return void(h = e);
                                    L.cursor++
                                }
                            if (L.cursor = r, L.out_grouping(j, 97, 252)) {
                                for (; !L.in_grouping(j, 97, 252);) {
                                    if (L.cursor >= L.limit) return;
                                    L.cursor++
                                }
                                h = L.cursor
                            }
                        }

                        function t() {
                            return h <= L.cursor
                        }

                        function i() {
                            var e;
                            if (L.ket = L.cursor, e = L.find_among_b(v, 2), e && (L.bra = L.cursor, t())) switch (e) {
                                case 1:
                                    L.slice_from("a");
                                    break;
                                case 2:
                                    L.slice_from("e")
                            }
                        }

                        function o() {
                            var e = L.limit - L.cursor;
                            return !!L.find_among_b(_, 23) && (L.cursor = L.limit - e, !0)
                        }

                        function s() {
                            if (L.cursor > L.limit_backward) {
                                L.cursor--, L.ket = L.cursor;
                                var e = L.cursor - 1;
                                L.limit_backward <= e && e <= L.limit && (L.cursor = e, L.bra = e, L.slice_del())
                            }
                        }

                        function u() {
                            var e;
                            if (L.ket = L.cursor, e = L.find_among_b(g, 2), e && (L.bra = L.cursor, t())) {
                                if ((1 == e || 2 == e) && !o()) return;
                                L.slice_del(), s()
                            }
                        }

                        function a() {
                            L.ket = L.cursor, L.find_among_b(k, 44) && (L.bra = L.cursor, t() && (L.slice_del(), i()))
                        }

                        function c() {
                            var e;
                            if (L.ket = L.cursor, e = L.find_among_b(y, 3), e && (L.bra = L.cursor, t())) switch (e) {
                                case 1:
                                    L.slice_from("e");
                                    break;
                                case 2:
                                case 3:
                                    L.slice_from("a")
                            }
                        }

                        function l() {
                            var e;
                            if (L.ket = L.cursor, e = L.find_among_b(x, 6), e && (L.bra = L.cursor, t())) switch (e) {
                                case 1:
                                case 2:
                                    L.slice_del();
                                    break;
                                case 3:
                                    L.slice_from("a");
                                    break;
                                case 4:
                                    L.slice_from("e")
                            }
                        }

                        function f() {
                            var e;
                            if (L.ket = L.cursor, e = L.find_among_b(S, 2), e && (L.bra = L.cursor, t())) {
                                if ((1 == e || 2 == e) && !o()) return;
                                L.slice_del(), s()
                            }
                        }

                        function d() {
                            var e;
                            if (L.ket = L.cursor, e = L.find_among_b(F, 7), e && (L.bra = L.cursor, t())) switch (e) {
                                case 1:
                                    L.slice_from("a");
                                    break;
                                case 2:
                                    L.slice_from("e");
                                    break;
                                case 3:
                                case 4:
                                case 5:
                                case 6:
                                case 7:
                                    L.slice_del()
                            }
                        }

                        function w() {
                            var e;
                            if (L.ket = L.cursor, e = L.find_among_b(q, 12), e && (L.bra = L.cursor, t())) switch (e) {
                                case 1:
                                case 4:
                                case 7:
                                case 9:
                                    L.slice_del();
                                    break;
                                case 2:
                                case 5:
                                case 8:
                                    L.slice_from("e");
                                    break;
                                case 3:
                                case 6:
                                    L.slice_from("a")
                            }
                        }

                        function m() {
                            var e;
                            if (L.ket = L.cursor, e = L.find_among_b(W, 31), e && (L.bra = L.cursor, t())) switch (e) {
                                case 1:
                                case 4:
                                case 7:
                                case 8:
                                case 9:
                                case 12:
                                case 13:
                                case 16:
                                case 17:
                                case 18:
                                    L.slice_del();
                                    break;
                                case 2:
                                case 5:
                                case 10:
                                case 14:
                                case 19:
                                    L.slice_from("a");
                                    break;
                                case 3:
                                case 6:
                                case 11:
                                case 15:
                                case 20:
                                    L.slice_from("e")
                            }
                        }

                        function p() {
                            var e;
                            if (L.ket = L.cursor, e = L.find_among_b(z, 42), e && (L.bra = L.cursor, t())) switch (e) {
                                case 1:
                                case 4:
                                case 5:
                                case 6:
                                case 9:
                                case 10:
                                case 11:
                                case 14:
                                case 15:
                                case 16:
                                case 17:
                                case 20:
                                case 21:
                                case 24:
                                case 25:
                                case 26:
                                case 29:
                                    L.slice_del();
                                    break;
                                case 2:
                                case 7:
                                case 12:
                                case 18:
                                case 22:
                                case 27:
                                    L.slice_from("a");
                                    break;
                                case 3:
                                case 8:
                                case 13:
                                case 19:
                                case 23:
                                case 28:
                                    L.slice_from("e")
                            }
                        }
                        var h, b = [new r("cs", -1, -1), new r("dzs", -1, -1), new r("gy", -1, -1), new r("ly", -1, -1), new r("ny", -1, -1), new r("sz", -1, -1), new r("ty", -1, -1), new r("zs", -1, -1)],
                            v = [new r("á", -1, 1), new r("é", -1, 2)],
                            _ = [new r("bb", -1, -1), new r("cc", -1, -1), new r("dd", -1, -1), new r("ff", -1, -1), new r("gg", -1, -1), new r("jj", -1, -1), new r("kk", -1, -1), new r("ll", -1, -1), new r("mm", -1, -1), new r("nn", -1, -1), new r("pp", -1, -1), new r("rr", -1, -1), new r("ccs", -1, -1), new r("ss", -1, -1), new r("zzs", -1, -1), new r("tt", -1, -1), new r("vv", -1, -1), new r("ggy", -1, -1), new r("lly", -1, -1), new r("nny", -1, -1), new r("tty", -1, -1), new r("ssz", -1, -1), new r("zz", -1, -1)],
                            g = [new r("al", -1, 1), new r("el", -1, 2)],
                            k = [new r("ba", -1, -1), new r("ra", -1, -1), new r("be", -1, -1), new r("re", -1, -1), new r("ig", -1, -1), new r("nak", -1, -1), new r("nek", -1, -1), new r("val", -1, -1), new r("vel", -1, -1), new r("ul", -1, -1), new r("nál", -1, -1), new r("nél", -1, -1), new r("ból", -1, -1), new r("ról", -1, -1), new r("tól", -1, -1), new r("bõl", -1, -1), new r("rõl", -1, -1), new r("tõl", -1, -1), new r("ül", -1, -1), new r("n", -1, -1), new r("an", 19, -1), new r("ban", 20, -1), new r("en", 19, -1), new r("ben", 22, -1), new r("képpen", 22, -1), new r("on", 19, -1), new r("ön", 19, -1), new r("képp", -1, -1), new r("kor", -1, -1), new r("t", -1, -1), new r("at", 29, -1), new r("et", 29, -1), new r("ként", 29, -1), new r("anként", 32, -1), new r("enként", 32, -1), new r("onként", 32, -1), new r("ot", 29, -1), new r("ért", 29, -1), new r("öt", 29, -1), new r("hez", -1, -1), new r("hoz", -1, -1), new r("höz", -1, -1), new r("vá", -1, -1), new r("vé", -1, -1)],
                            y = [new r("án", -1, 2), new r("én", -1, 1), new r("ánként", -1, 3)],
                            x = [new r("stul", -1, 2), new r("astul", 0, 1), new r("ástul", 0, 3), new r("stül", -1, 2), new r("estül", 3, 1), new r("éstül", 3, 4)],
                            S = [new r("á", -1, 1), new r("é", -1, 2)],
                            F = [new r("k", -1, 7), new r("ak", 0, 4), new r("ek", 0, 6), new r("ok", 0, 5), new r("ák", 0, 1), new r("ék", 0, 2), new r("ök", 0, 3)],
                            q = [new r("éi", -1, 7), new r("áéi", 0, 6), new r("ééi", 0, 5), new r("é", -1, 9), new r("ké", 3, 4), new r("aké", 4, 1), new r("eké", 4, 1), new r("oké", 4, 1), new r("áké", 4, 3), new r("éké", 4, 2), new r("öké", 4, 1), new r("éé", 3, 8)],
                            W = [new r("a", -1, 18), new r("ja", 0, 17), new r("d", -1, 16), new r("ad", 2, 13), new r("ed", 2, 13), new r("od", 2, 13), new r("ád", 2, 14), new r("éd", 2, 15), new r("öd", 2, 13), new r("e", -1, 18), new r("je", 9, 17), new r("nk", -1, 4), new r("unk", 11, 1), new r("ánk", 11, 2), new r("énk", 11, 3), new r("ünk", 11, 1), new r("uk", -1, 8), new r("juk", 16, 7), new r("ájuk", 17, 5), new r("ük", -1, 8), new r("jük", 19, 7), new r("éjük", 20, 6), new r("m", -1, 12), new r("am", 22, 9), new r("em", 22, 9), new r("om", 22, 9), new r("ám", 22, 10), new r("ém", 22, 11), new r("o", -1, 18), new r("á", -1, 19), new r("é", -1, 20)],
                            z = [new r("id", -1, 10), new r("aid", 0, 9), new r("jaid", 1, 6), new r("eid", 0, 9), new r("jeid", 3, 6), new r("áid", 0, 7), new r("éid", 0, 8), new r("i", -1, 15), new r("ai", 7, 14), new r("jai", 8, 11), new r("ei", 7, 14), new r("jei", 10, 11), new r("ái", 7, 12), new r("éi", 7, 13), new r("itek", -1, 24), new r("eitek", 14, 21), new r("jeitek", 15, 20), new r("éitek", 14, 23), new r("ik", -1, 29), new r("aik", 18, 26), new r("jaik", 19, 25), new r("eik", 18, 26), new r("jeik", 21, 25), new r("áik", 18, 27), new r("éik", 18, 28), new r("ink", -1, 20), new r("aink", 25, 17), new r("jaink", 26, 16), new r("eink", 25, 17), new r("jeink", 28, 16), new r("áink", 25, 18), new r("éink", 25, 19), new r("aitok", -1, 21), new r("jaitok", 32, 20), new r("áitok", -1, 22), new r("im", -1, 5), new r("aim", 35, 4), new r("jaim", 36, 1), new r("eim", 35, 4), new r("jeim", 38, 1), new r("áim", 35, 2), new r("éim", 35, 3)],
                            j = [17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 17, 52, 14],
                            L = new n;
                        this.setCurrent = function(e) {
                            L.setCurrent(e)
                        }, this.getCurrent = function() {
                            return L.getCurrent()
                        }, this.stem = function() {
                            var r = L.cursor;
                            return e(), L.limit_backward = r, L.cursor = L.limit, u(), L.cursor = L.limit, a(), L.cursor = L.limit, c(), L.cursor = L.limit, l(), L.cursor = L.limit, f(), L.cursor = L.limit, w(), L.cursor = L.limit, m(), L.cursor = L.limit, p(), L.cursor = L.limit, d(), !0
                        }
                    };
                return function(e) {
                    return t.setCurrent(e), t.stem(), t.getCurrent()
                }
            }(), e.Pipeline.registerFunction(e.hu.stemmer, "stemmer-hu"), e.hu.stopWordFilter = function(r) {
                if (e.hu.stopWordFilter.stopWords.indexOf(r) === -1) return r
            }, e.hu.stopWordFilter.stopWords = new e.SortedSet, e.hu.stopWordFilter.stopWords.length = 200, e.hu.stopWordFilter.stopWords.elements = " a abban ahhoz ahogy ahol aki akik akkor alatt amely amelyek amelyekben amelyeket amelyet amelynek ami amikor amit amolyan amíg annak arra arról az azok azon azonban azt aztán azután azzal azért be belül benne bár cikk cikkek cikkeket csak de e ebben eddig egy egyes egyetlen egyik egyre egyéb egész ehhez ekkor el ellen elsõ elég elõ elõször elõtt emilyen ennek erre ez ezek ezen ezt ezzel ezért fel felé hanem hiszen hogy hogyan igen ill ill. illetve ilyen ilyenkor ismét ison itt jobban jó jól kell kellett keressünk keresztül ki kívül között közül legalább legyen lehet lehetett lenne lenni lesz lett maga magát majd majd meg mellett mely melyek mert mi mikor milyen minden mindenki mindent mindig mint mintha mit mivel miért most már más másik még míg nagy nagyobb nagyon ne nekem neki nem nincs néha néhány nélkül olyan ott pedig persze rá s saját sem semmi sok sokat sokkal szemben szerint szinte számára talán tehát teljes tovább továbbá több ugyanis utolsó után utána vagy vagyis vagyok valaki valami valamint való van vannak vele vissza viszont volna volt voltak voltam voltunk által általában át én éppen és így õ õk õket össze úgy új újabb újra".split(" "), e.Pipeline.registerFunction(e.hu.stopWordFilter, "stopWordFilter-hu")
        }
    })
}, function(e, r, n) {
    var t, i;
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(this, function() {
        return function(e) {
            if ("undefined" == typeof e) throw new Error("Lunr is not present. Please include / require Lunr before this script.");
            if ("undefined" == typeof e.stemmerSupport) throw new Error("Lunr stemmer support is not present. Please include / require Lunr stemmer support before this script.");
            e.it = function() {
                this.pipeline.reset(), this.pipeline.add(e.it.stopWordFilter, e.it.stemmer)
            }, e.it.stemmer = function() {
                var r = e.stemmerSupport.Among,
                    n = e.stemmerSupport.SnowballProgram,
                    t = new function() {
                        function e(e, r, n) {
                            return !(!P.eq_s(1, e) || (P.ket = P.cursor, !P.in_grouping(j, 97, 249))) && (P.slice_from(r), P.cursor = n, !0)
                        }

                        function t() {
                            for (var r, n, t, i, o = P.cursor;;) {
                                if (P.bra = P.cursor, r = P.find_among(k, 7)) switch (P.ket = P.cursor, r) {
                                    case 1:
                                        P.slice_from("à");
                                        continue;
                                    case 2:
                                        P.slice_from("è");
                                        continue;
                                    case 3:
                                        P.slice_from("ì");
                                        continue;
                                    case 4:
                                        P.slice_from("ò");
                                        continue;
                                    case 5:
                                        P.slice_from("ù");
                                        continue;
                                    case 6:
                                        P.slice_from("qU");
                                        continue;
                                    case 7:
                                        if (P.cursor >= P.limit) break;
                                        P.cursor++;
                                        continue
                                }
                                break
                            }
                            for (P.cursor = o;;)
                                for (n = P.cursor;;) {
                                    if (t = P.cursor, P.in_grouping(j, 97, 249)) {
                                        if (P.bra = P.cursor, i = P.cursor, e("u", "U", t)) break;
                                        if (P.cursor = i, e("i", "I", t)) break
                                    }
                                    if (P.cursor = t, P.cursor >= P.limit) return void(P.cursor = n);
                                    P.cursor++
                                }
                        }

                        function i(e) {
                            if (P.cursor = e, !P.in_grouping(j, 97, 249)) return !1;
                            for (; !P.out_grouping(j, 97, 249);) {
                                if (P.cursor >= P.limit) return !1;
                                P.cursor++
                            }
                            return !0
                        }

                        function o() {
                            if (P.in_grouping(j, 97, 249)) {
                                var e = P.cursor;
                                if (P.out_grouping(j, 97, 249)) {
                                    for (; !P.in_grouping(j, 97, 249);) {
                                        if (P.cursor >= P.limit) return i(e);
                                        P.cursor++
                                    }
                                    return !0
                                }
                                return i(e)
                            }
                            return !1
                        }

                        function s() {
                            var e, r = P.cursor;
                            if (!o()) {
                                if (P.cursor = r, !P.out_grouping(j, 97, 249)) return;
                                if (e = P.cursor, P.out_grouping(j, 97, 249)) {
                                    for (; !P.in_grouping(j, 97, 249);) {
                                        if (P.cursor >= P.limit) return P.cursor = e, void(P.in_grouping(j, 97, 249) && P.cursor < P.limit && P.cursor++);
                                        P.cursor++
                                    }
                                    return void(g = P.cursor)
                                }
                                if (P.cursor = e, !P.in_grouping(j, 97, 249) || P.cursor >= P.limit) return;
                                P.cursor++
                            }
                            g = P.cursor
                        }

                        function u() {
                            for (; !P.in_grouping(j, 97, 249);) {
                                if (P.cursor >= P.limit) return !1;
                                P.cursor++
                            }
                            for (; !P.out_grouping(j, 97, 249);) {
                                if (P.cursor >= P.limit) return !1;
                                P.cursor++
                            }
                            return !0
                        }

                        function a() {
                            var e = P.cursor;
                            g = P.limit, _ = g, v = g, s(), P.cursor = e, u() && (_ = P.cursor, u() && (v = P.cursor))
                        }

                        function c() {
                            for (var e;;) {
                                if (P.bra = P.cursor, e = P.find_among(y, 3), !e) break;
                                switch (P.ket = P.cursor, e) {
                                    case 1:
                                        P.slice_from("i");
                                        break;
                                    case 2:
                                        P.slice_from("u");
                                        break;
                                    case 3:
                                        if (P.cursor >= P.limit) return;
                                        P.cursor++
                                }
                            }
                        }

                        function l() {
                            return g <= P.cursor
                        }

                        function f() {
                            return _ <= P.cursor
                        }

                        function d() {
                            return v <= P.cursor
                        }

                        function w() {
                            var e;
                            if (P.ket = P.cursor, P.find_among_b(x, 37) && (P.bra = P.cursor, e = P.find_among_b(S, 5), e && l())) switch (e) {
                                case 1:
                                    P.slice_del();
                                    break;
                                case 2:
                                    P.slice_from("e")
                            }
                        }

                        function m() {
                            var e;
                            if (P.ket = P.cursor, e = P.find_among_b(W, 51), !e) return !1;
                            switch (P.bra = P.cursor, e) {
                                case 1:
                                    if (!d()) return !1;
                                    P.slice_del();
                                    break;
                                case 2:
                                    if (!d()) return !1;
                                    P.slice_del(), P.ket = P.cursor, P.eq_s_b(2, "ic") && (P.bra = P.cursor, d() && P.slice_del());
                                    break;
                                case 3:
                                    if (!d()) return !1;
                                    P.slice_from("log");
                                    break;
                                case 4:
                                    if (!d()) return !1;
                                    P.slice_from("u");
                                    break;
                                case 5:
                                    if (!d()) return !1;
                                    P.slice_from("ente");
                                    break;
                                case 6:
                                    if (!l()) return !1;
                                    P.slice_del();
                                    break;
                                case 7:
                                    if (!f()) return !1;
                                    P.slice_del(), P.ket = P.cursor, e = P.find_among_b(F, 4), e && (P.bra = P.cursor, d() && (P.slice_del(), 1 == e && (P.ket = P.cursor, P.eq_s_b(2, "at") && (P.bra = P.cursor, d() && P.slice_del()))));
                                    break;
                                case 8:
                                    if (!d()) return !1;
                                    P.slice_del(), P.ket = P.cursor, e = P.find_among_b(q, 3), e && (P.bra = P.cursor, 1 == e && d() && P.slice_del());
                                    break;
                                case 9:
                                    if (!d()) return !1;
                                    P.slice_del(), P.ket = P.cursor, P.eq_s_b(2, "at") && (P.bra = P.cursor, d() && (P.slice_del(), P.ket = P.cursor, P.eq_s_b(2, "ic") && (P.bra = P.cursor, d() && P.slice_del())))
                            }
                            return !0
                        }

                        function p() {
                            var e, r;
                            P.cursor >= g && (r = P.limit_backward, P.limit_backward = g, P.ket = P.cursor, e = P.find_among_b(z, 87), e && (P.bra = P.cursor, 1 == e && P.slice_del()), P.limit_backward = r)
                        }

                        function h() {
                            var e = P.limit - P.cursor;
                            return P.ket = P.cursor, P.in_grouping_b(L, 97, 242) && (P.bra = P.cursor, l() && (P.slice_del(), P.ket = P.cursor, P.eq_s_b(1, "i") && (P.bra = P.cursor, l()))) ? void P.slice_del() : void(P.cursor = P.limit - e)
                        }

                        function b() {
                            h(), P.ket = P.cursor, P.eq_s_b(1, "h") && (P.bra = P.cursor, P.in_grouping_b(C, 99, 103) && l() && P.slice_del())
                        }
                        var v, _, g, k = [new r("", -1, 7), new r("qu", 0, 6), new r("á", 0, 1), new r("é", 0, 2), new r("í", 0, 3), new r("ó", 0, 4), new r("ú", 0, 5)],
                            y = [new r("", -1, 3), new r("I", 0, 1), new r("U", 0, 2)],
                            x = [new r("la", -1, -1), new r("cela", 0, -1), new r("gliela", 0, -1), new r("mela", 0, -1), new r("tela", 0, -1), new r("vela", 0, -1), new r("le", -1, -1), new r("cele", 6, -1), new r("gliele", 6, -1), new r("mele", 6, -1), new r("tele", 6, -1), new r("vele", 6, -1), new r("ne", -1, -1), new r("cene", 12, -1), new r("gliene", 12, -1), new r("mene", 12, -1), new r("sene", 12, -1), new r("tene", 12, -1), new r("vene", 12, -1), new r("ci", -1, -1), new r("li", -1, -1), new r("celi", 20, -1), new r("glieli", 20, -1), new r("meli", 20, -1), new r("teli", 20, -1), new r("veli", 20, -1), new r("gli", 20, -1), new r("mi", -1, -1), new r("si", -1, -1), new r("ti", -1, -1), new r("vi", -1, -1), new r("lo", -1, -1), new r("celo", 31, -1), new r("glielo", 31, -1), new r("melo", 31, -1), new r("telo", 31, -1), new r("velo", 31, -1)],
                            S = [new r("ando", -1, 1), new r("endo", -1, 1), new r("ar", -1, 2), new r("er", -1, 2), new r("ir", -1, 2)],
                            F = [new r("ic", -1, -1), new r("abil", -1, -1), new r("os", -1, -1), new r("iv", -1, 1)],
                            q = [new r("ic", -1, 1), new r("abil", -1, 1), new r("iv", -1, 1)],
                            W = [new r("ica", -1, 1), new r("logia", -1, 3), new r("osa", -1, 1), new r("ista", -1, 1), new r("iva", -1, 9), new r("anza", -1, 1), new r("enza", -1, 5), new r("ice", -1, 1), new r("atrice", 7, 1), new r("iche", -1, 1), new r("logie", -1, 3), new r("abile", -1, 1), new r("ibile", -1, 1), new r("usione", -1, 4), new r("azione", -1, 2), new r("uzione", -1, 4), new r("atore", -1, 2), new r("ose", -1, 1), new r("ante", -1, 1), new r("mente", -1, 1), new r("amente", 19, 7), new r("iste", -1, 1), new r("ive", -1, 9), new r("anze", -1, 1), new r("enze", -1, 5), new r("ici", -1, 1), new r("atrici", 25, 1), new r("ichi", -1, 1), new r("abili", -1, 1), new r("ibili", -1, 1), new r("ismi", -1, 1), new r("usioni", -1, 4), new r("azioni", -1, 2), new r("uzioni", -1, 4), new r("atori", -1, 2), new r("osi", -1, 1), new r("anti", -1, 1), new r("amenti", -1, 6), new r("imenti", -1, 6), new r("isti", -1, 1), new r("ivi", -1, 9), new r("ico", -1, 1), new r("ismo", -1, 1), new r("oso", -1, 1), new r("amento", -1, 6), new r("imento", -1, 6), new r("ivo", -1, 9), new r("ità", -1, 8), new r("istà", -1, 1), new r("istè", -1, 1), new r("istì", -1, 1)],
                            z = [new r("isca", -1, 1), new r("enda", -1, 1), new r("ata", -1, 1), new r("ita", -1, 1), new r("uta", -1, 1), new r("ava", -1, 1), new r("eva", -1, 1), new r("iva", -1, 1), new r("erebbe", -1, 1), new r("irebbe", -1, 1), new r("isce", -1, 1), new r("ende", -1, 1), new r("are", -1, 1), new r("ere", -1, 1), new r("ire", -1, 1), new r("asse", -1, 1), new r("ate", -1, 1), new r("avate", 16, 1), new r("evate", 16, 1), new r("ivate", 16, 1), new r("ete", -1, 1), new r("erete", 20, 1), new r("irete", 20, 1), new r("ite", -1, 1), new r("ereste", -1, 1), new r("ireste", -1, 1), new r("ute", -1, 1), new r("erai", -1, 1), new r("irai", -1, 1), new r("isci", -1, 1), new r("endi", -1, 1), new r("erei", -1, 1), new r("irei", -1, 1), new r("assi", -1, 1), new r("ati", -1, 1), new r("iti", -1, 1), new r("eresti", -1, 1), new r("iresti", -1, 1), new r("uti", -1, 1), new r("avi", -1, 1), new r("evi", -1, 1), new r("ivi", -1, 1), new r("isco", -1, 1), new r("ando", -1, 1), new r("endo", -1, 1), new r("Yamo", -1, 1), new r("iamo", -1, 1), new r("avamo", -1, 1), new r("evamo", -1, 1), new r("ivamo", -1, 1), new r("eremo", -1, 1), new r("iremo", -1, 1), new r("assimo", -1, 1), new r("ammo", -1, 1), new r("emmo", -1, 1), new r("eremmo", 54, 1), new r("iremmo", 54, 1), new r("immo", -1, 1), new r("ano", -1, 1), new r("iscano", 58, 1), new r("avano", 58, 1), new r("evano", 58, 1), new r("ivano", 58, 1), new r("eranno", -1, 1), new r("iranno", -1, 1), new r("ono", -1, 1), new r("iscono", 65, 1), new r("arono", 65, 1), new r("erono", 65, 1), new r("irono", 65, 1), new r("erebbero", -1, 1), new r("irebbero", -1, 1), new r("assero", -1, 1), new r("essero", -1, 1), new r("issero", -1, 1), new r("ato", -1, 1), new r("ito", -1, 1), new r("uto", -1, 1), new r("avo", -1, 1), new r("evo", -1, 1), new r("ivo", -1, 1), new r("ar", -1, 1), new r("ir", -1, 1), new r("erà", -1, 1), new r("irà", -1, 1), new r("erò", -1, 1), new r("irò", -1, 1)],
                            j = [17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 128, 8, 2, 1],
                            L = [17, 65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 128, 8, 2],
                            C = [17],
                            P = new n;
                        this.setCurrent = function(e) {
                            P.setCurrent(e)
                        }, this.getCurrent = function() {
                            return P.getCurrent()
                        }, this.stem = function() {
                            var e = P.cursor;
                            return t(), P.cursor = e, a(), P.limit_backward = e, P.cursor = P.limit, w(), P.cursor = P.limit, m() || (P.cursor = P.limit, p()), P.cursor = P.limit, b(), P.cursor = P.limit_backward, c(), !0
                        }
                    };
                return function(e) {
                    return t.setCurrent(e), t.stem(), t.getCurrent()
                }
            }(), e.Pipeline.registerFunction(e.it.stemmer, "stemmer-it"), e.it.stopWordFilter = function(r) {
                if (e.it.stopWordFilter.stopWords.indexOf(r) === -1) return r
            }, e.it.stopWordFilter.stopWords = new e.SortedSet, e.it.stopWordFilter.stopWords.length = 280, e.it.stopWordFilter.stopWords.elements = " a abbia abbiamo abbiano abbiate ad agl agli ai al all alla alle allo anche avemmo avendo avesse avessero avessi avessimo aveste avesti avete aveva avevamo avevano avevate avevi avevo avrai avranno avrebbe avrebbero avrei avremmo avremo avreste avresti avrete avrà avrò avuta avute avuti avuto c che chi ci coi col come con contro cui da dagl dagli dai dal dall dalla dalle dallo degl degli dei del dell della delle dello di dov dove e ebbe ebbero ebbi ed era erano eravamo eravate eri ero essendo faccia facciamo facciano facciate faccio facemmo facendo facesse facessero facessi facessimo faceste facesti faceva facevamo facevano facevate facevi facevo fai fanno farai faranno farebbe farebbero farei faremmo faremo fareste faresti farete farà farò fece fecero feci fosse fossero fossi fossimo foste fosti fu fui fummo furono gli ha hai hanno ho i il in io l la le lei li lo loro lui ma mi mia mie miei mio ne negl negli nei nel nell nella nelle nello noi non nostra nostre nostri nostro o per perché più quale quanta quante quanti quanto quella quelle quelli quello questa queste questi questo sarai saranno sarebbe sarebbero sarei saremmo saremo sareste saresti sarete sarà sarò se sei si sia siamo siano siate siete sono sta stai stando stanno starai staranno starebbe starebbero starei staremmo staremo stareste staresti starete starà starò stava stavamo stavano stavate stavi stavo stemmo stesse stessero stessi stessimo steste stesti stette stettero stetti stia stiamo stiano stiate sto su sua sue sugl sugli sui sul sull sulla sulle sullo suo suoi ti tra tu tua tue tuo tuoi tutti tutto un una uno vi voi vostra vostre vostri vostro è".split(" "), e.Pipeline.registerFunction(e.it.stopWordFilter, "stopWordFilter-it")
        }
    })
}, function(e, r, n) {
    var t, i;
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(this, function() {
        return function(e) {
            if ("undefined" == typeof e) throw new Error("Lunr is not present. Please include / require Lunr before this script.");
            if ("undefined" == typeof e.stemmerSupport) throw new Error("Lunr stemmer support is not present. Please include / require Lunr stemmer support before this script.");
            e.no = function() {
                this.pipeline.reset(), this.pipeline.add(e.no.stopWordFilter, e.no.stemmer)
            }, e.no.stemmer = function() {
                var r = e.stemmerSupport.Among,
                    n = e.stemmerSupport.SnowballProgram,
                    t = new function() {
                        function e() {
                            var e, r = w.cursor + 3;
                            if (u = w.limit, 0 <= r || r <= w.limit) {
                                for (s = r;;) {
                                    if (e = w.cursor, w.in_grouping(f, 97, 248)) {
                                        w.cursor = e;
                                        break
                                    }
                                    if (e >= w.limit) return;
                                    w.cursor = e + 1
                                }
                                for (; !w.out_grouping(f, 97, 248);) {
                                    if (w.cursor >= w.limit) return;
                                    w.cursor++
                                }
                                u = w.cursor, u < s && (u = s)
                            }
                        }

                        function t() {
                            var e, r, n;
                            if (w.cursor >= u && (r = w.limit_backward, w.limit_backward = u, w.ket = w.cursor, e = w.find_among_b(a, 29), w.limit_backward = r, e)) switch (w.bra = w.cursor, e) {
                                case 1:
                                    w.slice_del();
                                    break;
                                case 2:
                                    n = w.limit - w.cursor, w.in_grouping_b(d, 98, 122) ? w.slice_del() : (w.cursor = w.limit - n, w.eq_s_b(1, "k") && w.out_grouping_b(f, 97, 248) && w.slice_del());
                                    break;
                                case 3:
                                    w.slice_from("er")
                            }
                        }

                        function i() {
                            var e, r = w.limit - w.cursor;
                            w.cursor >= u && (e = w.limit_backward, w.limit_backward = u, w.ket = w.cursor, w.find_among_b(c, 2) ? (w.bra = w.cursor, w.limit_backward = e, w.cursor = w.limit - r, w.cursor > w.limit_backward && (w.cursor--, w.bra = w.cursor, w.slice_del())) : w.limit_backward = e)
                        }

                        function o() {
                            var e, r;
                            w.cursor >= u && (r = w.limit_backward, w.limit_backward = u, w.ket = w.cursor, e = w.find_among_b(l, 11), e ? (w.bra = w.cursor, w.limit_backward = r, 1 == e && w.slice_del()) : w.limit_backward = r)
                        }
                        var s, u, a = [new r("a", -1, 1), new r("e", -1, 1), new r("ede", 1, 1), new r("ande", 1, 1), new r("ende", 1, 1), new r("ane", 1, 1), new r("ene", 1, 1), new r("hetene", 6, 1), new r("erte", 1, 3), new r("en", -1, 1), new r("heten", 9, 1), new r("ar", -1, 1), new r("er", -1, 1), new r("heter", 12, 1), new r("s", -1, 2), new r("as", 14, 1), new r("es", 14, 1), new r("edes", 16, 1), new r("endes", 16, 1), new r("enes", 16, 1), new r("hetenes", 19, 1), new r("ens", 14, 1), new r("hetens", 21, 1), new r("ers", 14, 1), new r("ets", 14, 1), new r("et", -1, 1), new r("het", 25, 1), new r("ert", -1, 3), new r("ast", -1, 1)],
                            c = [new r("dt", -1, -1), new r("vt", -1, -1)],
                            l = [new r("leg", -1, 1), new r("eleg", 0, 1), new r("ig", -1, 1), new r("eig", 2, 1), new r("lig", 2, 1), new r("elig", 4, 1), new r("els", -1, 1), new r("lov", -1, 1), new r("elov", 7, 1), new r("slov", 7, 1), new r("hetslov", 9, 1)],
                            f = [17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 48, 0, 128],
                            d = [119, 125, 149, 1],
                            w = new n;
                        this.setCurrent = function(e) {
                            w.setCurrent(e)
                        }, this.getCurrent = function() {
                            return w.getCurrent()
                        }, this.stem = function() {
                            var r = w.cursor;
                            return e(), w.limit_backward = r, w.cursor = w.limit, t(), w.cursor = w.limit, i(), w.cursor = w.limit, o(), !0
                        }
                    };
                return function(e) {
                    return t.setCurrent(e), t.stem(), t.getCurrent()
                }
            }(), e.Pipeline.registerFunction(e.no.stemmer, "stemmer-no"), e.no.stopWordFilter = function(r) {
                if (e.no.stopWordFilter.stopWords.indexOf(r) === -1) return r
            }, e.no.stopWordFilter.stopWords = new e.SortedSet, e.no.stopWordFilter.stopWords.length = 177, e.no.stopWordFilter.stopWords.elements = " alle at av bare begge ble blei bli blir blitt både båe da de deg dei deim deira deires dem den denne der dere deres det dette di din disse ditt du dykk dykkar då eg ein eit eitt eller elles en enn er et ett etter for fordi fra før ha hadde han hans har hennar henne hennes her hjå ho hoe honom hoss hossen hun hva hvem hver hvilke hvilken hvis hvor hvordan hvorfor i ikke ikkje ikkje ingen ingi inkje inn inni ja jeg kan kom korleis korso kun kunne kva kvar kvarhelst kven kvi kvifor man mange me med medan meg meget mellom men mi min mine mitt mot mykje ned no noe noen noka noko nokon nokor nokre nå når og også om opp oss over på samme seg selv si si sia sidan siden sin sine sitt sjøl skal skulle slik so som som somme somt så sånn til um upp ut uten var vart varte ved vere verte vi vil ville vore vors vort vår være være vært å".split(" "), e.Pipeline.registerFunction(e.no.stopWordFilter, "stopWordFilter-no")
        }
    })
}, function(e, r, n) {
    var t, i;
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(this, function() {
        return function(e) {
            if ("undefined" == typeof e) throw new Error("Lunr is not present. Please include / require Lunr before this script.");
            if ("undefined" == typeof e.stemmerSupport) throw new Error("Lunr stemmer support is not present. Please include / require Lunr stemmer support before this script.");
            e.pt = function() {
                this.pipeline.reset(), this.pipeline.add(e.pt.stopWordFilter, e.pt.stemmer)
            }, e.pt.stemmer = function() {
                var r = e.stemmerSupport.Among,
                    n = e.stemmerSupport.SnowballProgram,
                    t = new function() {
                        function e() {
                            for (var e;;) {
                                if (C.bra = C.cursor, e = C.find_among(k, 3)) switch (C.ket = C.cursor, e) {
                                    case 1:
                                        C.slice_from("a~");
                                        continue;
                                    case 2:
                                        C.slice_from("o~");
                                        continue;
                                    case 3:
                                        if (C.cursor >= C.limit) break;
                                        C.cursor++;
                                        continue
                                }
                                break
                            }
                        }

                        function t() {
                            if (C.out_grouping(L, 97, 250)) {
                                for (; !C.in_grouping(L, 97, 250);) {
                                    if (C.cursor >= C.limit) return !0;
                                    C.cursor++
                                }
                                return !1
                            }
                            return !0
                        }

                        function i() {
                            if (C.in_grouping(L, 97, 250))
                                for (; !C.out_grouping(L, 97, 250);) {
                                    if (C.cursor >= C.limit) return !1;
                                    C.cursor++
                                }
                            return g = C.cursor, !0
                        }

                        function o() {
                            var e, r, n = C.cursor;
                            if (C.in_grouping(L, 97, 250))
                                if (e = C.cursor, t()) {
                                    if (C.cursor = e, i()) return
                                } else g = C.cursor;
                            if (C.cursor = n, C.out_grouping(L, 97, 250)) {
                                if (r = C.cursor, t()) {
                                    if (C.cursor = r, !C.in_grouping(L, 97, 250) || C.cursor >= C.limit) return;
                                    C.cursor++
                                }
                                g = C.cursor
                            }
                        }

                        function s() {
                            for (; !C.in_grouping(L, 97, 250);) {
                                if (C.cursor >= C.limit) return !1;
                                C.cursor++
                            }
                            for (; !C.out_grouping(L, 97, 250);) {
                                if (C.cursor >= C.limit) return !1;
                                C.cursor++
                            }
                            return !0
                        }

                        function u() {
                            var e = C.cursor;
                            g = C.limit, _ = g, v = g, o(), C.cursor = e, s() && (_ = C.cursor, s() && (v = C.cursor))
                        }

                        function a() {
                            for (var e;;) {
                                if (C.bra = C.cursor, e = C.find_among(y, 3)) switch (C.ket = C.cursor, e) {
                                    case 1:
                                        C.slice_from("ã");
                                        continue;
                                    case 2:
                                        C.slice_from("õ");
                                        continue;
                                    case 3:
                                        if (C.cursor >= C.limit) break;
                                        C.cursor++;
                                        continue
                                }
                                break
                            }
                        }

                        function c() {
                            return g <= C.cursor
                        }

                        function l() {
                            return _ <= C.cursor
                        }

                        function f() {
                            return v <= C.cursor
                        }

                        function d() {
                            var e;
                            if (C.ket = C.cursor, e = C.find_among_b(q, 45), !e) return !1;
                            switch (C.bra = C.cursor, e) {
                                case 1:
                                    if (!f()) return !1;
                                    C.slice_del();
                                    break;
                                case 2:
                                    if (!f()) return !1;
                                    C.slice_from("log");
                                    break;
                                case 3:
                                    if (!f()) return !1;
                                    C.slice_from("u");
                                    break;
                                case 4:
                                    if (!f()) return !1;
                                    C.slice_from("ente");
                                    break;
                                case 5:
                                    if (!l()) return !1;
                                    C.slice_del(), C.ket = C.cursor, e = C.find_among_b(x, 4), e && (C.bra = C.cursor, f() && (C.slice_del(), 1 == e && (C.ket = C.cursor, C.eq_s_b(2, "at") && (C.bra = C.cursor, f() && C.slice_del()))));
                                    break;
                                case 6:
                                    if (!f()) return !1;
                                    C.slice_del(), C.ket = C.cursor, e = C.find_among_b(S, 3), e && (C.bra = C.cursor, 1 == e && f() && C.slice_del());
                                    break;
                                case 7:
                                    if (!f()) return !1;
                                    C.slice_del(), C.ket = C.cursor, e = C.find_among_b(F, 3), e && (C.bra = C.cursor, 1 == e && f() && C.slice_del());
                                    break;
                                case 8:
                                    if (!f()) return !1;
                                    C.slice_del(), C.ket = C.cursor, C.eq_s_b(2, "at") && (C.bra = C.cursor, f() && C.slice_del());
                                    break;
                                case 9:
                                    if (!c() || !C.eq_s_b(1, "e")) return !1;
                                    C.slice_from("ir")
                            }
                            return !0
                        }

                        function w() {
                            var e, r;
                            if (C.cursor >= g) {
                                if (r = C.limit_backward, C.limit_backward = g, C.ket = C.cursor, e = C.find_among_b(W, 120)) return C.bra = C.cursor, 1 == e && C.slice_del(), C.limit_backward = r, !0;
                                C.limit_backward = r
                            }
                            return !1
                        }

                        function m() {
                            var e;
                            C.ket = C.cursor, e = C.find_among_b(z, 7), e && (C.bra = C.cursor, 1 == e && c() && C.slice_del())
                        }

                        function p(e, r) {
                            if (C.eq_s_b(1, e)) {
                                C.bra = C.cursor;
                                var n = C.limit - C.cursor;
                                if (C.eq_s_b(1, r)) return C.cursor = C.limit - n, c() && C.slice_del(), !1
                            }
                            return !0
                        }

                        function h() {
                            var e, r;
                            if (C.ket = C.cursor, e = C.find_among_b(j, 4)) switch (C.bra = C.cursor, e) {
                                case 1:
                                    c() && (C.slice_del(), C.ket = C.cursor, r = C.limit - C.cursor, p("u", "g") && p("i", "c"));
                                    break;
                                case 2:
                                    C.slice_from("c")
                            }
                        }

                        function b() {
                            return d() || (C.cursor = C.limit, w()) ? (C.cursor = C.limit, C.ket = C.cursor, void(C.eq_s_b(1, "i") && (C.bra = C.cursor, C.eq_s_b(1, "c") && (C.cursor = C.limit, c() && C.slice_del())))) : (C.cursor = C.limit, void m())
                        }
                        var v, _, g, k = [new r("", -1, 3), new r("ã", 0, 1), new r("õ", 0, 2)],
                            y = [new r("", -1, 3), new r("a~", 0, 1), new r("o~", 0, 2)],
                            x = [new r("ic", -1, -1), new r("ad", -1, -1), new r("os", -1, -1), new r("iv", -1, 1)],
                            S = [new r("ante", -1, 1), new r("avel", -1, 1), new r("ível", -1, 1)],
                            F = [new r("ic", -1, 1), new r("abil", -1, 1), new r("iv", -1, 1)],
                            q = [new r("ica", -1, 1), new r("ância", -1, 1), new r("ência", -1, 4), new r("ira", -1, 9), new r("adora", -1, 1), new r("osa", -1, 1), new r("ista", -1, 1), new r("iva", -1, 8), new r("eza", -1, 1), new r("logía", -1, 2), new r("idade", -1, 7), new r("ante", -1, 1), new r("mente", -1, 6), new r("amente", 12, 5), new r("ável", -1, 1), new r("ível", -1, 1), new r("ución", -1, 3), new r("ico", -1, 1), new r("ismo", -1, 1), new r("oso", -1, 1), new r("amento", -1, 1), new r("imento", -1, 1), new r("ivo", -1, 8), new r("aça~o", -1, 1), new r("ador", -1, 1), new r("icas", -1, 1), new r("ências", -1, 4), new r("iras", -1, 9), new r("adoras", -1, 1), new r("osas", -1, 1), new r("istas", -1, 1), new r("ivas", -1, 8), new r("ezas", -1, 1), new r("logías", -1, 2), new r("idades", -1, 7), new r("uciones", -1, 3), new r("adores", -1, 1), new r("antes", -1, 1), new r("aço~es", -1, 1), new r("icos", -1, 1), new r("ismos", -1, 1), new r("osos", -1, 1), new r("amentos", -1, 1), new r("imentos", -1, 1), new r("ivos", -1, 8)],
                            W = [new r("ada", -1, 1), new r("ida", -1, 1), new r("ia", -1, 1), new r("aria", 2, 1), new r("eria", 2, 1), new r("iria", 2, 1), new r("ara", -1, 1), new r("era", -1, 1), new r("ira", -1, 1), new r("ava", -1, 1), new r("asse", -1, 1), new r("esse", -1, 1), new r("isse", -1, 1), new r("aste", -1, 1), new r("este", -1, 1), new r("iste", -1, 1), new r("ei", -1, 1), new r("arei", 16, 1), new r("erei", 16, 1), new r("irei", 16, 1), new r("am", -1, 1), new r("iam", 20, 1), new r("ariam", 21, 1), new r("eriam", 21, 1), new r("iriam", 21, 1), new r("aram", 20, 1), new r("eram", 20, 1), new r("iram", 20, 1), new r("avam", 20, 1), new r("em", -1, 1), new r("arem", 29, 1), new r("erem", 29, 1), new r("irem", 29, 1), new r("assem", 29, 1), new r("essem", 29, 1), new r("issem", 29, 1), new r("ado", -1, 1), new r("ido", -1, 1), new r("ando", -1, 1), new r("endo", -1, 1), new r("indo", -1, 1), new r("ara~o", -1, 1), new r("era~o", -1, 1), new r("ira~o", -1, 1), new r("ar", -1, 1), new r("er", -1, 1), new r("ir", -1, 1), new r("as", -1, 1), new r("adas", 47, 1), new r("idas", 47, 1), new r("ias", 47, 1), new r("arias", 50, 1), new r("erias", 50, 1), new r("irias", 50, 1), new r("aras", 47, 1), new r("eras", 47, 1), new r("iras", 47, 1), new r("avas", 47, 1), new r("es", -1, 1), new r("ardes", 58, 1), new r("erdes", 58, 1), new r("irdes", 58, 1), new r("ares", 58, 1), new r("eres", 58, 1), new r("ires", 58, 1), new r("asses", 58, 1), new r("esses", 58, 1), new r("isses", 58, 1), new r("astes", 58, 1), new r("estes", 58, 1), new r("istes", 58, 1), new r("is", -1, 1), new r("ais", 71, 1), new r("eis", 71, 1), new r("areis", 73, 1), new r("ereis", 73, 1), new r("ireis", 73, 1), new r("áreis", 73, 1), new r("éreis", 73, 1), new r("íreis", 73, 1), new r("ásseis", 73, 1), new r("ésseis", 73, 1), new r("ísseis", 73, 1), new r("áveis", 73, 1), new r("íeis", 73, 1), new r("aríeis", 84, 1), new r("eríeis", 84, 1), new r("iríeis", 84, 1), new r("ados", -1, 1), new r("idos", -1, 1), new r("amos", -1, 1), new r("áramos", 90, 1), new r("éramos", 90, 1), new r("íramos", 90, 1), new r("ávamos", 90, 1), new r("íamos", 90, 1), new r("aríamos", 95, 1), new r("eríamos", 95, 1), new r("iríamos", 95, 1), new r("emos", -1, 1), new r("aremos", 99, 1), new r("eremos", 99, 1), new r("iremos", 99, 1), new r("ássemos", 99, 1), new r("êssemos", 99, 1), new r("íssemos", 99, 1), new r("imos", -1, 1), new r("armos", -1, 1), new r("ermos", -1, 1), new r("irmos", -1, 1), new r("ámos", -1, 1), new r("arás", -1, 1), new r("erás", -1, 1), new r("irás", -1, 1), new r("eu", -1, 1), new r("iu", -1, 1), new r("ou", -1, 1), new r("ará", -1, 1), new r("erá", -1, 1), new r("irá", -1, 1)],
                            z = [new r("a", -1, 1), new r("i", -1, 1), new r("o", -1, 1), new r("os", -1, 1), new r("á", -1, 1), new r("í", -1, 1), new r("ó", -1, 1)],
                            j = [new r("e", -1, 1), new r("ç", -1, 2), new r("é", -1, 1), new r("ê", -1, 1)],
                            L = [17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 19, 12, 2],
                            C = new n;
                        this.setCurrent = function(e) {
                            C.setCurrent(e)
                        }, this.getCurrent = function() {
                            return C.getCurrent()
                        }, this.stem = function() {
                            var r = C.cursor;
                            return e(), C.cursor = r, u(), C.limit_backward = r, C.cursor = C.limit, b(), C.cursor = C.limit, h(), C.cursor = C.limit_backward, a(), !0
                        }
                    };
                return function(e) {
                    return t.setCurrent(e), t.stem(), t.getCurrent()
                }
            }(), e.Pipeline.registerFunction(e.pt.stemmer, "stemmer-pt"), e.pt.stopWordFilter = function(r) {
                if (e.pt.stopWordFilter.stopWords.indexOf(r) === -1) return r
            }, e.pt.stopWordFilter.stopWords = new e.SortedSet, e.pt.stopWordFilter.stopWords.length = 204, e.pt.stopWordFilter.stopWords.elements = " a ao aos aquela aquelas aquele aqueles aquilo as até com como da das de dela delas dele deles depois do dos e ela elas ele eles em entre era eram essa essas esse esses esta estamos estas estava estavam este esteja estejam estejamos estes esteve estive estivemos estiver estivera estiveram estiverem estivermos estivesse estivessem estivéramos estivéssemos estou está estávamos estão eu foi fomos for fora foram forem formos fosse fossem fui fôramos fôssemos haja hajam hajamos havemos hei houve houvemos houver houvera houveram houverei houverem houveremos houveria houveriam houvermos houverá houverão houveríamos houvesse houvessem houvéramos houvéssemos há hão isso isto já lhe lhes mais mas me mesmo meu meus minha minhas muito na nas nem no nos nossa nossas nosso nossos num numa não nós o os ou para pela pelas pelo pelos por qual quando que quem se seja sejam sejamos sem serei seremos seria seriam será serão seríamos seu seus somos sou sua suas são só também te tem temos tenha tenham tenhamos tenho terei teremos teria teriam terá terão teríamos teu teus teve tinha tinham tive tivemos tiver tivera tiveram tiverem tivermos tivesse tivessem tivéramos tivéssemos tu tua tuas tém tínhamos um uma você vocês vos à às éramos".split(" "), e.Pipeline.registerFunction(e.pt.stopWordFilter, "stopWordFilter-pt")
        }
    })
}, function(e, r, n) {
    var t, i;
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(this, function() {
        return function(e) {
            if ("undefined" == typeof e) throw new Error("Lunr is not present. Please include / require Lunr before this script.");
            if ("undefined" == typeof e.stemmerSupport) throw new Error("Lunr stemmer support is not present. Please include / require Lunr stemmer support before this script.");
            e.ro = function() {
                this.pipeline.reset(), this.pipeline.add(e.ro.stopWordFilter, e.ro.stemmer)
            }, e.ro.stemmer = function() {
                var r = e.stemmerSupport.Among,
                    n = e.stemmerSupport.SnowballProgram,
                    t = new function() {
                        function e(e, r) {
                            j.eq_s(1, e) && (j.ket = j.cursor, j.in_grouping(z, 97, 259) && j.slice_from(r))
                        }

                        function t() {
                            for (var r, n;;) {
                                if (r = j.cursor, j.in_grouping(z, 97, 259) && (n = j.cursor, j.bra = n, e("u", "U"), j.cursor = n, e("i", "I")), j.cursor = r, j.cursor >= j.limit) break;
                                j.cursor++
                            }
                        }

                        function i() {
                            if (j.out_grouping(z, 97, 259)) {
                                for (; !j.in_grouping(z, 97, 259);) {
                                    if (j.cursor >= j.limit) return !0;
                                    j.cursor++
                                }
                                return !1
                            }
                            return !0
                        }

                        function o() {
                            if (j.in_grouping(z, 97, 259))
                                for (; !j.out_grouping(z, 97, 259);) {
                                    if (j.cursor >= j.limit) return !0;
                                    j.cursor++
                                }
                            return !1
                        }

                        function s() {
                            var e, r, n = j.cursor;
                            if (j.in_grouping(z, 97, 259)) {
                                if (e = j.cursor, !i()) return void(k = j.cursor);
                                if (j.cursor = e, !o()) return void(k = j.cursor)
                            }
                            j.cursor = n, j.out_grouping(z, 97, 259) && (r = j.cursor, i() && (j.cursor = r, j.in_grouping(z, 97, 259) && j.cursor < j.limit && j.cursor++), k = j.cursor)
                        }

                        function u() {
                            for (; !j.in_grouping(z, 97, 259);) {
                                if (j.cursor >= j.limit) return !1;
                                j.cursor++
                            }
                            for (; !j.out_grouping(z, 97, 259);) {
                                if (j.cursor >= j.limit) return !1;
                                j.cursor++
                            }
                            return !0
                        }

                        function a() {
                            var e = j.cursor;
                            k = j.limit, g = k, _ = k, s(), j.cursor = e, u() && (g = j.cursor, u() && (_ = j.cursor))
                        }

                        function c() {
                            for (var e;;) {
                                if (j.bra = j.cursor, e = j.find_among(y, 3)) switch (j.ket = j.cursor, e) {
                                    case 1:
                                        j.slice_from("i");
                                        continue;
                                    case 2:
                                        j.slice_from("u");
                                        continue;
                                    case 3:
                                        if (j.cursor >= j.limit) break;
                                        j.cursor++;
                                        continue
                                }
                                break
                            }
                        }

                        function l() {
                            return k <= j.cursor
                        }

                        function f() {
                            return g <= j.cursor
                        }

                        function d() {
                            return _ <= j.cursor
                        }

                        function w() {
                            var e, r;
                            if (j.ket = j.cursor, e = j.find_among_b(x, 16), e && (j.bra = j.cursor, f())) switch (e) {
                                case 1:
                                    j.slice_del();
                                    break;
                                case 2:
                                    j.slice_from("a");
                                    break;
                                case 3:
                                    j.slice_from("e");
                                    break;
                                case 4:
                                    j.slice_from("i");
                                    break;
                                case 5:
                                    r = j.limit - j.cursor, j.eq_s_b(2, "ab") || (j.cursor = j.limit - r, j.slice_from("i"));
                                    break;
                                case 6:
                                    j.slice_from("at");
                                    break;
                                case 7:
                                    j.slice_from("aţi")
                            }
                        }

                        function m() {
                            var e, r = j.limit - j.cursor;
                            if (j.ket = j.cursor, e = j.find_among_b(S, 46), e && (j.bra = j.cursor, f())) {
                                switch (e) {
                                    case 1:
                                        j.slice_from("abil");
                                        break;
                                    case 2:
                                        j.slice_from("ibil");
                                        break;
                                    case 3:
                                        j.slice_from("iv");
                                        break;
                                    case 4:
                                        j.slice_from("ic");
                                        break;
                                    case 5:
                                        j.slice_from("at");
                                        break;
                                    case 6:
                                        j.slice_from("it")
                                }
                                return v = !0, j.cursor = j.limit - r, !0
                            }
                            return !1
                        }

                        function p() {
                            var e, r;
                            for (v = !1;;)
                                if (r = j.limit - j.cursor, !m()) {
                                    j.cursor = j.limit - r;
                                    break
                                } if (j.ket = j.cursor, e = j.find_among_b(F, 62), e && (j.bra = j.cursor, d())) {
                                switch (e) {
                                    case 1:
                                        j.slice_del();
                                        break;
                                    case 2:
                                        j.eq_s_b(1, "ţ") && (j.bra = j.cursor, j.slice_from("t"));
                                        break;
                                    case 3:
                                        j.slice_from("ist")
                                }
                                v = !0
                            }
                        }

                        function h() {
                            var e, r, n;
                            if (j.cursor >= k) {
                                if (r = j.limit_backward, j.limit_backward = k, j.ket = j.cursor, e = j.find_among_b(q, 94)) switch (j.bra = j.cursor, e) {
                                    case 1:
                                        if (n = j.limit - j.cursor, !j.out_grouping_b(z, 97, 259) && (j.cursor = j.limit - n, !j.eq_s_b(1, "u"))) break;
                                    case 2:
                                        j.slice_del()
                                }
                                j.limit_backward = r
                            }
                        }

                        function b() {
                            var e;
                            j.ket = j.cursor, e = j.find_among_b(W, 5), e && (j.bra = j.cursor, l() && 1 == e && j.slice_del())
                        }
                        var v, _, g, k, y = [new r("", -1, 3), new r("I", 0, 1), new r("U", 0, 2)],
                            x = [new r("ea", -1, 3), new r("aţia", -1, 7), new r("aua", -1, 2), new r("iua", -1, 4), new r("aţie", -1, 7), new r("ele", -1, 3), new r("ile", -1, 5), new r("iile", 6, 4), new r("iei", -1, 4), new r("atei", -1, 6), new r("ii", -1, 4), new r("ului", -1, 1), new r("ul", -1, 1), new r("elor", -1, 3), new r("ilor", -1, 4), new r("iilor", 14, 4)],
                            S = [new r("icala", -1, 4), new r("iciva", -1, 4), new r("ativa", -1, 5), new r("itiva", -1, 6), new r("icale", -1, 4), new r("aţiune", -1, 5), new r("iţiune", -1, 6), new r("atoare", -1, 5), new r("itoare", -1, 6), new r("ătoare", -1, 5), new r("icitate", -1, 4), new r("abilitate", -1, 1), new r("ibilitate", -1, 2), new r("ivitate", -1, 3), new r("icive", -1, 4), new r("ative", -1, 5), new r("itive", -1, 6), new r("icali", -1, 4), new r("atori", -1, 5), new r("icatori", 18, 4), new r("itori", -1, 6), new r("ători", -1, 5), new r("icitati", -1, 4), new r("abilitati", -1, 1), new r("ivitati", -1, 3), new r("icivi", -1, 4), new r("ativi", -1, 5), new r("itivi", -1, 6), new r("icităi", -1, 4), new r("abilităi", -1, 1), new r("ivităi", -1, 3), new r("icităţi", -1, 4), new r("abilităţi", -1, 1), new r("ivităţi", -1, 3), new r("ical", -1, 4), new r("ator", -1, 5), new r("icator", 35, 4), new r("itor", -1, 6), new r("ător", -1, 5), new r("iciv", -1, 4), new r("ativ", -1, 5), new r("itiv", -1, 6), new r("icală", -1, 4), new r("icivă", -1, 4), new r("ativă", -1, 5), new r("itivă", -1, 6)],
                            F = [new r("ica", -1, 1), new r("abila", -1, 1), new r("ibila", -1, 1), new r("oasa", -1, 1), new r("ata", -1, 1), new r("ita", -1, 1), new r("anta", -1, 1), new r("ista", -1, 3), new r("uta", -1, 1), new r("iva", -1, 1), new r("ic", -1, 1), new r("ice", -1, 1), new r("abile", -1, 1), new r("ibile", -1, 1), new r("isme", -1, 3), new r("iune", -1, 2), new r("oase", -1, 1), new r("ate", -1, 1), new r("itate", 17, 1), new r("ite", -1, 1), new r("ante", -1, 1), new r("iste", -1, 3), new r("ute", -1, 1), new r("ive", -1, 1), new r("ici", -1, 1), new r("abili", -1, 1), new r("ibili", -1, 1), new r("iuni", -1, 2), new r("atori", -1, 1), new r("osi", -1, 1), new r("ati", -1, 1), new r("itati", 30, 1), new r("iti", -1, 1), new r("anti", -1, 1), new r("isti", -1, 3), new r("uti", -1, 1), new r("işti", -1, 3), new r("ivi", -1, 1), new r("ităi", -1, 1), new r("oşi", -1, 1), new r("ităţi", -1, 1), new r("abil", -1, 1), new r("ibil", -1, 1), new r("ism", -1, 3), new r("ator", -1, 1), new r("os", -1, 1), new r("at", -1, 1), new r("it", -1, 1), new r("ant", -1, 1), new r("ist", -1, 3), new r("ut", -1, 1), new r("iv", -1, 1), new r("ică", -1, 1), new r("abilă", -1, 1), new r("ibilă", -1, 1), new r("oasă", -1, 1), new r("ată", -1, 1), new r("ită", -1, 1), new r("antă", -1, 1), new r("istă", -1, 3), new r("ută", -1, 1), new r("ivă", -1, 1)],
                            q = [new r("ea", -1, 1), new r("ia", -1, 1), new r("esc", -1, 1), new r("ăsc", -1, 1), new r("ind", -1, 1), new r("ând", -1, 1), new r("are", -1, 1), new r("ere", -1, 1), new r("ire", -1, 1), new r("âre", -1, 1), new r("se", -1, 2), new r("ase", 10, 1), new r("sese", 10, 2), new r("ise", 10, 1), new r("use", 10, 1), new r("âse", 10, 1), new r("eşte", -1, 1), new r("ăşte", -1, 1), new r("eze", -1, 1), new r("ai", -1, 1), new r("eai", 19, 1), new r("iai", 19, 1), new r("sei", -1, 2), new r("eşti", -1, 1), new r("ăşti", -1, 1), new r("ui", -1, 1), new r("ezi", -1, 1), new r("âi", -1, 1), new r("aşi", -1, 1), new r("seşi", -1, 2), new r("aseşi", 29, 1), new r("seseşi", 29, 2), new r("iseşi", 29, 1), new r("useşi", 29, 1), new r("âseşi", 29, 1), new r("işi", -1, 1), new r("uşi", -1, 1), new r("âşi", -1, 1), new r("aţi", -1, 2), new r("eaţi", 38, 1), new r("iaţi", 38, 1), new r("eţi", -1, 2), new r("iţi", -1, 2), new r("âţi", -1, 2), new r("arăţi", -1, 1), new r("serăţi", -1, 2), new r("aserăţi", 45, 1), new r("seserăţi", 45, 2), new r("iserăţi", 45, 1), new r("userăţi", 45, 1), new r("âserăţi", 45, 1), new r("irăţi", -1, 1), new r("urăţi", -1, 1), new r("ârăţi", -1, 1), new r("am", -1, 1), new r("eam", 54, 1), new r("iam", 54, 1), new r("em", -1, 2), new r("asem", 57, 1), new r("sesem", 57, 2), new r("isem", 57, 1), new r("usem", 57, 1), new r("âsem", 57, 1), new r("im", -1, 2), new r("âm", -1, 2), new r("ăm", -1, 2), new r("arăm", 65, 1), new r("serăm", 65, 2), new r("aserăm", 67, 1), new r("seserăm", 67, 2), new r("iserăm", 67, 1), new r("userăm", 67, 1), new r("âserăm", 67, 1), new r("irăm", 65, 1), new r("urăm", 65, 1), new r("ârăm", 65, 1), new r("au", -1, 1), new r("eau", 76, 1), new r("iau", 76, 1), new r("indu", -1, 1), new r("ându", -1, 1), new r("ez", -1, 1), new r("ească", -1, 1), new r("ară", -1, 1), new r("seră", -1, 2), new r("aseră", 84, 1), new r("seseră", 84, 2), new r("iseră", 84, 1), new r("useră", 84, 1), new r("âseră", 84, 1), new r("iră", -1, 1), new r("ură", -1, 1), new r("âră", -1, 1), new r("ează", -1, 1)],
                            W = [new r("a", -1, 1), new r("e", -1, 1), new r("ie", 1, 1), new r("i", -1, 1), new r("ă", -1, 1)],
                            z = [17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 32, 0, 0, 4],
                            j = new n;
                        this.setCurrent = function(e) {
                            j.setCurrent(e)
                        }, this.getCurrent = function() {
                            return j.getCurrent()
                        }, this.stem = function() {
                            var e = j.cursor;
                            return t(), j.cursor = e, a(), j.limit_backward = e, j.cursor = j.limit, w(), j.cursor = j.limit, p(), j.cursor = j.limit, v || (j.cursor = j.limit, h(), j.cursor = j.limit), b(), j.cursor = j.limit_backward, c(), !0
                        }
                    };
                return function(e) {
                    return t.setCurrent(e), t.stem(), t.getCurrent()
                }
            }(), e.Pipeline.registerFunction(e.ro.stemmer, "stemmer-ro"), e.ro.stopWordFilter = function(r) {
                if (e.ro.stopWordFilter.stopWords.indexOf(r) === -1) return r
            }, e.ro.stopWordFilter.stopWords = new e.SortedSet, e.ro.stopWordFilter.stopWords.length = 282, e.ro.stopWordFilter.stopWords.elements = " acea aceasta această aceea acei aceia acel acela acele acelea acest acesta aceste acestea aceşti aceştia acolo acord acum ai aia aibă aici al ale alea altceva altcineva am ar are asemenea asta astea astăzi asupra au avea avem aveţi azi aş aşadar aţi bine bucur bună ca care caut ce cel ceva chiar cinci cine cineva contra cu cum cumva curând curînd când cât câte câtva câţi cînd cît cîte cîtva cîţi că căci cărei căror cărui către da dacă dar datorită dată dau de deci deja deoarece departe deşi din dinaintea dintr- dintre doi doilea două drept după dă ea ei el ele eram este eu eşti face fata fi fie fiecare fii fim fiu fiţi frumos fără graţie halbă iar ieri la le li lor lui lângă lîngă mai mea mei mele mereu meu mi mie mine mult multă mulţi mulţumesc mâine mîine mă ne nevoie nici nicăieri nimeni nimeri nimic nişte noastre noastră noi noroc nostru nouă noştri nu opt ori oricare orice oricine oricum oricând oricât oricînd oricît oriunde patra patru patrulea pe pentru peste pic poate pot prea prima primul prin puţin puţina puţină până pînă rog sa sale sau se spate spre sub sunt suntem sunteţi sută sînt sîntem sînteţi să săi său ta tale te timp tine toate toată tot totuşi toţi trei treia treilea tu tăi tău un una unde undeva unei uneia unele uneori unii unor unora unu unui unuia unul vi voastre voastră voi vostru vouă voştri vreme vreo vreun vă zece zero zi zice îi îl îmi împotriva în  înainte înaintea încotro încât încît între întrucât întrucît îţi ăla ălea ăsta ăstea ăştia şapte şase şi ştiu ţi ţie".split(" "), e.Pipeline.registerFunction(e.ro.stopWordFilter, "stopWordFilter-ro")
        }
    })
}, function(e, r, n) {
    var t, i;
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(this, function() {
        return function(e) {
            if ("undefined" == typeof e) throw new Error("Lunr is not present. Please include / require Lunr before this script.");
            if ("undefined" == typeof e.stemmerSupport) throw new Error("Lunr stemmer support is not present. Please include / require Lunr stemmer support before this script.");
            e.ru = function() {
                    this.pipeline.reset(), this.pipeline.add(e.ru.stopWordFilter, e.ru.stemmer)
                }, e.ru.stemmer = function() {
                    var r = e.stemmerSupport.Among,
                        n = e.stemmerSupport.SnowballProgram,
                        t = new function() {
                            function e() {
                                for (; !W.in_grouping(q, 1072, 1103);) {
                                    if (W.cursor >= W.limit) return !1;
                                    W.cursor++
                                }
                                return !0
                            }

                            function t() {
                                for (; !W.out_grouping(q, 1072, 1103);) {
                                    if (W.cursor >= W.limit) return !1;
                                    W.cursor++
                                }
                                return !0
                            }

                            function i() {
                                b = W.limit, h = b, e() && (b = W.cursor, t() && e() && t() && (h = W.cursor))
                            }

                            function o() {
                                return h <= W.cursor
                            }

                            function s(e, r) {
                                var n, t;
                                if (W.ket = W.cursor, n = W.find_among_b(e, r)) {
                                    switch (W.bra = W.cursor, n) {
                                        case 1:
                                            if (t = W.limit - W.cursor, !W.eq_s_b(1, "а") && (W.cursor = W.limit - t, !W.eq_s_b(1, "я"))) return !1;
                                        case 2:
                                            W.slice_del()
                                    }
                                    return !0
                                }
                                return !1
                            }

                            function u() {
                                return s(v, 9)
                            }

                            function a(e, r) {
                                var n;
                                return W.ket = W.cursor, n = W.find_among_b(e, r), !!n && (W.bra = W.cursor, 1 == n && W.slice_del(), !0)
                            }

                            function c() {
                                return a(_, 26)
                            }

                            function l() {
                                return !!c() && (s(g, 8), !0)
                            }

                            function f() {
                                return a(k, 2)
                            }

                            function d() {
                                return s(y, 46)
                            }

                            function w() {
                                a(x, 36)
                            }

                            function m() {
                                var e;
                                W.ket = W.cursor, e = W.find_among_b(S, 2), e && (W.bra = W.cursor, o() && 1 == e && W.slice_del())
                            }

                            function p() {
                                var e;
                                if (W.ket = W.cursor, e = W.find_among_b(F, 4)) switch (W.bra = W.cursor, e) {
                                    case 1:
                                        if (W.slice_del(), W.ket = W.cursor, !W.eq_s_b(1, "н")) break;
                                        W.bra = W.cursor;
                                    case 2:
                                        if (!W.eq_s_b(1, "н")) break;
                                    case 3:
                                        W.slice_del()
                                }
                            }
                            var h, b, v = [new r("в", -1, 1), new r("ив", 0, 2), new r("ыв", 0, 2), new r("вши", -1, 1), new r("ивши", 3, 2), new r("ывши", 3, 2), new r("вшись", -1, 1), new r("ившись", 6, 2), new r("ывшись", 6, 2)],
                                _ = [new r("ее", -1, 1), new r("ие", -1, 1), new r("ое", -1, 1), new r("ые", -1, 1), new r("ими", -1, 1), new r("ыми", -1, 1), new r("ей", -1, 1), new r("ий", -1, 1), new r("ой", -1, 1), new r("ый", -1, 1), new r("ем", -1, 1), new r("им", -1, 1), new r("ом", -1, 1), new r("ым", -1, 1), new r("его", -1, 1), new r("ого", -1, 1), new r("ему", -1, 1), new r("ому", -1, 1), new r("их", -1, 1), new r("ых", -1, 1), new r("ею", -1, 1), new r("ою", -1, 1), new r("ую", -1, 1), new r("юю", -1, 1), new r("ая", -1, 1), new r("яя", -1, 1)],
                                g = [new r("ем", -1, 1), new r("нн", -1, 1), new r("вш", -1, 1), new r("ивш", 2, 2), new r("ывш", 2, 2), new r("щ", -1, 1), new r("ющ", 5, 1), new r("ующ", 6, 2)],
                                k = [new r("сь", -1, 1), new r("ся", -1, 1)],
                                y = [new r("ла", -1, 1), new r("ила", 0, 2), new r("ыла", 0, 2), new r("на", -1, 1), new r("ена", 3, 2), new r("ете", -1, 1), new r("ите", -1, 2), new r("йте", -1, 1), new r("ейте", 7, 2), new r("уйте", 7, 2), new r("ли", -1, 1), new r("или", 10, 2), new r("ыли", 10, 2), new r("й", -1, 1), new r("ей", 13, 2), new r("уй", 13, 2), new r("л", -1, 1), new r("ил", 16, 2), new r("ыл", 16, 2), new r("ем", -1, 1), new r("им", -1, 2), new r("ым", -1, 2), new r("н", -1, 1), new r("ен", 22, 2), new r("ло", -1, 1), new r("ило", 24, 2), new r("ыло", 24, 2), new r("но", -1, 1), new r("ено", 27, 2), new r("нно", 27, 1), new r("ет", -1, 1), new r("ует", 30, 2), new r("ит", -1, 2), new r("ыт", -1, 2), new r("ют", -1, 1), new r("уют", 34, 2), new r("ят", -1, 2), new r("ны", -1, 1), new r("ены", 37, 2), new r("ть", -1, 1), new r("ить", 39, 2), new r("ыть", 39, 2), new r("ешь", -1, 1), new r("ишь", -1, 2), new r("ю", -1, 2), new r("ую", 44, 2)],
                                x = [new r("а", -1, 1), new r("ев", -1, 1), new r("ов", -1, 1), new r("е", -1, 1), new r("ие", 3, 1), new r("ье", 3, 1), new r("и", -1, 1), new r("еи", 6, 1), new r("ии", 6, 1), new r("ами", 6, 1), new r("ями", 6, 1), new r("иями", 10, 1), new r("й", -1, 1), new r("ей", 12, 1), new r("ией", 13, 1), new r("ий", 12, 1), new r("ой", 12, 1), new r("ам", -1, 1), new r("ем", -1, 1), new r("ием", 18, 1), new r("ом", -1, 1), new r("ям", -1, 1), new r("иям", 21, 1), new r("о", -1, 1), new r("у", -1, 1), new r("ах", -1, 1), new r("ях", -1, 1), new r("иях", 26, 1), new r("ы", -1, 1), new r("ь", -1, 1), new r("ю", -1, 1), new r("ию", 30, 1), new r("ью", 30, 1), new r("я", -1, 1), new r("ия", 33, 1), new r("ья", 33, 1)],
                                S = [new r("ост", -1, 1), new r("ость", -1, 1)],
                                F = [new r("ейше", -1, 1), new r("н", -1, 2), new r("ейш", -1, 1), new r("ь", -1, 3)],
                                q = [33, 65, 8, 232],
                                W = new n;
                            this.setCurrent = function(e) {
                                W.setCurrent(e)
                            }, this.getCurrent = function() {
                                return W.getCurrent()
                            }, this.stem = function() {
                                return i(), W.cursor = W.limit, !(W.cursor < b) && (W.limit_backward = b, u() || (W.cursor = W.limit, f() || (W.cursor = W.limit), l() || (W.cursor = W.limit, d() || (W.cursor = W.limit, w()))), W.cursor = W.limit, W.ket = W.cursor, W.eq_s_b(1, "и") ? (W.bra = W.cursor, W.slice_del()) : W.cursor = W.limit, m(), W.cursor = W.limit, p(), !0)
                            }
                        };
                    return function(e) {
                        return t.setCurrent(e), t.stem(), t.getCurrent()
                    }
                }(), e.Pipeline.registerFunction(e.ru.stemmer, "stemmer-ru"), e.ru.stopWordFilter = function(r) {
                    if (e.ru.stopWordFilter.stopWords.indexOf(r) === -1) return r
                }, e.ru.stopWordFilter.stopWords = new e.SortedSet, e.ru.stopWordFilter.stopWords.length = 422, e.ru.stopWordFilter.stopWords.elements = " алло без близко более больше будем будет будете будешь будто буду будут будь бы бывает бывь был была были было быть в важная важное важные важный вам вами вас ваш ваша ваше ваши вверх вдали вдруг ведь везде весь вниз внизу во вокруг вон восемнадцатый восемнадцать восемь восьмой вот впрочем времени время все всегда всего всем всеми всему всех всею всю всюду вся всё второй вы г где говорил говорит год года году да давно даже далеко дальше даром два двадцатый двадцать две двенадцатый двенадцать двух девятнадцатый девятнадцать девятый девять действительно дел день десятый десять для до довольно долго должно другая другие других друго другое другой е его ее ей ему если есть еще ещё ею её ж же жизнь за занят занята занято заняты затем зато зачем здесь значит и из или им именно иметь ими имя иногда их к каждая каждое каждые каждый кажется как какая какой кем когда кого ком кому конечно которая которого которой которые который которых кроме кругом кто куда лет ли лишь лучше люди м мало между меля менее меньше меня миллионов мимо мира мне много многочисленная многочисленное многочисленные многочисленный мной мною мог могут мож может можно можхо мои мой мор мочь моя моё мы на наверху над надо назад наиболее наконец нам нами нас начала наш наша наше наши не него недавно недалеко нее ней нельзя нем немного нему непрерывно нередко несколько нет нею неё ни нибудь ниже низко никогда никуда ними них ничего но ну нужно нх о об оба обычно один одиннадцатый одиннадцать однажды однако одного одной около он она они оно опять особенно от отовсюду отсюда очень первый перед по под пожалуйста позже пока пор пора после посреди потом потому почему почти прекрасно при про просто против процентов пятнадцатый пятнадцать пятый пять раз разве рано раньше рядом с сам сама сами самим самими самих само самого самой самом самому саму свое своего своей свои своих свою сеаой себе себя сегодня седьмой сейчас семнадцатый семнадцать семь сих сказал сказала сказать сколько слишком сначала снова со собой собою совсем спасибо стал суть т та так такая также такие такое такой там твой твоя твоё те тебе тебя тем теми теперь тех то тобой тобою тогда того тоже только том тому тот тою третий три тринадцатый тринадцать ту туда тут ты тысяч у уж уже уметь хорошо хотеть хоть хотя хочешь часто чаще чего человек чем чему через четвертый четыре четырнадцатый четырнадцать что чтоб чтобы чуть шестнадцатый шестнадцать шестой шесть эта эти этим этими этих это этого этой этом этому этот эту я \ufeffа".split(" "),
                e.Pipeline.registerFunction(e.ru.stopWordFilter, "stopWordFilter-ru")
        }
    })
}, function(e, r, n) {
    var t, i;
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(this, function() {
        return function(e) {
            if ("undefined" == typeof e) throw new Error("Lunr is not present. Please include / require Lunr before this script.");
            if ("undefined" == typeof e.stemmerSupport) throw new Error("Lunr stemmer support is not present. Please include / require Lunr stemmer support before this script.");
            e.sv = function() {
                this.pipeline.reset(), this.pipeline.add(e.sv.stopWordFilter, e.sv.stemmer)
            }, e.sv.stemmer = function() {
                var r = e.stemmerSupport.Among,
                    n = e.stemmerSupport.SnowballProgram,
                    t = new function() {
                        function e() {
                            var e, r = w.cursor + 3;
                            if (u = w.limit, 0 <= r || r <= w.limit) {
                                for (s = r;;) {
                                    if (e = w.cursor, w.in_grouping(f, 97, 246)) {
                                        w.cursor = e;
                                        break
                                    }
                                    if (w.cursor = e, w.cursor >= w.limit) return;
                                    w.cursor++
                                }
                                for (; !w.out_grouping(f, 97, 246);) {
                                    if (w.cursor >= w.limit) return;
                                    w.cursor++
                                }
                                u = w.cursor, u < s && (u = s)
                            }
                        }

                        function t() {
                            var e, r = w.limit_backward;
                            if (w.cursor >= u && (w.limit_backward = u, w.cursor = w.limit, w.ket = w.cursor, e = w.find_among_b(a, 37), w.limit_backward = r, e)) switch (w.bra = w.cursor, e) {
                                case 1:
                                    w.slice_del();
                                    break;
                                case 2:
                                    w.in_grouping_b(d, 98, 121) && w.slice_del()
                            }
                        }

                        function i() {
                            var e = w.limit_backward;
                            w.cursor >= u && (w.limit_backward = u, w.cursor = w.limit, w.find_among_b(c, 7) && (w.cursor = w.limit, w.ket = w.cursor, w.cursor > w.limit_backward && (w.bra = --w.cursor, w.slice_del())), w.limit_backward = e)
                        }

                        function o() {
                            var e, r;
                            if (w.cursor >= u) {
                                if (r = w.limit_backward, w.limit_backward = u, w.cursor = w.limit, w.ket = w.cursor, e = w.find_among_b(l, 5)) switch (w.bra = w.cursor, e) {
                                    case 1:
                                        w.slice_del();
                                        break;
                                    case 2:
                                        w.slice_from("lös");
                                        break;
                                    case 3:
                                        w.slice_from("full")
                                }
                                w.limit_backward = r
                            }
                        }
                        var s, u, a = [new r("a", -1, 1), new r("arna", 0, 1), new r("erna", 0, 1), new r("heterna", 2, 1), new r("orna", 0, 1), new r("ad", -1, 1), new r("e", -1, 1), new r("ade", 6, 1), new r("ande", 6, 1), new r("arne", 6, 1), new r("are", 6, 1), new r("aste", 6, 1), new r("en", -1, 1), new r("anden", 12, 1), new r("aren", 12, 1), new r("heten", 12, 1), new r("ern", -1, 1), new r("ar", -1, 1), new r("er", -1, 1), new r("heter", 18, 1), new r("or", -1, 1), new r("s", -1, 2), new r("as", 21, 1), new r("arnas", 22, 1), new r("ernas", 22, 1), new r("ornas", 22, 1), new r("es", 21, 1), new r("ades", 26, 1), new r("andes", 26, 1), new r("ens", 21, 1), new r("arens", 29, 1), new r("hetens", 29, 1), new r("erns", 21, 1), new r("at", -1, 1), new r("andet", -1, 1), new r("het", -1, 1), new r("ast", -1, 1)],
                            c = [new r("dd", -1, -1), new r("gd", -1, -1), new r("nn", -1, -1), new r("dt", -1, -1), new r("gt", -1, -1), new r("kt", -1, -1), new r("tt", -1, -1)],
                            l = [new r("ig", -1, 1), new r("lig", 0, 1), new r("els", -1, 1), new r("fullt", -1, 3), new r("löst", -1, 2)],
                            f = [17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 0, 32],
                            d = [119, 127, 149],
                            w = new n;
                        this.setCurrent = function(e) {
                            w.setCurrent(e)
                        }, this.getCurrent = function() {
                            return w.getCurrent()
                        }, this.stem = function() {
                            var r = w.cursor;
                            return e(), w.limit_backward = r, w.cursor = w.limit, t(), w.cursor = w.limit, i(), w.cursor = w.limit, o(), !0
                        }
                    };
                return function(e) {
                    return t.setCurrent(e), t.stem(), t.getCurrent()
                }
            }(), e.Pipeline.registerFunction(e.sv.stemmer, "stemmer-sv"), e.sv.stopWordFilter = function(r) {
                if (e.sv.stopWordFilter.stopWords.indexOf(r) === -1) return r
            }, e.sv.stopWordFilter.stopWords = new e.SortedSet, e.sv.stopWordFilter.stopWords.length = 115, e.sv.stopWordFilter.stopWords.elements = " alla allt att av blev bli blir blivit de dem den denna deras dess dessa det detta dig din dina ditt du där då efter ej eller en er era ert ett från för ha hade han hans har henne hennes hon honom hur här i icke ingen inom inte jag ju kan kunde man med mellan men mig min mina mitt mot mycket ni nu när någon något några och om oss på samma sedan sig sin sina sitta själv skulle som så sådan sådana sådant till under upp ut utan vad var vara varför varit varje vars vart vem vi vid vilka vilkas vilken vilket vår våra vårt än är åt över".split(" "), e.Pipeline.registerFunction(e.sv.stopWordFilter, "stopWordFilter-sv")
        }
    })
}, function(e, r, n) {
    var t, i;
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(this, function() {
        return function(e) {
            if ("undefined" == typeof e) throw new Error("Lunr is not present. Please include / require Lunr before this script.");
            if ("undefined" == typeof e.stemmerSupport) throw new Error("Lunr stemmer support is not present. Please include / require Lunr stemmer support before this script.");
            e.tr = function() {
                this.pipeline.reset(), this.pipeline.add(e.tr.stopWordFilter, e.tr.stemmer)
            }, e.tr.stemmer = function() {
                var r = e.stemmerSupport.Among,
                    n = e.stemmerSupport.SnowballProgram,
                    t = new function() {
                        function e(e, r, n) {
                            for (;;) {
                                var t = Ne.limit - Ne.cursor;
                                if (Ne.in_grouping_b(e, r, n)) {
                                    Ne.cursor = Ne.limit - t;
                                    break
                                }
                                if (Ne.cursor = Ne.limit - t, Ne.cursor <= Ne.limit_backward) return !1;
                                Ne.cursor--
                            }
                            return !0
                        }

                        function t() {
                            var r, n;
                            r = Ne.limit - Ne.cursor, e(je, 97, 305);
                            for (var t = 0; t < Me.length; t++) {
                                n = Ne.limit - Ne.cursor;
                                var i = Me[t];
                                if (Ne.eq_s_b(1, i[0]) && e(i[1], i[2], i[3])) return Ne.cursor = Ne.limit - r, !0;
                                Ne.cursor = Ne.limit - n
                            }
                            return Ne.cursor = Ne.limit - n, !(!Ne.eq_s_b(1, "ü") || !e(Ie, 246, 252)) && (Ne.cursor = Ne.limit - r, !0)
                        }

                        function i(e, r) {
                            var n, t = Ne.limit - Ne.cursor;
                            return e() && (Ne.cursor = Ne.limit - t, Ne.cursor > Ne.limit_backward && (Ne.cursor--, n = Ne.limit - Ne.cursor, r())) ? (Ne.cursor = Ne.limit - n, !0) : (Ne.cursor = Ne.limit - t, e() ? (Ne.cursor = Ne.limit - t, !1) : (Ne.cursor = Ne.limit - t, !(Ne.cursor <= Ne.limit_backward) && (Ne.cursor--, !!r() && (Ne.cursor = Ne.limit - t, !0))))
                        }

                        function o(e) {
                            return i(e, function() {
                                return Ne.in_grouping_b(je, 97, 305)
                            })
                        }

                        function s() {
                            return o(function() {
                                return Ne.eq_s_b(1, "n")
                            })
                        }

                        function u() {
                            return o(function() {
                                return Ne.eq_s_b(1, "s")
                            })
                        }

                        function a() {
                            return o(function() {
                                return Ne.eq_s_b(1, "y")
                            })
                        }

                        function c() {
                            return i(function() {
                                return Ne.in_grouping_b(Le, 105, 305)
                            }, function() {
                                return Ne.out_grouping_b(je, 97, 305)
                            })
                        }

                        function l() {
                            return Ne.find_among_b(oe, 10) && c()
                        }

                        function f() {
                            return t() && Ne.in_grouping_b(Le, 105, 305) && u()
                        }

                        function d() {
                            return Ne.find_among_b(se, 2)
                        }

                        function w() {
                            return t() && Ne.in_grouping_b(Le, 105, 305) && a()
                        }

                        function m() {
                            return t() && Ne.find_among_b(ue, 4)
                        }

                        function p() {
                            return t() && Ne.find_among_b(ae, 4) && s()
                        }

                        function h() {
                            return t() && Ne.find_among_b(ce, 2) && a()
                        }

                        function b() {
                            return t() && Ne.find_among_b(le, 2)
                        }

                        function v() {
                            return t() && Ne.find_among_b(fe, 4)
                        }

                        function _() {
                            return t() && Ne.find_among_b(de, 2)
                        }

                        function g() {
                            return t() && Ne.find_among_b(we, 4)
                        }

                        function k() {
                            return t() && Ne.find_among_b(me, 2)
                        }

                        function y() {
                            return t() && Ne.find_among_b(pe, 2) && a()
                        }

                        function x() {
                            return Ne.eq_s_b(2, "ki")
                        }

                        function S() {
                            return t() && Ne.find_among_b(he, 2) && s()
                        }

                        function F() {
                            return t() && Ne.find_among_b(be, 4) && a()
                        }

                        function q() {
                            return t() && Ne.find_among_b(ve, 4)
                        }

                        function W() {
                            return t() && Ne.find_among_b(_e, 4) && a()
                        }

                        function z() {
                            return Ne.find_among_b(ge, 4)
                        }

                        function j() {
                            return t() && Ne.find_among_b(ke, 2)
                        }

                        function L() {
                            return t() && Ne.find_among_b(ye, 4)
                        }

                        function C() {
                            return t() && Ne.find_among_b(xe, 8)
                        }

                        function P() {
                            return Ne.find_among_b(Se, 2)
                        }

                        function E() {
                            return t() && Ne.find_among_b(Fe, 32) && a()
                        }

                        function A() {
                            return Ne.find_among_b(qe, 8) && a()
                        }

                        function O() {
                            return t() && Ne.find_among_b(We, 4) && a()
                        }

                        function I() {
                            return Ne.eq_s_b(3, "ken") && a()
                        }

                        function M() {
                            var e = Ne.limit - Ne.cursor;
                            return !(O() || (Ne.cursor = Ne.limit - e, E() || (Ne.cursor = Ne.limit - e, A() || (Ne.cursor = Ne.limit - e, I()))))
                        }

                        function N() {
                            if (P()) {
                                var e = Ne.limit - Ne.cursor;
                                if (z() || (Ne.cursor = Ne.limit - e, j() || (Ne.cursor = Ne.limit - e, F() || (Ne.cursor = Ne.limit - e, q() || (Ne.cursor = Ne.limit - e, W() || (Ne.cursor = Ne.limit - e))))), O()) return !1
                            }
                            return !0
                        }

                        function T() {
                            if (j()) {
                                Ne.bra = Ne.cursor, Ne.slice_del();
                                var e = Ne.limit - Ne.cursor;
                                return Ne.ket = Ne.cursor, C() || (Ne.cursor = Ne.limit - e, E() || (Ne.cursor = Ne.limit - e, A() || (Ne.cursor = Ne.limit - e, O() || (Ne.cursor = Ne.limit - e)))), te = !1, !1
                            }
                            return !0
                        }

                        function D() {
                            if (!L()) return !0;
                            var e = Ne.limit - Ne.cursor;
                            return !E() && (Ne.cursor = Ne.limit - e, !A())
                        }

                        function R() {
                            var e, r = Ne.limit - Ne.cursor;
                            return !(z() || (Ne.cursor = Ne.limit - r, W() || (Ne.cursor = Ne.limit - r, q() || (Ne.cursor = Ne.limit - r, F())))) || (Ne.bra = Ne.cursor, Ne.slice_del(), e = Ne.limit - Ne.cursor, Ne.ket = Ne.cursor, O() || (Ne.cursor = Ne.limit - e), !1)
                        }

                        function B() {
                            var e, r = Ne.limit - Ne.cursor;
                            if (Ne.ket = Ne.cursor, te = !0, M() && (Ne.cursor = Ne.limit - r, N() && (Ne.cursor = Ne.limit - r, T() && (Ne.cursor = Ne.limit - r, D() && (Ne.cursor = Ne.limit - r, R()))))) {
                                if (Ne.cursor = Ne.limit - r, !C()) return;
                                Ne.bra = Ne.cursor, Ne.slice_del(), Ne.ket = Ne.cursor, e = Ne.limit - Ne.cursor, z() || (Ne.cursor = Ne.limit - e, j() || (Ne.cursor = Ne.limit - e, F() || (Ne.cursor = Ne.limit - e, q() || (Ne.cursor = Ne.limit - e, W() || (Ne.cursor = Ne.limit - e))))), O() || (Ne.cursor = Ne.limit - e)
                            }
                            Ne.bra = Ne.cursor, Ne.slice_del()
                        }

                        function U() {
                            var e, r, n, t;
                            if (Ne.ket = Ne.cursor, x()) {
                                if (e = Ne.limit - Ne.cursor, v()) return Ne.bra = Ne.cursor, Ne.slice_del(), r = Ne.limit - Ne.cursor, Ne.ket = Ne.cursor, j() ? (Ne.bra = Ne.cursor, Ne.slice_del(), U()) : (Ne.cursor = Ne.limit - r, l() && (Ne.bra = Ne.cursor, Ne.slice_del(), Ne.ket = Ne.cursor, j() && (Ne.bra = Ne.cursor, Ne.slice_del(), U()))), !0;
                                if (Ne.cursor = Ne.limit - e, p()) {
                                    if (Ne.bra = Ne.cursor, Ne.slice_del(), Ne.ket = Ne.cursor, n = Ne.limit - Ne.cursor, d()) Ne.bra = Ne.cursor, Ne.slice_del();
                                    else {
                                        if (Ne.cursor = Ne.limit - n, Ne.ket = Ne.cursor, !l() && (Ne.cursor = Ne.limit - n, !f() && (Ne.cursor = Ne.limit - n, !U()))) return !0;
                                        Ne.bra = Ne.cursor, Ne.slice_del(), Ne.ket = Ne.cursor, j() && (Ne.bra = Ne.cursor, Ne.slice_del(), U())
                                    }
                                    return !0
                                }
                                if (Ne.cursor = Ne.limit - e, _()) {
                                    if (t = Ne.limit - Ne.cursor, d()) Ne.bra = Ne.cursor, Ne.slice_del();
                                    else if (Ne.cursor = Ne.limit - t, f()) Ne.bra = Ne.cursor, Ne.slice_del(), Ne.ket = Ne.cursor, j() && (Ne.bra = Ne.cursor, Ne.slice_del(), U());
                                    else if (Ne.cursor = Ne.limit - t, !U()) return !1;
                                    return !0
                                }
                            }
                            return !1
                        }

                        function $(e) {
                            if (Ne.ket = Ne.cursor, !_() && (Ne.cursor = Ne.limit - e, !b())) return !1;
                            var r = Ne.limit - Ne.cursor;
                            if (d()) Ne.bra = Ne.cursor, Ne.slice_del();
                            else if (Ne.cursor = Ne.limit - r, f()) Ne.bra = Ne.cursor, Ne.slice_del(), Ne.ket = Ne.cursor, j() && (Ne.bra = Ne.cursor, Ne.slice_del(), U());
                            else if (Ne.cursor = Ne.limit - r, !U()) return !1;
                            return !0
                        }

                        function H(e) {
                            if (Ne.ket = Ne.cursor, !k() && (Ne.cursor = Ne.limit - e, !m())) return !1;
                            var r = Ne.limit - Ne.cursor;
                            return !(!f() && (Ne.cursor = Ne.limit - r, !d())) && (Ne.bra = Ne.cursor, Ne.slice_del(), Ne.ket = Ne.cursor, j() && (Ne.bra = Ne.cursor, Ne.slice_del(), U()), !0)
                        }

                        function Y() {
                            var e, r = Ne.limit - Ne.cursor;
                            return Ne.ket = Ne.cursor, !(!p() && (Ne.cursor = Ne.limit - r, !y())) && (Ne.bra = Ne.cursor, Ne.slice_del(), e = Ne.limit - Ne.cursor, Ne.ket = Ne.cursor, !(!j() || (Ne.bra = Ne.cursor, Ne.slice_del(), !U())) || (Ne.cursor = Ne.limit - e, Ne.ket = Ne.cursor, !(l() || (Ne.cursor = Ne.limit - e, f() || (Ne.cursor = Ne.limit - e, U()))) || (Ne.bra = Ne.cursor, Ne.slice_del(), Ne.ket = Ne.cursor, j() && (Ne.bra = Ne.cursor, Ne.slice_del(), U()), !0)))
                        }

                        function J() {
                            var e, r, n = Ne.limit - Ne.cursor;
                            if (Ne.ket = Ne.cursor, !v() && (Ne.cursor = Ne.limit - n, !w() && (Ne.cursor = Ne.limit - n, !h()))) return !1;
                            if (Ne.bra = Ne.cursor, Ne.slice_del(), Ne.ket = Ne.cursor, e = Ne.limit - Ne.cursor, l()) Ne.bra = Ne.cursor, Ne.slice_del(), r = Ne.limit - Ne.cursor, Ne.ket = Ne.cursor, j() || (Ne.cursor = Ne.limit - r);
                            else if (Ne.cursor = Ne.limit - e, !j()) return !0;
                            return Ne.bra = Ne.cursor, Ne.slice_del(), Ne.ket = Ne.cursor, U(), !0
                        }

                        function V() {
                            var e, r, n = Ne.limit - Ne.cursor;
                            if (Ne.ket = Ne.cursor, j()) return Ne.bra = Ne.cursor, Ne.slice_del(), void U();
                            if (Ne.cursor = Ne.limit - n, Ne.ket = Ne.cursor, S())
                                if (Ne.bra = Ne.cursor, Ne.slice_del(), e = Ne.limit - Ne.cursor, Ne.ket = Ne.cursor, d()) Ne.bra = Ne.cursor, Ne.slice_del();
                                else {
                                    if (Ne.cursor = Ne.limit - e, Ne.ket = Ne.cursor, !l() && (Ne.cursor = Ne.limit - e, !f())) {
                                        if (Ne.cursor = Ne.limit - e, Ne.ket = Ne.cursor, !j()) return;
                                        if (Ne.bra = Ne.cursor, Ne.slice_del(), !U()) return
                                    }
                                    Ne.bra = Ne.cursor, Ne.slice_del(), Ne.ket = Ne.cursor, j() && (Ne.bra = Ne.cursor, Ne.slice_del(), U())
                                }
                            else if (Ne.cursor = Ne.limit - n, !$(n) && (Ne.cursor = Ne.limit - n, !H(n))) {
                                if (Ne.cursor = Ne.limit - n, Ne.ket = Ne.cursor, g()) return Ne.bra = Ne.cursor, Ne.slice_del(), Ne.ket = Ne.cursor, r = Ne.limit - Ne.cursor, void(l() ? (Ne.bra = Ne.cursor, Ne.slice_del(), Ne.ket = Ne.cursor, j() && (Ne.bra = Ne.cursor, Ne.slice_del(), U())) : (Ne.cursor = Ne.limit - r, j() ? (Ne.bra = Ne.cursor, Ne.slice_del(), U()) : (Ne.cursor = Ne.limit - r, U())));
                                if (Ne.cursor = Ne.limit - n, !Y()) {
                                    if (Ne.cursor = Ne.limit - n, d()) return Ne.bra = Ne.cursor, void Ne.slice_del();
                                    Ne.cursor = Ne.limit - n, U() || (Ne.cursor = Ne.limit - n, J() || (Ne.cursor = Ne.limit - n, Ne.ket = Ne.cursor, (l() || (Ne.cursor = Ne.limit - n, f())) && (Ne.bra = Ne.cursor, Ne.slice_del(), Ne.ket = Ne.cursor, j() && (Ne.bra = Ne.cursor, Ne.slice_del(), U()))))
                                }
                            }
                        }

                        function G() {
                            var e;
                            if (Ne.ket = Ne.cursor, e = Ne.find_among_b(ze, 4)) switch (Ne.bra = Ne.cursor, e) {
                                case 1:
                                    Ne.slice_from("p");
                                    break;
                                case 2:
                                    Ne.slice_from("ç");
                                    break;
                                case 3:
                                    Ne.slice_from("t");
                                    break;
                                case 4:
                                    Ne.slice_from("k")
                            }
                        }

                        function X() {
                            for (;;) {
                                var e = Ne.limit - Ne.cursor;
                                if (Ne.in_grouping_b(je, 97, 305)) {
                                    Ne.cursor = Ne.limit - e;
                                    break
                                }
                                if (Ne.cursor = Ne.limit - e, Ne.cursor <= Ne.limit_backward) return !1;
                                Ne.cursor--
                            }
                            return !0
                        }

                        function K(e, r, n) {
                            if (Ne.cursor = Ne.limit - e, X()) {
                                var t = Ne.limit - Ne.cursor;
                                if (!Ne.eq_s_b(1, r) && (Ne.cursor = Ne.limit - t, !Ne.eq_s_b(1, n))) return !0;
                                Ne.cursor = Ne.limit - e;
                                var i = Ne.cursor;
                                return Ne.insert(Ne.cursor, Ne.cursor, n), Ne.cursor = i, !1
                            }
                            return !0
                        }

                        function Q() {
                            var e = Ne.limit - Ne.cursor;
                            (Ne.eq_s_b(1, "d") || (Ne.cursor = Ne.limit - e, Ne.eq_s_b(1, "g"))) && K(e, "a", "ı") && K(e, "e", "i") && K(e, "o", "u") && K(e, "ö", "ü")
                        }

                        function Z() {
                            for (var e, r = Ne.cursor, n = 2;;) {
                                for (e = Ne.cursor; !Ne.in_grouping(je, 97, 305);) {
                                    if (Ne.cursor >= Ne.limit) return Ne.cursor = e, !(n > 0) && (Ne.cursor = r, !0);
                                    Ne.cursor++
                                }
                                n--
                            }
                        }

                        function ee(e, r, n) {
                            for (; !Ne.eq_s(r, n);) {
                                if (Ne.cursor >= Ne.limit) return !0;
                                Ne.cursor++
                            }
                            return ie = r, ie != Ne.limit || (Ne.cursor = e, !1)
                        }

                        function re() {
                            var e = Ne.cursor;
                            return !ee(e, 2, "ad") || (Ne.cursor = e, !ee(e, 5, "soyad"))
                        }

                        function ne() {
                            var e = Ne.cursor;
                            return !re() && (Ne.limit_backward = e, Ne.cursor = Ne.limit, Q(), Ne.cursor = Ne.limit, G(), !0)
                        }
                        var te, ie, oe = [new r("m", -1, -1), new r("n", -1, -1), new r("miz", -1, -1), new r("niz", -1, -1), new r("muz", -1, -1), new r("nuz", -1, -1), new r("müz", -1, -1), new r("nüz", -1, -1), new r("mız", -1, -1), new r("nız", -1, -1)],
                            se = [new r("leri", -1, -1), new r("ları", -1, -1)],
                            ue = [new r("ni", -1, -1), new r("nu", -1, -1), new r("nü", -1, -1), new r("nı", -1, -1)],
                            ae = [new r("in", -1, -1), new r("un", -1, -1), new r("ün", -1, -1), new r("ın", -1, -1)],
                            ce = [new r("a", -1, -1), new r("e", -1, -1)],
                            le = [new r("na", -1, -1), new r("ne", -1, -1)],
                            fe = [new r("da", -1, -1), new r("ta", -1, -1), new r("de", -1, -1), new r("te", -1, -1)],
                            de = [new r("nda", -1, -1), new r("nde", -1, -1)],
                            we = [new r("dan", -1, -1), new r("tan", -1, -1), new r("den", -1, -1), new r("ten", -1, -1)],
                            me = [new r("ndan", -1, -1), new r("nden", -1, -1)],
                            pe = [new r("la", -1, -1), new r("le", -1, -1)],
                            he = [new r("ca", -1, -1), new r("ce", -1, -1)],
                            be = [new r("im", -1, -1), new r("um", -1, -1), new r("üm", -1, -1), new r("ım", -1, -1)],
                            ve = [new r("sin", -1, -1), new r("sun", -1, -1), new r("sün", -1, -1), new r("sın", -1, -1)],
                            _e = [new r("iz", -1, -1), new r("uz", -1, -1), new r("üz", -1, -1), new r("ız", -1, -1)],
                            ge = [new r("siniz", -1, -1), new r("sunuz", -1, -1), new r("sünüz", -1, -1), new r("sınız", -1, -1)],
                            ke = [new r("lar", -1, -1), new r("ler", -1, -1)],
                            ye = [new r("niz", -1, -1), new r("nuz", -1, -1), new r("nüz", -1, -1), new r("nız", -1, -1)],
                            xe = [new r("dir", -1, -1), new r("tir", -1, -1), new r("dur", -1, -1), new r("tur", -1, -1), new r("dür", -1, -1), new r("tür", -1, -1), new r("dır", -1, -1), new r("tır", -1, -1)],
                            Se = [new r("casına", -1, -1), new r("cesine", -1, -1)],
                            Fe = [new r("di", -1, -1), new r("ti", -1, -1), new r("dik", -1, -1), new r("tik", -1, -1), new r("duk", -1, -1), new r("tuk", -1, -1), new r("dük", -1, -1), new r("tük", -1, -1), new r("dık", -1, -1), new r("tık", -1, -1), new r("dim", -1, -1), new r("tim", -1, -1), new r("dum", -1, -1), new r("tum", -1, -1), new r("düm", -1, -1), new r("tüm", -1, -1), new r("dım", -1, -1), new r("tım", -1, -1), new r("din", -1, -1), new r("tin", -1, -1), new r("dun", -1, -1), new r("tun", -1, -1), new r("dün", -1, -1), new r("tün", -1, -1), new r("dın", -1, -1), new r("tın", -1, -1), new r("du", -1, -1), new r("tu", -1, -1), new r("dü", -1, -1), new r("tü", -1, -1), new r("dı", -1, -1), new r("tı", -1, -1)],
                            qe = [new r("sa", -1, -1), new r("se", -1, -1), new r("sak", -1, -1), new r("sek", -1, -1), new r("sam", -1, -1), new r("sem", -1, -1), new r("san", -1, -1), new r("sen", -1, -1)],
                            We = [new r("miş", -1, -1), new r("muş", -1, -1), new r("müş", -1, -1), new r("mış", -1, -1)],
                            ze = [new r("b", -1, 1), new r("c", -1, 2), new r("d", -1, 3), new r("ğ", -1, 4)],
                            je = [17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 8, 0, 0, 0, 0, 0, 0, 1],
                            Le = [1, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 1],
                            Ce = [1, 64, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                            Pe = [17, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 130],
                            Ee = [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                            Ae = [17],
                            Oe = [65],
                            Ie = [65],
                            Me = [
                                ["a", Ce, 97, 305],
                                ["e", Pe, 101, 252],
                                ["ı", Ee, 97, 305],
                                ["i", Ae, 101, 105],
                                ["o", Oe, 111, 117],
                                ["ö", Ie, 246, 252],
                                ["u", Oe, 111, 117]
                            ],
                            Ne = new n;
                        this.setCurrent = function(e) {
                            Ne.setCurrent(e)
                        }, this.getCurrent = function() {
                            return Ne.getCurrent()
                        }, this.stem = function() {
                            return !!(Z() && (Ne.limit_backward = Ne.cursor, Ne.cursor = Ne.limit, B(), Ne.cursor = Ne.limit, te && (V(), Ne.cursor = Ne.limit_backward, ne())))
                        }
                    };
                return function(e) {
                    return t.setCurrent(e), t.stem(), t.getCurrent()
                }
            }(), e.Pipeline.registerFunction(e.tr.stemmer, "stemmer-tr"), e.tr.stopWordFilter = function(r) {
                if (e.tr.stopWordFilter.stopWords.indexOf(r) === -1) return r
            }, e.tr.stopWordFilter.stopWords = new e.SortedSet, e.tr.stopWordFilter.stopWords.length = 210, e.tr.stopWordFilter.stopWords.elements = " acaba altmış altı ama ancak arada aslında ayrıca bana bazı belki ben benden beni benim beri beş bile bin bir biri birkaç birkez birçok birşey birşeyi biz bizden bize bizi bizim bu buna bunda bundan bunlar bunları bunların bunu bunun burada böyle böylece da daha dahi de defa değil diye diğer doksan dokuz dolayı dolayısıyla dört edecek eden ederek edilecek ediliyor edilmesi ediyor elli en etmesi etti ettiği ettiğini eğer gibi göre halen hangi hatta hem henüz hep hepsi her herhangi herkesin hiç hiçbir iki ile ilgili ise itibaren itibariyle için işte kadar karşın katrilyon kendi kendilerine kendini kendisi kendisine kendisini kez ki kim kimden kime kimi kimse kırk milyar milyon mu mü mı nasıl ne neden nedenle nerde nerede nereye niye niçin o olan olarak oldu olduklarını olduğu olduğunu olmadı olmadığı olmak olması olmayan olmaz olsa olsun olup olur olursa oluyor on ona ondan onlar onlardan onları onların onu onun otuz oysa pek rağmen sadece sanki sekiz seksen sen senden seni senin siz sizden sizi sizin tarafından trilyon tüm var vardı ve veya ya yani yapacak yapmak yaptı yaptıkları yaptığı yaptığını yapılan yapılması yapıyor yedi yerine yetmiş yine yirmi yoksa yüz zaten çok çünkü öyle üzere üç şey şeyden şeyi şeyler şu şuna şunda şundan şunları şunu şöyle".split(" "), e.Pipeline.registerFunction(e.tr.stopWordFilter, "stopWordFilter-tr")
        }
    })
}, function(e, r, n) {
    var t, i;
    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    };
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(void 0, function() {
        return function(e) {
            if ("undefined" == typeof e) throw new Error("Lunr is not present. Please include / require Lunr before this script.");
            if ("undefined" == typeof e.stemmerSupport) throw new Error("Lunr stemmer support is not present. Please include / require Lunr stemmer support before this script.");
            e.unsupported = function() {
                this.pipeline.reset(), this.pipeline.add()
            }, e.unsupported.stemmer = function(e) {
                return e
            }, e.Pipeline.registerFunction(e.unsupported.stemmer, "stemmer-unsupported"), e.unsupported.stopWordFilter = function(r) {
                if (e.unsupported.stopWordFilter.stopWords.indexOf(r) === -1) return r
            }, e.unsupported.stopWordFilter.stopWords = new e.SortedSet, e.unsupported.stopWordFilter.stopWords.length = 1, e.unsupported.stopWordFilter.stopWords.elements = [""], e.Pipeline.registerFunction(e.unsupported.stopWordFilter, "stopWordFilter-unsupported")
        }
    })
}, function(e, r, n) {
    var t, i;
    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    };
    ! function(o, s) {
        t = s, i = "function" == typeof t ? t.call(r, n, r, e) : t, !(void 0 !== i && (e.exports = i))
    }(void 0, function() {
        function e(e) {
            return e.replace(/\u00A0/g, " ").replace(/[\u0021-\u002F\u003A-\u0040\u005B-\u0060\u007B-\u007E\u201C\u201D\u8211\u8212]/g, " ").replace(/\s+/g, " ")
        }

        function r(r) {
            var n = /[\u3000-\u303F\uFF0C\uFF1A\uFF08\uFF09]/g;
            return i(e(r), n)
        }

        function n(r) {
            var n = /[\u3000-\u303F\uFF0C\uFF1A\uFF08\uFF09]/g;
            return i(e(r), n)
        }

        function t(r) {
            var n = /[\u3000-\u303F\uFF0C\uFF1A\uFF08\uFF09\u00B7]/g;
            return i(e(r), n)
        }

        function i(e, r) {
            var n = e.replace(r, " ").split(/\s+/g).map(function(e) {
                return o(e, 2)
            }).reduce(function(e, r) {
                return e.concat(r)
            });
            return n.join(" ")
        }

        function o(e, r) {
            var n = [];
            if (/^\w+$/i.test(e)) return [e];
            for (var t = 0; t < e.length; t++) {
                var i = t + r < e.length ? t + r : e.length;
                n.push(e.substring(t, i))
            }
            return n
        }
        return function(i) {
            switch (i) {
                case "zh":
                    return {
                        normalize: r
                    };
                case "ja":
                    return {
                        normalize: n
                    };
                case "ko":
                    return {
                        normalize: t
                    };
                default:
                    return {
                        normalize: e
                    }
            }
        }
    })
}, function(e, r, n) {
    "use strict";

    function t(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function i(e) {
        if (Array.isArray(e)) {
            for (var r = 0, n = Array(e.length); r < e.length; r++) n[r] = e[r];
            return n
        }
        return Array.from(e)
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var o = n(116),
        s = t(o),
        u = n(117),
        a = t(u),
        c = n(118),
        l = t(c),
        f = n(73),
        d = t(f),
        w = n(75),
        m = t(w),
        p = n(74),
        h = n(64),
        b = t(h);
    r.default = function(e, r) {
        function n(n, t) {
            var i = n(w()),
                o = (0, d.default)(function() {
                    return r
                }, i);
            (0, m.default)(o, r, t), e.location = (0, b.default)(i)
        }
        var t = (0, s.default)(e.webhelp.toc),
            o = Object.keys(t),
            u = function() {
                return r.querySelector(".active")
            },
            c = function() {
                return r.querySelector(".active > a").getAttribute("href")
            },
            f = function(e) {
                return e.substring(2)
            },
            w = function() {
                return f(c())
            },
            h = function(e) {
                return {
                    title: e.title,
                    url: e.url
                }
            },
            v = function e(r) {
                return t[r] ? [].concat(i(e(t[r].parent)), [t[r]]) : []
            };
        return {
            forward: function() {
                return n((0, l.default)(t), !1)
            },
            back: function() {
                return n((0, a.default)(t), !0)
            },
            getTitle: function(e) {
                return t[e] ? t[e].title : "No title"
            },
            getDescription: function(e) {
                return t[e] ? t[e].description : ""
            },
            expandAll: function() {
                (0, p.expandTree)(function() {
                    return r
                }), (0, m.default)(u(), r, !1)
            },
            collapseOthers: function() {
                return (0, p.collapseOthers)(function() {
                    return r
                }, u())
            },
            isFirstTopic: function(e) {
                return e === o[0]
            },
            isLastTopic: function(e) {
                return e === o[o.length - 1]
            },
            getPath: function(e) {
                return v(e).map(h)
            }
        }
    }
}, function(e, r) {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = function e(r) {
        return function(n, t) {
            return (t.url || t.id) && (n[t.url || t.id] = {
                title: t.title,
                description: t.description,
                parent: r,
                url: t.url,
                id: t.id
            }), t.children && t.children.reduce(e(t.url || t.id), n), n
        }
    };
    r.default = function(e) {
        return e.reduce(n(void 0), {})
    }
}, function(e, r) {
    "use strict";

    function n(e, r) {
        var n = Object.keys(e),
            i = n.findIndex(function(e) {
                return e === r
            });
        i--;
        for (var o = function() {
                var r = n[i],
                    t = n.findIndex(function(e) {
                        return e === r
                    }),
                    o = n[t];
                return void 0 !== e[o].url ? {
                    v: r
                } : void i--
            }; i >= 0;) {
            var s = o();
            if ("object" === ("undefined" == typeof s ? "undefined" : t(s))) return s.v
        }
        return r
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    };
    r.default = function(e) {
        return function(r) {
            return n(e, r)
        }
    }
}, function(e, r) {
    "use strict";

    function n(e, r) {
        var n = Object.keys(e),
            i = n.findIndex(function(e) {
                return e === r
            });
        i++;
        for (var o = function() {
                var r = n[i],
                    t = n.findIndex(function(e) {
                        return e === r
                    }),
                    o = n[t];
                return void 0 !== e[o].url ? {
                    v: r
                } : void i++
            }; i < n.length;) {
            var s = o();
            if ("object" === ("undefined" == typeof s ? "undefined" : t(s))) return s.v
        }
        return r
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    };
    r.default = function(e) {
        return function(r) {
            return n(e, r)
        }
    }
}]);
//# sourceMappingURL=offline.js.map